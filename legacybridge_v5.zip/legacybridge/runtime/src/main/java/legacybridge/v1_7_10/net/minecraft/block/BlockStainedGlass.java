package legacybridge.v1_7_10.net.minecraft.block;

import legacybridge.v1_7_10.net.minecraft.block.material.Material;

/** Shim de BlockStainedGlass (1.7.10; na verdade herda de BlockBreakable, que ainda não existe aqui). */
public class BlockStainedGlass extends Block {
    public BlockStainedGlass(Material material) {
        super(material);
    }
}
