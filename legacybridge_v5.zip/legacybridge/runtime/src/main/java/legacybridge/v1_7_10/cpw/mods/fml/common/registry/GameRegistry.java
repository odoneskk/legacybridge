package legacybridge.v1_7_10.cpw.mods.fml.common.registry;

import legacybridge.runtime.PendingRegistry;
import legacybridge.v1_7_10.net.minecraft.block.Block;
import legacybridge.v1_7_10.net.minecraft.item.ItemBlock;
import legacybridge.v1_7_10.net.minecraft.item.ItemStack;

/** Shim de GameRegistry (1.7.10). Só enfileira; o registro real acontece no RegisterEvent. */
public class GameRegistry {
    public static Block registerBlock(Block block, String name) {
        PendingRegistry.queueBlock(name, block);
        return block;
    }

    /** O ItemBlock customizado ainda é ignorado (registramos um BlockItem comum). */
    public static Block registerBlock(Block block, Class<? extends ItemBlock> itemClass, String name) {
        PendingRegistry.queueBlock(name, block);
        return block;
    }

    /** TODO: converter para receita JSON. Por enquanto é só contada e avisada no log. */
    public static void addRecipe(ItemStack output, Object... params) {
        PendingRegistry.ignoredRecipe();
    }

    public static void addShapelessRecipe(ItemStack output, Object... params) {
        PendingRegistry.ignoredRecipe();
    }

    // TODO: registerItem, registerTileEntity, addSmelting, registerWorldGenerator (ver README).
}
