package legacybridge.v1_7_10.net.minecraft.block;

import legacybridge.runtime.LegacyBlockAdapter;
import legacybridge.v1_7_10.net.minecraft.block.material.Material;
import legacybridge.v1_7_10.net.minecraft.client.renderer.texture.IIconRegister;
import legacybridge.v1_7_10.net.minecraft.creativetab.CreativeTabs;
import legacybridge.v1_7_10.net.minecraft.util.IIcon;
import net.minecraft.world.level.block.state.BlockBehaviour;

/**
 * Shim de Block (1.7.10): um objeto COMUM, que não herda do Block moderno.
 *
 * <p>Por quê: o Block moderno registra a si mesmo no construtor e o Minecraft exige que todo Block construído seja
 * registrado (senão os registros não congelam), além de ter propriedades finais. Aqui os "setters encadeados" da 1.7.10
 * só guardam valores; o Block moderno ({@link LegacyBlockAdapter}) é criado por {@link #modern()} quando o bloco é
 * de fato registrado, já com dureza, resistência, som e luz corretos.
 */
public class Block {
    /** Shim de Block.SoundType (1.7.10). */
    public static class SoundType {
        public final String soundName;
        public final float volume;
        public final float frequency;

        public SoundType(String name, float volume, float frequency) {
            this.soundName = name;
            this.volume = volume;
            this.frequency = frequency;
        }
    }

    public static final SoundType soundTypeStone = new SoundType("stone", 1.0F, 1.0F);
    public static final SoundType soundTypeWood = new SoundType("wood", 1.0F, 1.0F);
    public static final SoundType soundTypeGravel = new SoundType("gravel", 1.0F, 1.0F);
    public static final SoundType soundTypeGrass = new SoundType("grass", 1.0F, 1.0F);
    public static final SoundType soundTypePiston = new SoundType("stone", 1.0F, 1.0F);
    public static final SoundType soundTypeMetal = new SoundType("stone", 1.0F, 1.5F);
    public static final SoundType soundTypeGlass = new SoundType("stone", 1.0F, 1.0F);
    public static final SoundType soundTypeCloth = new SoundType("cloth", 1.0F, 1.0F);
    public static final SoundType soundTypeSand = new SoundType("sand", 1.0F, 1.0F);
    public static final SoundType soundTypeSnow = new SoundType("snow", 1.0F, 1.0F);
    public static final SoundType soundTypeLadder = new SoundType("ladder", 1.0F, 1.0F);
    public static final SoundType soundTypeAnvil = new SoundType("anvil", 0.3F, 1.0F);

    private final Material material;
    private String unlocalizedName = "";
    private float blockHardness;
    private float blockResistance;          // no "espaço" da 1.7.10: setResistance(r) guarda r*3; explosão usa isto/5
    private int lightValue;
    private SoundType stepSound = soundTypeStone;
    private CreativeTabs creativeTab;
    private String textureName = "";
    private net.minecraft.world.level.block.Block modern;

    public Block(Material material) {
        this.material = material;
    }

    // ---- "setters encadeados" da 1.7.10 ----

    public Block setBlockName(String name) {
        this.unlocalizedName = name;
        return this;
    }

    public Block setHardness(float hardness) {
        this.blockHardness = hardness;
        if (this.blockResistance < hardness * 5.0F) {
            this.blockResistance = hardness * 5.0F;
        }
        return this;
    }

    public Block setResistance(float resistance) {
        this.blockResistance = resistance * 3.0F;
        return this;
    }

    public Block setBlockUnbreakable() {
        return setHardness(-1.0F);
    }

    public Block setLightLevel(float level) {
        this.lightValue = (int) (15.0F * level);
        return this;
    }

    public Block setStepSound(SoundType sound) {
        this.stepSound = sound;
        return this;
    }

    public Block setCreativeTab(CreativeTabs tab) {
        this.creativeTab = tab;
        return this;
    }

    public Block setBlockTextureName(String name) {
        this.textureName = name;
        return this;
    }

    // ---- métodos que mods costumam sobrescrever (valores padrão da 1.7.10) ----

    public String getUnlocalizedName() {
        return "tile." + unlocalizedName;
    }

    public IIcon getIcon(int side, int meta) {
        return null;
    }

    public void registerBlockIcons(IIconRegister register) {
    }

    public int damageDropped(int meta) {
        return 0;
    }

    public boolean isOpaqueCube() {
        return true;
    }

    public boolean renderAsNormalBlock() {
        return true;
    }

    public int getRenderBlockPass() {
        return 0;
    }

    // ---- acesso para o runtime ----

    public Material legacyMaterial() {
        return material;
    }

    public String legacyTextureName() {
        return textureName;
    }

    public CreativeTabs legacyCreativeTab() {
        return creativeTab;
    }

    /** Usado por Blocks.*: o bloco vanilla correspondente já existe, não criamos outro. */
    public static Block wrapVanilla(Material material, net.minecraft.world.level.block.Block vanilla) {
        Block b = new Block(material);
        b.modern = vanilla;
        return b;
    }

    /** Block moderno que representa este, criado sob demanda (só quando o bloco é registrado). */
    public net.minecraft.world.level.block.Block modern() {
        if (modern == null) {
            modern = new LegacyBlockAdapter(this, buildProperties());
        }
        return modern;
    }

    private BlockBehaviour.Properties buildProperties() {
        BlockBehaviour.Properties p = BlockBehaviour.Properties.of();
        if (blockHardness < 0.0F) {
            p = p.strength(-1.0F, 3600000.0F);
        } else {
            p = p.strength(blockHardness, blockResistance / 5.0F);
        }
        p = p.sound(modernSound(stepSound));
        if (lightValue > 0) {
            final int light = lightValue;
            p = p.lightLevel(state -> light);
        }
        return p;
    }

    private static net.minecraft.world.level.block.SoundType modernSound(SoundType s) {
        if (s == soundTypeWood) return net.minecraft.world.level.block.SoundType.WOOD;
        if (s == soundTypeGravel) return net.minecraft.world.level.block.SoundType.GRAVEL;
        if (s == soundTypeGrass) return net.minecraft.world.level.block.SoundType.GRASS;
        if (s == soundTypeMetal) return net.minecraft.world.level.block.SoundType.METAL;
        if (s == soundTypeGlass) return net.minecraft.world.level.block.SoundType.GLASS;
        if (s == soundTypeCloth) return net.minecraft.world.level.block.SoundType.WOOL;
        if (s == soundTypeSand) return net.minecraft.world.level.block.SoundType.SAND;
        if (s == soundTypeSnow) return net.minecraft.world.level.block.SoundType.SNOW;
        if (s == soundTypeLadder) return net.minecraft.world.level.block.SoundType.LADDER;
        if (s == soundTypeAnvil) return net.minecraft.world.level.block.SoundType.ANVIL;
        return net.minecraft.world.level.block.SoundType.STONE;
    }
}
