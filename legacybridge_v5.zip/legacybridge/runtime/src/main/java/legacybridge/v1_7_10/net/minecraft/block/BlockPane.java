package legacybridge.v1_7_10.net.minecraft.block;

import legacybridge.v1_7_10.net.minecraft.block.material.Material;

/** Shim de BlockPane (1.7.10). TODO: conexão entre painéis (na 1.20 é IronBarsBlock/CrossCollisionBlock). */
public class BlockPane extends Block {
    public BlockPane(String sideTexture, String topTexture, Material material, boolean canDropItself) {
        super(material);
    }
}
