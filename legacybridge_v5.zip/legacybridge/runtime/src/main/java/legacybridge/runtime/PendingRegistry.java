package legacybridge.runtime;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import legacybridge.v1_7_10.net.minecraft.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

/**
 * Na 1.7.10 qualquer coisa registra no preInit; na 1.20.1 só dentro do RegisterEvent. Por isso o preInit legado roda
 * no primeiro RegisterEvent, e os shims (ex.: GameRegistry.registerBlock) só enfileiram aqui. O Block moderno de cada
 * bloco legado só é criado ({@link Block#modern()}) quando o registro correspondente é aberto.
 *
 * <p>TODO: itens, entidades (EntityType + atributos + spawn placement + renderer), biomas e spawns
 * (estes são dados/JSON na 1.20.1, ver README), ItemBlock customizado, abas criativas
 * (BuildCreativeModeTabContentsEvent), receitas.
 */
public final class PendingRegistry {
    private static final Map<ResourceLocation, Block> BLOCKS = new LinkedHashMap<>();
    private static int ignoredRecipes;

    private PendingRegistry() {}

    public static void queueBlock(String name, Block block) {
        String path = name.toLowerCase(Locale.ROOT);
        BLOCKS.put(new ResourceLocation(LegacyBootstrap.currentModId(), path), block);
    }

    public static void ignoredRecipe() {
        ignoredRecipes++;
    }

    static int ignoredRecipes() {
        return ignoredRecipes;
    }

    static void onRegister(RegisterEvent event) {
        // Primeiro RegisterEvent de qualquer registro: os registros estão abertos, então o preInit legado só pode
        // rodar agora. As chamadas seguintes não fazem nada (a flag fica no LegacyBootstrap).
        LegacyBootstrap.runPreInit();
        event.register(ForgeRegistries.Keys.BLOCKS,
                helper -> BLOCKS.forEach((id, block) -> helper.register(id, block.modern())));
        event.register(ForgeRegistries.Keys.ITEMS,
                helper -> BLOCKS.forEach((id, block) -> helper.register(id, new BlockItem(block.modern(), new Item.Properties()))));
    }
}
