package legacybridge.runtime;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;

/**
 * O Block moderno que representa um Block legado (1.7.10). Hoje só carrega a referência e a chave de tradução;
 * é aqui que vão entrar, aos poucos: metadata como BlockState, drops, interação, render type, etc.
 */
public class LegacyBlockAdapter extends Block {
    private final legacybridge.v1_7_10.net.minecraft.block.Block legacy;

    public LegacyBlockAdapter(legacybridge.v1_7_10.net.minecraft.block.Block legacy, BlockBehaviour.Properties properties) {
        super(properties);
        this.legacy = legacy;
    }

    public legacybridge.v1_7_10.net.minecraft.block.Block legacy() {
        return legacy;
    }

    @Override
    public String getDescriptionId() {
        String name = legacy.getUnlocalizedName();
        return name.equals("tile.") ? super.getDescriptionId() : name;
    }
}
