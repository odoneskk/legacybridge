package legacybridge.runtime;

import java.util.ArrayList;
import java.util.List;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import legacybridge.v1_7_10.cpw.mods.fml.common.event.FMLInitializationEvent;
import legacybridge.v1_7_10.cpw.mods.fml.common.event.FMLPostInitializationEvent;
import legacybridge.v1_7_10.cpw.mods.fml.common.event.FMLPreInitializationEvent;

/**
 * Liga o mundo antigo ao novo.
 *
 * <p>Ordem de execução (importa muito):
 * <ol>
 *   <li><b>Construção do mod</b> ({@link #boot}): só instancia a classe do mod legado e injeta {@code @Mod.Instance}.
 *       Aqui os registros do Minecraft ainda estão CONGELADOS.</li>
 *   <li><b>Primeiro RegisterEvent</b> ({@link #runPreInit}): roda o {@code preInit} dos mods legados. É aqui, e só aqui,
 *       que o {@code new Block(...)} de um mod 1.7.10 pode acontecer: o construtor do Block moderno registra um
 *       "holder" interno e lança "Registry is already frozen" fora desse momento.</li>
 *   <li><b>FMLCommonSetupEvent</b> ({@link #onCommonSetup}): {@code init} e {@code postInit}.</li>
 * </ol>
 *
 * <p>Por enquanto só a geração 1.7.10.
 */
public final class LegacyBootstrap {
    private static final Logger LOGGER = LogManager.getLogger("legacybridge");
    private static final List<LegacyModContainer> MODS = new ArrayList<>();
    private static String currentModId = "minecraft";
    private static boolean preInitDone;

    private LegacyBootstrap() {}

    /** Equivalente ao Loader.instance().activeModContainer().getModId() da 1.7.10. */
    public static String currentModId() {
        return currentModId;
    }

    /** Chamado pela classe de entrada gerada, no construtor do mod (registros ainda congelados). */
    public static void boot(Class<?> anchor, String modId, String legacyClassName) {
        String previous = currentModId;
        currentModId = modId;
        try {
            Class<?> cls = Class.forName(legacyClassName, true, anchor.getClassLoader());
            var ctor = cls.getDeclaredConstructor();
            ctor.setAccessible(true);
            LegacyModContainer container = new LegacyModContainer(modId, ctor.newInstance());
            MODS.add(container);
            container.injectInstance();
        } catch (LinkageError e) {
            throw missingShim(modId, e);
        } catch (ReflectiveOperationException e) {
            if (e.getCause() instanceof LinkageError le) {
                throw missingShim(modId, le);
            }
            throw new IllegalStateException("Legacy Bridge: não foi possível iniciar o mod legado " + modId, e);
        } finally {
            currentModId = previous;
        }
    }

    /** Chamado no primeiro RegisterEvent (qualquer registro): nesse momento todos os registros estão abertos. */
    static synchronized void runPreInit() {
        if (preInitDone) {
            return;
        }
        preInitDone = true;
        for (LegacyModContainer c : MODS) {
            currentModId = c.modId();
            LOGGER.info("Legacy Bridge: preInit de {}", c.modId());
            try {
                c.fire(new FMLPreInitializationEvent(c.modId()));
            } finally {
                currentModId = "minecraft";
            }
        }
    }

    static void onCommonSetup(FMLCommonSetupEvent event) {
        if (PendingRegistry.ignoredRecipes() > 0) {
            LOGGER.warn("Legacy Bridge: {} receita(s) dos mods legados foram IGNORADAS (conversão para JSON ainda não implementada)",
                    PendingRegistry.ignoredRecipes());
        }
        for (LegacyModContainer c : MODS) {
            currentModId = c.modId();
            c.fire(new FMLInitializationEvent());
        }
        event.enqueueWork(() -> {
            for (LegacyModContainer c : MODS) {
                currentModId = c.modId();
                c.fire(new FMLPostInitializationEvent());
            }
            currentModId = "minecraft";
        });
    }

    static IllegalStateException missingShim(String modId, Throwable cause) {
        return new IllegalStateException("Legacy Bridge: o mod '" + modId + "' usa parte da API 1.7.10 que ainda não tem shim ("
                + cause + "). A lista completa está em .legacybridge/cache/*.linkreport.txt", cause);
    }
}
