package legacybridge.loader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.commons.ClassRemapper;

/** Traduz um jar legado inteiro: bytecode, recursos, metadados e a classe de entrada do Forge 1.20.1. */
final class JarTranslator {
    private static final String PACK_MCMETA =
            "{\n  \"pack\": {\n    \"description\": \"Legacy Bridge\",\n    \"pack_format\": 15\n  }\n}\n";
    private static final Pattern LANG = Pattern.compile("^(assets/[^/]+/lang/)([^/]+)\\.lang$");
    private static final Pattern TEXTURES = Pattern.compile("^(assets/[^/]+/textures/)(blocks|items)/(.*)$");

    private final McpMappings mcp;
    private final ShimIndex shims;

    JarTranslator(McpMappings mcp, ShimIndex shims) {
        this.mcp = mcp;
        this.shims = shims;
    }

    LinkReport translate(Path in, Path out, List<LegacyModDecl> decls) throws IOException {
        LegacyGeneration gen = decls.get(0).generation();

        Set<String> ownClasses = new HashSet<>();
        try (ZipFile zip = new ZipFile(in.toFile())) {
            for (Enumeration<? extends ZipEntry> en = zip.entries(); en.hasMoreElements(); ) {
                String n = en.nextElement().getName();
                if (n.endsWith(".class")) {
                    ownClasses.add(n.substring(0, n.length() - ".class".length()));
                }
            }
        }
        LegacyRemapper remapper = new LegacyRemapper(gen, mcp, ownClasses);
        Map<String, ShimIndex.Info> ownInfo = new HashMap<>();

        Files.createDirectories(out.toAbsolutePath().getParent());
        Path tmp = out.resolveSibling(out.getFileName() + ".tmp");
        Set<String> written = new HashSet<>();
        try (ZipFile zip = new ZipFile(in.toFile());
             ZipOutputStream zo = new ZipOutputStream(Files.newOutputStream(tmp))) {

            put(zo, written, "META-INF/MANIFEST.MF", "Manifest-Version: 1.0\r\n\r\n".getBytes(StandardCharsets.UTF_8));

            for (Enumeration<? extends ZipEntry> en = zip.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement();
                String name = e.getName();
                if (e.isDirectory() || skip(name)) {
                    continue;
                }
                byte[] data;
                try (InputStream is = zip.getInputStream(e)) {
                    data = is.readAllBytes();
                }
                if (name.endsWith(".class")) {
                    ownInfo.put(name.substring(0, name.length() - ".class".length()), readOwn(data, remapper));
                    data = remapClass(data, remapper);
                } else {
                    Matcher lang = LANG.matcher(name);
                    Matcher tex = TEXTURES.matcher(name);
                    if (lang.matches()) {
                        name = lang.group(1) + lang.group(2).toLowerCase(Locale.ROOT) + ".json";
                        data = LangConverter.toJson(new String(data, StandardCharsets.UTF_8)).getBytes(StandardCharsets.UTF_8);
                    } else if (tex.matches()) {
                        // Achatamento da 1.13: textures/blocks -> textures/block, textures/items -> textures/item.
                        name = tex.group(1) + (tex.group(2).equals("blocks") ? "block" : "item") + "/" + tex.group(3);
                    }
                }
                put(zo, written, name, data);
            }

            put(zo, written, "META-INF/mods.toml",
                    ModsTomlWriter.write(decls, in.getFileName().toString()).getBytes(StandardCharsets.UTF_8));
            put(zo, written, "pack.mcmeta", PACK_MCMETA.getBytes(StandardCharsets.UTF_8));

            for (LegacyModDecl m : decls) {
                String id = ModIds.sanitize(m.modId());
                String entry = "legacybridge/gen/" + id + "/LegacyEntry";
                put(zo, written, entry + ".class", LifecycleEntryGenerator.generate(entry, id, m.modClass()));
            }
        }
        Files.move(tmp, out, StandardCopyOption.REPLACE_EXISTING);
        return LinkReport.build(remapper, shims.withOwn(ownInfo));
    }

    /** Hierarquia e membros de uma classe do mod, já no vocabulário MCP/shim, para o relatório de links. */
    private ShimIndex.Info readOwn(byte[] bytes, LegacyRemapper remapper) {
        ClassReader cr = new ClassReader(bytes);
        Set<String> methods = new HashSet<>();
        Set<String> fields = new HashSet<>();
        cr.accept(new org.objectweb.asm.ClassVisitor(org.objectweb.asm.Opcodes.ASM9) {
            @Override
            public org.objectweb.asm.MethodVisitor visitMethod(int access, String name, String desc, String sig, String[] ex) {
                methods.add(mcp.method(name) + remapper.mapMethodDesc(desc));
                return null;
            }

            @Override
            public org.objectweb.asm.FieldVisitor visitField(int access, String name, String desc, String sig, Object value) {
                fields.add(mcp.field(name));
                return null;
            }
        }, ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
        return new ShimIndex.Info(cr.getSuperName(), List.of(cr.getInterfaces()), methods, fields);
    }

    private static byte[] remapClass(byte[] bytes, LegacyRemapper remapper) {
        ClassReader cr = new ClassReader(bytes);
        ClassWriter cw = new ClassWriter(0);          // sem COMPUTE_FRAMES: não exige carregar classes do jogo
        cr.accept(new ClassRemapper(cw, remapper), 0);
        return cw.toByteArray();
    }

    /** Entradas que não devem ir para o jar traduzido (assinaturas ficam inválidas depois de reescrever). */
    private static boolean skip(String name) {
        String n = name.toUpperCase(Locale.ROOT);
        return n.equals("META-INF/MANIFEST.MF")
                || n.equals("META-INF/MODS.TOML")
                || n.equals("PACK.MCMETA")
                || n.equals("MODULE-INFO.CLASS")
                || (n.startsWith("META-INF/") && (n.endsWith(".SF") || n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC")))
                || n.startsWith("META-INF/VERSIONS/");
    }

    private static void put(ZipOutputStream zo, Set<String> written, String name, byte[] data) throws IOException {
        if (!written.add(name)) {
            return;                                   // duplicata (ex.: .json já existia ao lado do .lang)
        }
        zo.putNextEntry(new ZipEntry(name));
        zo.write(data);
        zo.closeEntry();
    }
}
