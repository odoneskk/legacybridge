package legacybridge.loader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

/**
 * Índice (classes, métodos, campos) dos shims do runtime + as classes do mod sendo traduzido.
 * Serve só para o relatório de links: diz o que o mod chama e o runtime ainda não implementa.
 *
 * <p>As classes do mod entram no índice porque quase toda chamada a um método da API antiga tem como
 * dono a SUBCLASSE do mod (ex.: {@code this.setHardness()} dentro de MeuBloco), e só dá para saber se
 * o método existe subindo a hierarquia: classe do mod -> shim -> (classe moderna, não verificável).
 */
final class ShimIndex {
    /** OK, não verificável (herda de classe moderna), faltando, ou sem relação com os shims. */
    enum Status { OK, UNVERIFIED, MISSING, IRRELEVANT }

    record Info(String superName, List<String> interfaces, Set<String> methods, Set<String> fields) {}

    private static final Set<String> OBJECT_METHODS = Set.of(
            "toString", "equals", "hashCode", "getClass", "notify", "notifyAll", "wait", "clone", "finalize");

    private final LegacyGeneration gen;
    private final Map<String, Info> shims = new HashMap<>();
    private final Map<String, Info> own = new HashMap<>();

    private ShimIndex(LegacyGeneration gen) {
        this.gen = gen;
    }

    static ShimIndex fromJar(Path runtimeJar, LegacyGeneration gen) throws IOException {
        ShimIndex idx = new ShimIndex(gen);
        try (ZipFile zip = new ZipFile(runtimeJar.toFile())) {
            for (Enumeration<? extends ZipEntry> en = zip.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement();
                if (!e.getName().startsWith(gen.shimPrefix) || !e.getName().endsWith(".class")) {
                    continue;
                }
                try (InputStream in = zip.getInputStream(e)) {
                    ClassReader cr = new ClassReader(in);
                    idx.shims.put(cr.getClassName(), readInfo(cr));
                }
            }
        }
        return idx;
    }

    /** Cópia que também conhece as classes do mod (nomes originais; métodos/campos já com nomes MCP). */
    ShimIndex withOwn(Map<String, Info> ownClasses) {
        ShimIndex copy = new ShimIndex(gen);
        copy.shims.putAll(shims);
        copy.own.putAll(ownClasses);
        return copy;
    }

    static Info readInfo(ClassReader cr) {
        Set<String> methods = new HashSet<>();
        Set<String> fields = new HashSet<>();
        cr.accept(new ClassVisitor(Opcodes.ASM9) {
            @Override
            public MethodVisitor visitMethod(int access, String name, String desc, String sig, String[] ex) {
                methods.add(name + desc);
                return null;
            }

            @Override
            public FieldVisitor visitField(int access, String name, String desc, String sig, Object value) {
                fields.add(name);
                return null;
            }
        }, ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
        return new Info(cr.getSuperName(), List.of(cr.getInterfaces()), methods, fields);
    }

    boolean hasClass(String relocatedInternalName) {
        return shims.containsKey(relocatedInternalName);
    }

    int size() {
        return shims.size();
    }

    /** Guarda o primeiro shim visitado na subida: é nele que o membro faltante deve ser implementado. */
    static final class Probe {
        String nearestShim;
    }

    /** {@code owner} é o nome ORIGINAL (antes da realocação); name/desc já estão no vocabulário MCP/shim. */
    Status check(String owner, String name, String desc, boolean field, Probe probe) {
        return walk(owner, name, desc, field, false, new HashSet<>(), probe);
    }

    private Status walk(String owner, String name, String desc, boolean field, boolean viaShim,
                        Set<String> seen, Probe probe) {
        if (owner == null || !seen.add(owner)) {
            return Status.IRRELEVANT;
        }
        Info info = own.get(owner);
        boolean touched = viaShim;
        if (info == null) {
            String relocated = gen.relocate(owner);
            info = shims.get(relocated);
            if (info != null) {
                touched = true;
                if (probe.nearestShim == null) {
                    probe.nearestShim = relocated;
                }
            } else if (gen.isShim(relocated)) {
                return Status.IRRELEVANT;             // classe sem shim: já listada em "classes sem shim"
            } else if (owner.equals("java/lang/Object") && touched) {
                return (!field && OBJECT_METHODS.contains(name)) ? Status.OK : Status.MISSING;
            } else {
                return touched ? Status.UNVERIFIED : Status.IRRELEVANT;
            }
        }
        if (field ? info.fields().contains(name) : info.methods().contains(name + desc)) {
            return Status.OK;
        }
        if (!field && name.equals("<init>")) {
            return touched ? Status.MISSING : Status.IRRELEVANT;     // construtores não são herdados
        }
        Status best = walk(info.superName(), name, desc, field, touched, seen, probe);
        for (String itf : info.interfaces()) {
            if (best == Status.OK) {
                return best;
            }
            Status s = walk(itf, name, desc, field, touched, seen, probe);
            if (s.ordinal() < best.ordinal()) {
                best = s;
            }
        }
        return best;
    }
}
