# Legacy Bridge

Esqueleto de um mod para **Forge 1.20.1** (Java 17) que traduz mods **1.7.10** (e, depois, 1.12.2) em tempo de
carregamento: você coloca o jar do mod antigo na pasta `mods/` junto com o `legacybridge-x.y.z.jar` e ele roda
como mod normal.

Começa pela **1.7.10**. A 1.12.2 já está modelada (`LegacyGeneration.V1_12_2`), mas desligada em
`LegacyBridgeLocator.ENABLED` até existirem shims para ela.

## Como funciona

```
mods/
 ├─ legacybridge-0.1.0.jar      ← loader (camada de serviço do Forge) com o runtime embutido
 └─ algum-mod-1.7.10.jar        ← mod legado, sem mods.toml
```

1. **Locator** (`LegacyBridgeLocator`): o Forge pergunta quais jars são mods. Ele devolve o runtime (extraído para
   `.legacybridge/runtime/`) e cada jar legado já traduzido (cache em `.legacybridge/cache/`).
2. **Inspector**: acha `@Mod` (`cpw.mods.fml.common.Mod`) nos jars sem `mods.toml`.
3. **Tradutor** (`JarTranslator`), por jar:
   - realoca a API antiga (`net/minecraft/**`, `net/minecraftforge/**`, `cpw/mods/fml/**`) para os **shims**
     em `legacybridge/v1_7_10/**` e troca nomes SRG (`func_149711_c`) pelos nomes MCP (`setHardness`);
   - gera `META-INF/mods.toml`, `pack.mcmeta` e uma classe `@Mod("id")` de entrada, cujo construtor chama
     `LegacyBootstrap.boot(...)` no runtime;
   - converte `.lang` → `.json` e renomeia `textures/blocks|items` → `textures/block|item`.
4. **Runtime** (mod `legacybridge`): shims da API antiga sobre a API moderna e o ciclo de vida dos mods legados:
   construção do mod (só instancia; registros ainda congelados) → **`preInit` no primeiro `RegisterEvent`** (único
   momento em que `new Block(...)` é permitido; fora dele dá "Registry is already frozen") → `init`/`postInit` no
   `FMLCommonSetupEvent`. Os shims de registro (`GameRegistry.registerBlock`) enfileiram, e o flush acontece
   quando o registro correspondente é aberto.

   O `Block` do shim é um **objeto comum** (não herda do `Block` moderno): o moderno registra a si mesmo no
   construtor, exige que todo bloco construído seja registrado e tem propriedades finais. Os "setters encadeados" da
   1.7.10 (`setHardness`, `setStepSound`...) só guardam valores, e `Block.modern()` cria o `LegacyBlockAdapter` com tudo
   aplicado quando o bloco é registrado. `Blocks.glass` e cia. embrulham os blocos vanilla (`Block.wrapVanilla`).
5. **Relatório de links**: para cada jar traduzido, `.legacybridge/cache/*.linkreport.txt` lista classes e métodos
   da API antiga que o mod usa e os shims ainda não têm. **É a sua lista de tarefas**: traduza mods reais e implemente
   o que o relatório mostrar, começando pelo que mais se repete.

## O que foi testado aqui (e o que não foi)

Rodado de verdade (JDK 21, sem Forge): inspeção de `@Mod`, remapeamento SRG→MCP + realocação, geração de
`mods.toml`/`pack.mcmeta`/classe de entrada, conversão de lang e texturas, carga do jar traduzido pelo verificador
do JVM (com StackMapTable), execução do `preInit` de um mod 1.7.10 falso e o relatório de links (inclusive chamadas
feitas por subclasses do mod). Reproduza com:

```
dev-test/run.sh caminho/methods.csv caminho/fields.csv
```

**NÃO testado** (sem rede nem Forge neste ambiente): o build Gradle, o `LegacyBridgeLocator` contra o FML 47, o
runtime e os shims contra os mappings oficiais da 1.20.1, e qualquer execução dentro do Minecraft. Trate esses
três como "escritos de memória, a validar".

## Primeiros passos

1. **Gradle wrapper**: não incluído. Copie `gradlew`, `gradlew.bat` e `gradle/wrapper/` do MDK do Forge 1.20.1.
2. `./gradlew build` → o jar final é `loader/build/libs/legacybridge-0.1.0.jar`.
3. **Mapeamentos MCP 1.7.10**: baixe o MCP stable da 1.7.10 (artefato `mcp_stable` do maven do Forge) e coloque
   `methods.csv` e `fields.csv` em `<pasta do jogo>/.legacybridge/mappings/1.7.10/`. Sem eles quase nenhum mod
   funciona (o jar do mod só tem nomes `func_`/`field_`). Os CSVs não vêm no projeto por causa da licença deles.
   O cache de traduções leva em conta esses arquivos: se você os colocar ou trocar depois, o mod é retraduzido sozinho.
4. Rode com um mod 1.7.10 **bem simples** (só blocos) e leia o `.linkreport.txt`.

## Estado atual (confirmado em jogo, Forge 47.4.28)

- ✔ O build compila e o Forge **descobre o `LegacyBridgeLocator`** soltando um único jar em `mods/`.
- ✔ O runtime entra na lista de mods e o mod 1.7.10 é traduzido (cache), reconhecido como mod e **construído**
  (a classe de entrada gerada chama o `LegacyBootstrap`).
- ✔ O jar 1.7.10 original na pasta `mods/` não causa erro.
- ✔ (corrigido na v4) `preInit` rodava no construtor do mod e quebrava com "Registry is already frozen".
- ✔ Mod de teste sintético (`lbtest`): carrega e registra o bloco no jogo.
- ✘ Qualquer mod que use API sem shim falha ao carregar. Exemplo real: o ExtrabiomesXL 1.7.10 deu
  `NoClassDefFoundError: ...CreativeTabs` (o relatório dele: 170 classes sem shim). Isso é esperado: os shims
  cobrem só o mínimo, e um mod de bioma precisa de muito mais (BiomeGenBase, geração de mundo, itens, ...).

### Teste mínimo dentro do jogo

`legacybridge-testmod-1.7.10.jar` é um mod 1.7.10 **sintético** (gerado por `dev-test/MakeTestMod.java`) que
registra um bloco usando só o que os shims atuais cobrem. Coloque-o em `mods/` junto com o Legacy Bridge. Esperado:
"LB Test Mod" na lista de mods e o bloco `lbtest:test_block` (`/give @s lbtest:test_block`, ou procure no JEI),
com textura quadriculada laranja/roxa e nome "LB Test Block". Se isso funcionar, o caminho completo
(tradução → entrada → preInit → registro) está certo, e o trabalho passa a ser só ampliar os shims.

### Iterar nos shims sem abrir o jogo

```
dev-test/translate.sh mod-1.7.10.jar methods.csv fields.csv .legacybridge/runtime/legacybridge-runtime-XXXX.jar
```
Traduz o jar e imprime o relatório de links (as 25 primeiras classes sem shim + arquivo completo).
Implemente os shims, recompile, repita. O log do jogo (`latest.log`) também mostra as 10 primeiras pendências de cada mod.

## Riscos a validar primeiro (1 a 3 já confirmados no jogo)

1. **Compila?** `LegacyBridgeLocator` estende `AbstractJarFileModLocator`. Se o compilador reclamar de método
   abstrato (`scanFile`, `isValid`...), copie o padrão do `ModsFolderLocator` do Forge 47.x.
2. **O Forge descobre o locator?** O jar é `FMLModType: LIBRARY` + `META-INF/services/...IModLocator`. No código
   do FML que consultei (a descoberta de jars em `mods/` é feita pelo `ModDirTransformerDiscoverer`; a versão que li é
   a da 1.14, e a API de `AbstractJarFileModLocator` conferi na documentação da 1.20), jars com esse service são
   tratados como serviço do loader. Não confirmei na 47.x. Se não carregar, a referência certa é o **Sinytra
   Connector 1.20.1** (MIT, github.com/Sinytra/Connector), que já resolve "soltar o jar na pasta mods" no mesmo
   Forge; o `ConnectorLocator` dele é o análogo direto.
3. **Jar legado original na pasta mods**: o Forge também enxerga o jar antigo (sem `mods.toml`) e pode reclamar de
   "arquivo inválido". Veja como o Connector trata os jars Fabric, que estão na mesma situação.
4. **Runtime**: compila contra os mappings oficiais? (`BlockBehaviour.Properties.of()`, `getDescriptionId()`,
   `RegisterEvent`.) O mod `legacybridge` aparece na lista de mods?

## Biomas e mobs (a dor que você citou)

Causas prováveis dos "bioma/mob não aparece" em conectores desse tipo (não verifiquei no Legacy Connector):
na 1.20.1 biomas, features e spawns são **dados** (JSON), e mob precisa de `EntityType` + atributos + spawn
placement + renderer. Mods antigos registram tudo por código. Plano:

- biomas: capturar o que o mod registra e **gerar** `data/<id>/worldgen/biome/*.json` + inclusão no Overworld;
- spawns (`EntityRegistry.addSpawn`): gerar biome modifiers (`forge:add_spawns`);
- `IWorldGenerator` não tem equivalente direto: emular por evento de chunk ou convertendo para features;
- entidades: registrar `EntityType`, atributos (`EntityAttributeCreationEvent`) e spawn placement.

Confirme os nomes exatos no Forge 47.x. Regra de qualidade: nenhum mod com bioma/entidade é "suportado" enquanto o
relatório de links tiver pendência nessas áreas.

## O que falta (sugestão de ordem)

1. Itens (`Item`, `GameRegistry.registerItem`), `ItemStack`, NBT, abas criativas (`BuildCreativeModeTabContentsEvent`).
2. Dureza/resistência de verdade: Access Transformer em `BlockBehaviour$BlockStateBase` (hoje só guardadas no shim).
3. Recursos: 1.7.10 não tem blockstates nem modelos JSON; gerar a partir dos nomes de textura.
4. Entidades, biomas, world gen, receitas (`addRecipe` → JSON), `TileEntity`.
5. Compatibilidade de Java antigo (`sun.misc.*` etc.), coremods (`FMLCorePlugin`), pacotes divididos entre mods,
   `mcmod.info` (nome/versão com `useMetadata`), Scala.
6. Gerador de esqueletos de shims a partir de um dump de assinaturas da 1.7.10 (você precisa do jar original
   da 1.7.10 para isso).
7. Habilitar a 1.12.2.

## Licenças e distribuição

Os jars traduzidos ficam só no cache local do jogador. **Não redistribua** o cache: os mods originais têm suas
próprias licenças. Este código é original; o Legacy Connector enviado serviu apenas para entender a arquitetura
(não copiei código nem mapeamentos dele).
