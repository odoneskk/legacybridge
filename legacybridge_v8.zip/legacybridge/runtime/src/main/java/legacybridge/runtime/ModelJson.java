package legacybridge.runtime;

import java.util.Locale;

/**
 * JSONs de blockstate/modelo (1.20.1) para blocos legados. A 1.7.10 não tem nada disso: as texturas vinham de
 * IIcon registrados por código, e aqui são reconstruídas a partir do que o mod registrou.
 * Faces da 1.7.10: 0=baixo, 1=cima, 2=norte, 3=sul, 4=oeste, 5=leste.
 */
public final class ModelJson {
    private ModelJson() {}

    /** "mod:nome" (nome de ícone 1.7.10) -> "mod:block/nome" (textura 1.20; minúsculas obrigatórias). */
    public static String texture(String icon) {
        String ns = "minecraft";
        String path = icon;
        int colon = icon.indexOf(':');
        if (colon >= 0) {
            ns = icon.substring(0, colon);
            path = icon.substring(colon + 1);
        }
        return ns.toLowerCase(Locale.ROOT) + ":block/" + path.toLowerCase(Locale.ROOT);
    }

    /**
     * @param faces      nomes de ícone por face (null = sem info); posições 0..5
     * @param fallback   ícone usado nas faces sem info (null = textura "faltando")
     * @param renderType null (sólido), "cutout" ou "translucent"
     */
    public static String blockModel(String[] faces, String fallback, String renderType) {
        String[] tex = new String[6];
        boolean same = true;
        for (int i = 0; i < 6; i++) {
            String icon = faces[i] != null ? faces[i] : fallback;
            tex[i] = icon == null ? "minecraft:missingno" : texture(icon);
            if (!tex[i].equals(tex[0])) {
                same = false;
            }
        }
        String render = renderType == null ? "" : ",\"render_type\":" + q("minecraft:" + renderType);
        if (same) {
            return "{\"parent\":\"minecraft:block/cube_all\",\"textures\":{\"all\":" + q(tex[0]) + "}" + render + "}";
        }
        return "{\"parent\":\"minecraft:block/cube\",\"textures\":{\"particle\":" + q(tex[1])
                + ",\"down\":" + q(tex[0]) + ",\"up\":" + q(tex[1]) + ",\"north\":" + q(tex[2])
                + ",\"south\":" + q(tex[3]) + ",\"west\":" + q(tex[4]) + ",\"east\":" + q(tex[5]) + "}" + render + "}";
    }

    public static String blockstate(String modelId) {
        return "{\"variants\":{\"\":{\"model\":" + q(modelId) + "}}}";
    }

    public static String itemModel(String blockModelId) {
        return "{\"parent\":" + q(blockModelId) + "}";
    }

    private static String q(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }
}
