package legacybridge.v1_7_10.net.minecraft.init;

import legacybridge.v1_7_10.net.minecraft.block.Block;
import legacybridge.v1_7_10.net.minecraft.block.BlockGrass;
import legacybridge.v1_7_10.net.minecraft.block.BlockSand;
import legacybridge.v1_7_10.net.minecraft.block.BlockStainedGlass;
import legacybridge.v1_7_10.net.minecraft.block.BlockStainedGlassPane;
import legacybridge.v1_7_10.net.minecraft.block.material.Material;

/**
 * Shim de Blocks (1.7.10): cada campo é um Block legado que "embrulha" o bloco vanilla equivalente da 1.20.1.
 * Só carrega quando algum mod usa (normalmente dentro do preInit, depois do bootstrap do Minecraft).
 * Metadados (ex.: cor do vidro) não existem na 1.20: stained_glass vira o vidro branco por enquanto.
 */
public class Blocks {
    public static final Block stone = Block.wrapVanilla(Material.rock, net.minecraft.world.level.block.Blocks.STONE);
    public static final Block cobblestone = Block.wrapVanilla(Material.rock, net.minecraft.world.level.block.Blocks.COBBLESTONE);
    public static final Block dirt = Block.wrapVanilla(Material.ground, net.minecraft.world.level.block.Blocks.DIRT);
    // Atenção: na 1.7.10 alguns campos têm tipo próprio, e o JVM compara o tipo do campo (NoSuchFieldError se diferir).
    public static final BlockGrass grass = Block.bindVanilla(new BlockGrass(), net.minecraft.world.level.block.Blocks.GRASS_BLOCK);
    public static final Block planks = Block.wrapVanilla(Material.wood, net.minecraft.world.level.block.Blocks.OAK_PLANKS);
    public static final BlockSand sand = Block.bindVanilla(new BlockSand(), net.minecraft.world.level.block.Blocks.SAND);
    public static final Block gravel = Block.wrapVanilla(Material.ground, net.minecraft.world.level.block.Blocks.GRAVEL);
    public static final Block glass = Block.wrapVanilla(Material.glass, net.minecraft.world.level.block.Blocks.GLASS);
    public static final Block glass_pane = Block.wrapVanilla(Material.glass, net.minecraft.world.level.block.Blocks.GLASS_PANE);
    public static final BlockStainedGlass stained_glass = Block.bindVanilla(new BlockStainedGlass(Material.glass),
            net.minecraft.world.level.block.Blocks.WHITE_STAINED_GLASS);
    public static final BlockStainedGlassPane stained_glass_pane = Block.bindVanilla(new BlockStainedGlassPane(),
            net.minecraft.world.level.block.Blocks.WHITE_STAINED_GLASS_PANE);
    public static final Block iron_bars = Block.wrapVanilla(Material.iron, net.minecraft.world.level.block.Blocks.IRON_BARS);
    public static final Block iron_block = Block.wrapVanilla(Material.iron, net.minecraft.world.level.block.Blocks.IRON_BLOCK);
    public static final Block gold_block = Block.wrapVanilla(Material.iron, net.minecraft.world.level.block.Blocks.GOLD_BLOCK);
    public static final Block diamond_block = Block.wrapVanilla(Material.iron, net.minecraft.world.level.block.Blocks.DIAMOND_BLOCK);
    public static final Block obsidian = Block.wrapVanilla(Material.rock, net.minecraft.world.level.block.Blocks.OBSIDIAN);
    public static final Block glowstone = Block.wrapVanilla(Material.glass, net.minecraft.world.level.block.Blocks.GLOWSTONE);
    public static final Block brick_block = Block.wrapVanilla(Material.rock, net.minecraft.world.level.block.Blocks.BRICKS);
    public static final Block bedrock = Block.wrapVanilla(Material.rock, net.minecraft.world.level.block.Blocks.BEDROCK);
    public static final Block wool = Block.wrapVanilla(Material.wood, net.minecraft.world.level.block.Blocks.WHITE_WOOL);
}
