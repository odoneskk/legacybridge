package legacybridge.loader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.fml.loading.moddiscovery.AbstractJarFileModLocator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Ponto de entrada no Forge 1.20.1. O Forge pergunta "quais jars são mods?"; respondemos com:
 * <ol>
 *   <li>o runtime embutido (extraído para .legacybridge/runtime);</li>
 *   <li>cada jar legado de mods/, já traduzido (cache em .legacybridge/cache).</li>
 * </ol>
 *
 * <p>ATENÇÃO: esta é a parte mais dependente da API interna do FML 47 e NÃO foi compilada/testada
 * aqui (sem rede para baixar o Forge). Se o compilador reclamar de método abstrato, compare com o
 * {@code ModsFolderLocator} do Forge 47.x. O README lista os pontos a validar primeiro.
 */
public class LegacyBridgeLocator extends AbstractJarFileModLocator {
    private static final Logger LOGGER = LogManager.getLogger("legacybridge");

    /** Gerações com shims minimamente utilizáveis. Comece por uma só e amplie quando a anterior estiver estável. */
    private static final Set<LegacyGeneration> ENABLED = EnumSet.of(LegacyGeneration.V1_7_10);

    @Override
    public String name() {
        return "legacybridge";
    }

    @Override
    public void initArguments(Map<String, ?> arguments) {
    }

    @Override
    public Stream<Path> scanCandidates() {
        try {
            return discover().stream();
        } catch (IOException | RuntimeException e) {
            LOGGER.error("Legacy Bridge: falha ao localizar mods legados; seguindo sem eles", e);
            return Stream.empty();
        }
    }

    private List<Path> discover() throws IOException {
        Path work = FMLPaths.GAMEDIR.get().resolve(".legacybridge");
        Path modsDir = FMLPaths.MODSDIR.get();

        List<Path> result = new ArrayList<>();
        Path runtime = extractRuntime(work.resolve("runtime"));
        result.add(runtime);

        String buildId = TranslationCache.sha256(runtime).substring(0, 12);
        TranslationCache cache = new TranslationCache(work.resolve("cache"), buildId);
        List<Path> keep = new ArrayList<>();
        Map<LegacyGeneration, JarTranslator> translators = new EnumMap<>(LegacyGeneration.class);

        List<Path> jars = new ArrayList<>();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(modsDir, "*.jar")) {
            ds.forEach(jars::add);
        }
        jars.sort(null);

        for (Path jar : jars) {
            try {
                List<LegacyModDecl> decls = LegacyJarInspector.inspect(jar);
                if (decls.isEmpty()) {
                    continue;
                }
                LegacyGeneration gen = decls.get(0).generation();
                if (!ENABLED.contains(gen)) {
                    LOGGER.warn("Legacy Bridge: {} é um mod {} e essa geração ainda não está habilitada; ignorando.",
                            jar.getFileName(), gen.label);
                    continue;
                }
                Path translated = cache.pathFor(jar);
                keep.add(translated);
                keep.add(TranslationCache.reportFor(translated));
                if (!Files.exists(translated)) {
                    JarTranslator tr = translators.get(gen);
                    if (tr == null) {
                        tr = new JarTranslator(loadMappings(work.resolve("mappings"), gen), ShimIndex.fromJar(runtime, gen));
                        translators.put(gen, tr);
                    }
                    LOGGER.info("Legacy Bridge: traduzindo {} ({})", jar.getFileName(), gen.label);
                    LinkReport report = tr.translate(jar, translated, decls);
                    Files.writeString(TranslationCache.reportFor(translated),
                            report.render(jar.getFileName().toString()), StandardCharsets.UTF_8);
                    LOGGER.info("Legacy Bridge: {} -> {}", jar.getFileName(), report.summary());
                }
                result.add(translated);
            } catch (IOException | RuntimeException e) {
                LOGGER.error("Legacy Bridge: não foi possível traduzir {}", jar.getFileName(), e);
            }
        }
        cache.prune(keep);
        return result;
    }

    private static McpMappings loadMappings(Path dir, LegacyGeneration gen) throws IOException {
        Path base = dir.resolve(gen.label);
        Path methods = base.resolve("methods.csv");
        Path fields = base.resolve("fields.csv");
        if (!Files.isRegularFile(methods) || !Files.isRegularFile(fields)) {
            LOGGER.warn("Legacy Bridge: faltam {} e {}. Sem eles os nomes SRG (func_/field_) não são traduzidos e "
                    + "quase todo mod vai falhar. Veja o README.", methods, fields);
            return McpMappings.empty();
        }
        McpMappings m = McpMappings.load(methods, fields);
        LOGGER.info("Legacy Bridge: {} mapeamentos MCP {} carregados", m.size(), gen.label);
        return m;
    }

    private static Path extractRuntime(Path dir) throws IOException {
        Files.createDirectories(dir);
        byte[] data;
        try (InputStream in = LegacyBridgeLocator.class.getResourceAsStream("/META-INF/legacybridge/runtime.jar")) {
            if (in == null) {
                throw new IOException("runtime.jar não está embutido neste jar (build incompleto?)");
            }
            data = in.readAllBytes();
        }
        Path target = dir.resolve("legacybridge-runtime-" + TranslationCache.sha256(data).substring(0, 12) + ".jar");
        if (!Files.exists(target)) {
            Files.write(target, data);
        }
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, "legacybridge-runtime-*.jar")) {
            for (Path p : ds) {
                if (!p.equals(target)) {
                    Files.deleteIfExists(p);
                }
            }
        }
        return target;
    }
}
