package legacybridge.runtime;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import legacybridge.v1_7_10.cpw.mods.fml.common.Mod;
import legacybridge.v1_7_10.cpw.mods.fml.common.SidedProxy;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** Um mod 1.7.10 em execução: injeta @Mod.Instance e despacha eventos para métodos @Mod.EventHandler. */
final class LegacyModContainer {
    private static final Logger LOGGER = LogManager.getLogger("legacybridge");

    private final String modId;
    private final Object instance;

    LegacyModContainer(String modId, Object instance) {
        this.modId = modId;
        this.instance = instance;
    }

    String modId() {
        return modId;
    }

    void injectInstance() throws IllegalAccessException {
        for (Class<?> c = instance.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (f.isAnnotationPresent(Mod.Instance.class) && f.getType().isAssignableFrom(instance.getClass())) {
                    f.setAccessible(true);
                    f.set(Modifier.isStatic(f.getModifiers()) ? null : instance, instance);
                }
                SidedProxy proxy = f.getAnnotation(SidedProxy.class);
                if (proxy != null) {
                    injectProxy(f, proxy);
                }
            }
        }
    }

    /** @SidedProxy: instancia a classe do cliente ou do servidor e a põe no campo (estático) do mod. */
    private void injectProxy(Field f, SidedProxy proxy) {
        String className = FMLEnvironment.dist == Dist.CLIENT ? proxy.clientSide() : proxy.serverSide();
        try {
            Object value = Class.forName(className, true, instance.getClass().getClassLoader()).getDeclaredConstructor().newInstance();
            f.setAccessible(true);
            f.set(Modifier.isStatic(f.getModifiers()) ? null : instance, value);
        } catch (ReflectiveOperationException | LinkageError e) {
            LOGGER.error("Legacy Bridge: não foi possível criar o proxy {} do mod '{}'", className, modId, e);
        }
    }

    void fire(Object event) {
        for (Class<?> c = instance.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                if (m.isAnnotationPresent(Mod.EventHandler.class)
                        && m.getParameterCount() == 1
                        && m.getParameterTypes()[0].isInstance(event)) {
                    try {
                        m.setAccessible(true);
                        m.invoke(Modifier.isStatic(m.getModifiers()) ? null : instance, event);
                    } catch (InvocationTargetException e) {
                        if (e.getCause() instanceof LinkageError le) {
                            throw LegacyBootstrap.missingShim(modId, le);
                        }
                        throw new IllegalStateException("Erro em " + modId + " (" + m + "): " + e.getCause(), e.getCause());
                    } catch (IllegalAccessException e) {
                        throw new IllegalStateException(e);
                    }
                }
            }
        }
    }
}
