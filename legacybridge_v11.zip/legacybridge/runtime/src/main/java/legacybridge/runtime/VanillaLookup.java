package legacybridge.runtime;

import java.util.HashMap;
import java.util.Map;

import legacybridge.v1_7_10.net.minecraft.block.Block;
import legacybridge.v1_7_10.net.minecraft.block.material.Material;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistries;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Acha o bloco vanilla da 1.20.1 que corresponde a um nome de Blocks.* da 1.7.10 (ex.: "log" -> oak_log). Usado pelos
 * campos de Blocks que o shim não declara: o tradutor cria no mod uma classe com esses campos e cada um chama aqui.
 */
public final class VanillaLookup {
    private static final Logger LOGGER = LogManager.getLogger("legacybridge");
    private static final Map<String, String> RENAMES = new HashMap<>();
    private static final Map<String, Block> CACHE = new HashMap<>();

    static {
        String[][] pairs = {
            {"grass", "grass_block"}, {"log", "oak_log"}, {"log2", "acacia_log"}, {"leaves", "oak_leaves"}, {"leaves2", "acacia_leaves"},
            {"planks", "oak_planks"}, {"sapling", "oak_sapling"}, {"tallgrass", "grass"}, {"deadbush", "dead_bush"},
            {"reeds", "sugar_cane"}, {"yellow_flower", "dandelion"}, {"red_flower", "poppy"}, {"double_plant", "sunflower"},
            {"stonebrick", "stone_bricks"}, {"brick_block", "bricks"}, {"snow_layer", "snow"}, {"snow", "snow_block"},
            {"waterlily", "lily_pad"}, {"web", "cobweb"}, {"hardened_clay", "terracotta"}, {"stained_hardened_clay", "white_terracotta"},
            {"wool", "white_wool"}, {"carpet", "white_carpet"}, {"lit_pumpkin", "jack_o_lantern"}, {"melon_block", "melon"},
            {"fence", "oak_fence"}, {"wooden_slab", "oak_slab"}, {"double_wooden_slab", "oak_slab"}, {"double_stone_slab", "stone_slab"},
            {"flowing_water", "water"}, {"flowing_lava", "lava"}, {"noteblock", "note_block"}, {"golden_rail", "powered_rail"},
            {"lit_redstone_ore", "redstone_ore"}, {"monster_egg", "infested_stone"}, {"stained_glass", "white_stained_glass"},
            {"stained_glass_pane", "white_stained_glass_pane"}, {"lit_furnace", "furnace"}, {"lit_redstone_lamp", "redstone_lamp"},
            {"standing_sign", "oak_sign"}, {"wall_sign", "oak_wall_sign"}, {"wooden_door", "oak_door"}, {"trapdoor", "oak_trapdoor"},
            {"wooden_pressure_plate", "oak_pressure_plate"}, {"wooden_button", "oak_button"}, {"fence_gate", "oak_fence_gate"},
            {"mob_spawner", "spawner"}, {"nether_brick", "nether_bricks"}, {"nether_brick_fence", "nether_brick_fence"},
        };
        for (String[] p : pairs) {
            RENAMES.put(p[0], p[1]);
        }
    }

    private VanillaLookup() {}

    /** Bloco legado que embrulha o vanilla equivalente (ou o ar, com um aviso, se não souber qual é). */
    public static synchronized Block block(String name) {
        Block cached = CACHE.get(name);
        if (cached == null) {
            cached = resolve(name);
            CACHE.put(name, cached);
        }
        return cached;
    }

    private static Block resolve(String name) {
        String path = RENAMES.getOrDefault(name, name);
        net.minecraft.world.level.block.Block vanilla = ForgeRegistries.BLOCKS.getValue(new ResourceLocation("minecraft", path));
        if (vanilla == null || (vanilla == net.minecraft.world.level.block.Blocks.AIR && !path.equals("air"))) {
            LOGGER.warn("Legacy Bridge: o bloco vanilla '{}' da 1.7.10 não tem equivalente conhecido na 1.20.1; usando ar", name);
            vanilla = net.minecraft.world.level.block.Blocks.AIR;
        }
        return Block.wrapVanilla(Material.rock, vanilla);
    }
}
