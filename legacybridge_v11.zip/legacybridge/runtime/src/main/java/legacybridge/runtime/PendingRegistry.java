package legacybridge.runtime;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.BiConsumer;

import legacybridge.v1_7_10.net.minecraft.block.Block;
import legacybridge.v1_7_10.net.minecraft.creativetab.CreativeTabs;
import legacybridge.v1_7_10.net.minecraft.item.ItemStack;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Na 1.7.10 qualquer coisa registra no preInit; na 1.20.1 só dentro do RegisterEvent. Por isso o preInit legado roda
 * no primeiro RegisterEvent, e os shims (ex.: GameRegistry.registerBlock) só enfileiram aqui.
 *
 * <p>Metadata: a 1.20 não tem. Um bloco legado com N valores de metadata (ex.: 16 cores) vira N blocos modernos,
 * "nome_0" ... "nome_15" (ou só "nome", se tem um único valor). O Block moderno de cada um só é criado
 * ({@link Block#modernForMeta}) quando o registro é aberto.
 *
 * <p>TODO: itens, entidades, biomas e spawns (dados/JSON na 1.20.1, ver README), ItemBlock customizado de verdade.
 */
public final class PendingRegistry {
    /** Um bloco moderno que representa uma metadata de um bloco legado. */
    public record Variant(ResourceLocation id, Block legacy, int meta) {}

    private static final Logger LOGGER = LogManager.getLogger("legacybridge");
    private static final Map<ResourceLocation, Block> BLOCKS = new LinkedHashMap<>();
    private static final List<LegacyRecipe> RECIPES = new ArrayList<>();
    /** Nome final de cada bloco moderno (pode diferir do desejado se houve conflito de nome). */
    private static final Map<Variant, ResourceLocation> FINAL_IDS = new LinkedHashMap<>();

    private PendingRegistry() {}

    public static void queueBlock(String name, Block block) {
        String path = name.toLowerCase(Locale.ROOT);
        BLOCKS.put(new ResourceLocation(LegacyBootstrap.currentModId(), path), block);
    }

    public static void queueRecipe(boolean shaped, ItemStack output, Object[] params) {
        RECIPES.add(new LegacyRecipe(LegacyBootstrap.currentModId(), shaped, output, params));
    }

    static List<LegacyRecipe> recipes() {
        return Collections.unmodifiableList(RECIPES);
    }

    /** Todos os blocos modernos (um por metadata). Só confiável depois do RegisterEvent de blocos. */
    static List<Variant> variants() {
        List<Variant> all = new ArrayList<>();
        for (Map.Entry<ResourceLocation, Block> e : BLOCKS.entrySet()) {
            List<Integer> metas = e.getValue().subMetas();
            for (int meta : metas) {
                all.add(new Variant(variantId(e.getKey(), metas.size(), meta), e.getValue(), meta));
            }
        }
        return all;
    }

    private static ResourceLocation variantId(ResourceLocation base, int metaCount, int meta) {
        return metaCount == 1 ? base : new ResourceLocation(base.getNamespace(), base.getPath() + "_" + meta);
    }

    static void onRegister(RegisterEvent event) {
        // Primeiro RegisterEvent de qualquer registro: os registros estão abertos, então o preInit legado só pode
        // rodar agora. As chamadas seguintes não fazem nada (a flag fica no LegacyBootstrap).
        LegacyBootstrap.runPreInit();
        event.register(ForgeRegistries.Keys.BLOCKS, helper -> {
            int count = 0;
            for (Variant v : variants()) {
                net.minecraft.world.level.block.Block modern;
                try {
                    modern = v.legacy().modernForMeta(v.meta());
                } catch (RuntimeException | LinkageError e) {
                    LOGGER.error("Legacy Bridge: não foi possível criar o bloco {}", v.id(), e);
                    continue;
                }
                // Isolamento: um bloco problemático (ex.: nome duplicado) não pode derrubar o registro dos outros mods.
                ResourceLocation finalId = registerSafely((id, b) -> helper.register(id, b), v.id(), modern);
                if (finalId != null) {
                    FINAL_IDS.put(v, finalId);
                    LOGGER.info("Legacy Bridge: bloco registrado: {}", finalId);
                    count++;
                }
            }
            LOGGER.info("Legacy Bridge: {} bloco(s) de mods legados registrado(s)", count);
        });
        event.register(ForgeRegistries.Keys.ITEMS, helper -> {
            for (Variant v : variants()) {
                try {
                    ResourceLocation id = FINAL_IDS.getOrDefault(v, v.id());
                    helper.register(id, new BlockItem(v.legacy().modernForMeta(v.meta()), new Item.Properties()));
                } catch (RuntimeException | LinkageError e) {
                    LOGGER.error("Legacy Bridge: não foi possível registrar o item do bloco {}", v.id(), e);
                }
            }
        });
    }

    /**
     * Registra; se o nome já existe ou é inválido, tenta "nome_dup1", "nome_dup2"... Isso importa: um Block moderno
     * criado e NÃO registrado faz o Minecraft falhar ao congelar os registros ("Unbound values in registry").
     */
    private static ResourceLocation registerSafely(BiConsumer<ResourceLocation, net.minecraft.world.level.block.Block> register,
                                                   ResourceLocation id, net.minecraft.world.level.block.Block block) {
        ResourceLocation target = id;
        for (int attempt = 1; attempt <= 50; attempt++) {
            try {
                register.accept(target, block);
                return target;
            } catch (RuntimeException e) {
                LOGGER.error("Legacy Bridge: falha ao registrar {} ({}); tentando outro nome", target, e.toString());
                target = new ResourceLocation(id.getNamespace(), id.getPath() + "_dup" + attempt);
            }
        }
        return null;
    }

    /**
     * Desde a 1.19.3 o inventário criativo e o JEI só listam itens que estão em uma aba criativa. Por isso cada bloco
     * legado entra numa aba moderna equivalente (abas customizadas e blocos sem aba vão para "Blocos de construção").
     */
    static void onBuildTabContents(BuildCreativeModeTabContentsEvent event) {
        for (Variant v : variants()) {
            try {
                if (v.legacy().hasModernFor(v.meta())
                        && event.getTabKey().equals(modernTabFor(v.legacy().legacyCreativeTab()))) {
                    event.accept(v.legacy().modernForMeta(v.meta()));
                }
            } catch (RuntimeException | LinkageError e) {
                LOGGER.error("Legacy Bridge: não foi possível pôr {} na aba criativa", v.id(), e);
            }
        }
    }

    private static ResourceKey<CreativeModeTab> modernTabFor(CreativeTabs tab) {
        if (tab == CreativeTabs.tabRedstone || tab == CreativeTabs.tabTransport) {
            return CreativeModeTabs.REDSTONE_BLOCKS;
        }
        if (tab == CreativeTabs.tabDecorations) {
            return CreativeModeTabs.FUNCTIONAL_BLOCKS;
        }
        if (tab == CreativeTabs.tabTools) {
            return CreativeModeTabs.TOOLS_AND_UTILITIES;
        }
        if (tab == CreativeTabs.tabCombat) {
            return CreativeModeTabs.COMBAT;
        }
        if (tab == CreativeTabs.tabFood) {
            return CreativeModeTabs.FOOD_AND_DRINKS;
        }
        if (tab == CreativeTabs.tabMisc || tab == CreativeTabs.tabMaterials || tab == CreativeTabs.tabBrewing) {
            return CreativeModeTabs.INGREDIENTS;
        }
        return CreativeModeTabs.BUILDING_BLOCKS;
    }
}
