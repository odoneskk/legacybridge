package legacybridge.v1_7_10.cpw.mods.fml.common;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/** Shim de SidedProxy (1.7.10): o campo anotado recebe uma instância da classe do lado (cliente/servidor) atual. */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface SidedProxy {
    String clientSide();

    String serverSide();

    String modId() default "";
}
