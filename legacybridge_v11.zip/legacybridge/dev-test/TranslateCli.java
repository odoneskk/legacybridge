package legacybridge.loader;

import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 * Traduz UM jar legado fora do Minecraft e imprime o relatório de links. Serve para iterar nos shims sem abrir o jogo.
 * Propriedades: lb.in, lb.out, lb.methods, lb.fields, lb.runtime (jar do runtime com os shims); lb.run=true tenta
 * instanciar a classe de entrada (só faz sentido com o runtime de teste, não com o real, que precisa do Minecraft).
 */
public class TranslateCli {
    public static void main(String[] a) throws Exception {
        Path in = Paths.get(System.getProperty("lb.in"));
        Path out = Paths.get(System.getProperty("lb.out"));
        Path runtime = Paths.get(System.getProperty("lb.runtime"));

        List<LegacyModDecl> decls = LegacyJarInspector.inspect(in);
        if (decls.isEmpty()) {
            System.out.println("Nenhum @Mod legado encontrado em " + in);
            return;
        }
        decls.forEach(d -> System.out.println("Mod encontrado: " + d.modId() + " " + d.safeVersion() + " (" + d.generation().label + ") classe " + d.modClass()));

        LegacyGeneration gen = decls.get(0).generation();
        McpMappings mcp = McpMappings.load(Paths.get(System.getProperty("lb.methods")), Paths.get(System.getProperty("lb.fields")));
        ShimIndex shims = ShimIndex.fromJar(runtime, gen);
        System.out.println("Mapeamentos: " + mcp.size() + " | shims no runtime: " + shims.size());

        LinkReport report = new JarTranslator(mcp, shims, Hierarchy.forGeneration(gen)).translate(in, out, decls);
        Path reportFile = TranslationCache.reportFor(out);
        Files.writeString(reportFile, report.render(in.getFileName().toString()), StandardCharsets.UTF_8);
        System.out.println("\n" + report.summary());
        report.topMissingClasses(25, gen.shimPrefix).forEach(c -> System.out.println("  sem shim: " + c));
        System.out.println("Relatório completo: " + reportFile);

        if (Boolean.getBoolean("lb.run")) {
            try (URLClassLoader cl = new URLClassLoader(new URL[]{out.toUri().toURL(), runtime.toUri().toURL()}, null)) {
                for (LegacyModDecl d : decls) {
                    String entry = "legacybridge.gen." + ModIds.sanitize(d.modId()) + ".LegacyEntry";
                    System.out.println("Executando " + entry);
                    Class.forName(entry, true, cl).getDeclaredConstructor().newInstance();
                }
            }
        }
    }
}
