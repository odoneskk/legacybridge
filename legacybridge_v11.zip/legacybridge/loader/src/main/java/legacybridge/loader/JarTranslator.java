package legacybridge.loader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.commons.ClassRemapper;
import org.objectweb.asm.commons.MethodRemapper;
import org.objectweb.asm.commons.Remapper;

/** Traduz um jar legado inteiro: bytecode, recursos, metadados, stubs da API sem shim e a classe de entrada do Forge 1.20.1. */
final class JarTranslator {
    private static final String PACK_MCMETA =
            "{\n  \"pack\": {\n    \"description\": \"Legacy Bridge\",\n    \"pack_format\": 15\n  }\n}\n";
    private static final Pattern LANG = Pattern.compile("^(assets/[^/]+/lang/)([^/]+)\\.lang$");
    private static final Pattern TEXTURES = Pattern.compile("^(assets/[^/]+/textures/)(blocks|items)/(.*)$");

    private final McpMappings mcp;
    private final ShimIndex shims;
    private final Hierarchy hierarchy;

    JarTranslator(McpMappings mcp, ShimIndex shims, Hierarchy hierarchy) {
        this.mcp = mcp;
        this.shims = shims;
        this.hierarchy = hierarchy;
    }

    LinkReport translate(Path in, Path out, List<LegacyModDecl> decls) throws IOException {
        LegacyGeneration gen = decls.get(0).generation();

        Set<String> ownClasses = new HashSet<>();
        try (ZipFile zip = new ZipFile(in.toFile())) {
            for (Enumeration<? extends ZipEntry> en = zip.entries(); en.hasMoreElements(); ) {
                String n = en.nextElement().getName();
                if (n.endsWith(".class")) {
                    ownClasses.add(n.substring(0, n.length() - ".class".length()));
                }
            }
        }
        LegacyRemapper remapper = new LegacyRemapper(gen, mcp, ownClasses);
        Map<String, ShimIndex.Info> ownInfo = new HashMap<>();
        Set<String> annotationTypes = new TreeSet<>();
        Map<String, byte[]> classes = new LinkedHashMap<>();        // nome do arquivo -> bytes (após o 1º remapeamento)
        Map<String, byte[]> resources = new LinkedHashMap<>();

        // Passo 1: remapeia o bytecode do mod (SRG -> MCP, API antiga -> shims) e junta o que o mod usa
        try (ZipFile zip = new ZipFile(in.toFile())) {
            for (Enumeration<? extends ZipEntry> en = zip.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement();
                String name = e.getName();
                if (e.isDirectory() || skip(name)) {
                    continue;
                }
                byte[] data;
                try (InputStream is = zip.getInputStream(e)) {
                    data = is.readAllBytes();
                }
                if (name.endsWith(".class")) {
                    ownInfo.put(name.substring(0, name.length() - ".class".length()), readOwn(data, remapper, gen, annotationTypes));
                    classes.put(name, remapClass(data, remapper));
                } else {
                    Matcher lang = LANG.matcher(name);
                    Matcher tex = TEXTURES.matcher(name);
                    if (lang.matches()) {
                        name = lang.group(1) + lang.group(2).toLowerCase(Locale.ROOT) + ".json";
                        data = LangConverter.toJson(new String(data, StandardCharsets.UTF_8)).getBytes(StandardCharsets.UTF_8);
                    } else if (tex.matches()) {
                        // Achatamento da 1.13: textures/blocks -> textures/block, textures/items -> textures/item.
                        name = tex.group(1) + (tex.group(2).equals("blocks") ? "block" : "item") + "/" + tex.group(3);
                    }
                    resources.putIfAbsent(name, data);
                }
            }
        }

        LinkReport report = LinkReport.build(remapper, shims.withOwn(ownInfo));

        // Passo 2: stubs para a API que ainda não tem shim, e redirecionamento do mod para eles
        Map<String, String> renames = Map.of();
        Map<String, String> fieldRedirects = Map.of();
        Map<String, byte[]> stubs = Map.of();
        if (!report.missingClasses.isEmpty()) {
            String stubRoot = "legacybridge/gen/" + ModIds.sanitize(decls.get(0).modId()) + "/stub/";
            StubSynthesizer.Result r = new StubSynthesizer(gen, shims, hierarchy, stubRoot)
                    .synthesize(report.missingClasses, remapper.refs, ownInfo, annotationTypes);
            renames = r.renames();
            fieldRedirects = r.fieldRedirects();
            stubs = r.classes();
        }
        report.stubbed = stubs.size();

        Files.createDirectories(out.toAbsolutePath().getParent());
        Path tmp = out.resolveSibling(out.getFileName() + ".tmp");
        Set<String> written = new HashSet<>();
        try (ZipOutputStream zo = new ZipOutputStream(Files.newOutputStream(tmp))) {
            put(zo, written, "META-INF/MANIFEST.MF", "Manifest-Version: 1.0\r\n\r\n".getBytes(StandardCharsets.UTF_8));
            for (Map.Entry<String, byte[]> e : resources.entrySet()) {
                put(zo, written, e.getKey(), e.getValue());
            }
            for (Map.Entry<String, byte[]> e : classes.entrySet()) {
                put(zo, written, e.getKey(),
                        renames.isEmpty() && fieldRedirects.isEmpty() ? e.getValue() : redirect(e.getValue(), renames, fieldRedirects));
            }
            for (Map.Entry<String, byte[]> e : stubs.entrySet()) {
                put(zo, written, e.getKey(), e.getValue());
            }
            put(zo, written, "META-INF/mods.toml",
                    ModsTomlWriter.write(decls, in.getFileName().toString()).getBytes(StandardCharsets.UTF_8));
            put(zo, written, "pack.mcmeta", PACK_MCMETA.getBytes(StandardCharsets.UTF_8));
            for (LegacyModDecl m : decls) {
                String id = ModIds.sanitize(m.modId());
                String entry = "legacybridge/gen/" + id + "/LegacyEntry";
                put(zo, written, entry + ".class", LifecycleEntryGenerator.generate(entry, id, m.modClass()));
            }
        }
        Files.move(tmp, out, StandardCopyOption.REPLACE_EXISTING);
        return report;
    }

    /** Remapeia a classe e registra cada membro referenciado COM o opcode (para os stubs saberem o que é estático). */
    private static byte[] remapClass(byte[] bytes, LegacyRemapper lr) {
        ClassReader cr = new ClassReader(bytes);
        ClassWriter cw = new ClassWriter(0);          // sem COMPUTE_FRAMES: não exige carregar classes do jogo
        cr.accept(new ClassRemapper(cw, lr) {
            @Override
            protected MethodVisitor createMethodRemapper(MethodVisitor mv) {
                return new MethodRemapper(api, mv, lr) {
                    @Override
                    public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf) {
                        lr.noteMethod(opcode, owner, name, desc);
                        super.visitMethodInsn(opcode, owner, name, desc, itf);
                    }

                    @Override
                    public void visitFieldInsn(int opcode, String owner, String name, String desc) {
                        lr.noteField(opcode, owner, name, desc);
                        super.visitFieldInsn(opcode, owner, name, desc);
                    }
                };
            }
        }, 0);
        return cw.toByteArray();
    }

    /** 2º remapeamento: nomes das classes sem shim -> stubs gerados; campos que faltam em shims reais -> classe "holder". */
    private static byte[] redirect(byte[] bytes, Map<String, String> renames, Map<String, String> fieldRedirects) {
        ClassReader cr = new ClassReader(bytes);
        ClassWriter cw = new ClassWriter(0);
        Remapper names = new Remapper() {
            @Override
            public String map(String internalName) {
                return renames.getOrDefault(internalName, internalName);
            }
        };
        cr.accept(new ClassRemapper(cw, names) {
            @Override
            protected MethodVisitor createMethodRemapper(MethodVisitor mv) {
                return new MethodRemapper(api, mv, names) {
                    @Override
                    public void visitFieldInsn(int opcode, String owner, String name, String desc) {
                        String holder = fieldRedirects.get(owner + "." + name + ":" + desc);
                        // desc ainda está no vocabulário "relocado" aqui (a chave foi montada assim), então consulta antes de renomear
                        super.visitFieldInsn(opcode, holder != null ? holder : owner, name, desc);
                    }
                };
            }
        }, 0);
        return cw.toByteArray();
    }

    /** Hierarquia e membros de uma classe do mod, já no vocabulário MCP/shim, para o relatório de links e os stubs. */
    private ShimIndex.Info readOwn(byte[] bytes, LegacyRemapper remapper, LegacyGeneration gen, Set<String> annotationTypes) {
        ClassReader cr = new ClassReader(bytes);
        Set<String> methods = new HashSet<>();
        Set<String> fields = new HashSet<>();
        cr.accept(new ClassVisitor(Opcodes.ASM9) {
            @Override
            public AnnotationVisitor visitAnnotation(String desc, boolean visible) {
                noteAnnotation(desc);
                return null;
            }

            @Override
            public MethodVisitor visitMethod(int access, String name, String desc, String sig, String[] ex) {
                methods.add(mcp.method(name) + remapper.mapMethodDesc(desc));
                return new MethodVisitor(Opcodes.ASM9) {
                    @Override
                    public AnnotationVisitor visitAnnotation(String d, boolean visible) {
                        noteAnnotation(d);
                        return null;
                    }
                };
            }

            @Override
            public FieldVisitor visitField(int access, String name, String desc, String sig, Object value) {
                fields.add(mcp.field(name) + ":" + remapper.mapDesc(desc));
                return new FieldVisitor(Opcodes.ASM9) {
                    @Override
                    public AnnotationVisitor visitAnnotation(String d, boolean visible) {
                        noteAnnotation(d);
                        return null;
                    }
                };
            }

            private void noteAnnotation(String desc) {
                if (desc.startsWith("L") && desc.endsWith(";")) {
                    annotationTypes.add(gen.relocate(desc.substring(1, desc.length() - 1)));
                }
            }
        }, ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
        return new ShimIndex.Info(cr.getSuperName(), List.of(cr.getInterfaces()), methods, fields);
    }

    /** Entradas que não devem ir para o jar traduzido (assinaturas ficam inválidas depois de reescrever). */
    private static boolean skip(String name) {
        String n = name.toUpperCase(Locale.ROOT);
        return n.equals("META-INF/MANIFEST.MF")
                || n.equals("META-INF/MODS.TOML")
                || n.equals("PACK.MCMETA")
                || n.equals("MODULE-INFO.CLASS")
                || (n.startsWith("META-INF/") && (n.endsWith(".SF") || n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC")))
                || n.startsWith("META-INF/VERSIONS/");
    }

    private static void put(ZipOutputStream zo, Set<String> written, String name, byte[] data) throws IOException {
        if (!written.add(name)) {
            return;                                   // duplicata (ex.: .json já existia ao lado do .lang)
        }
        zo.putNextEntry(new ZipEntry(name));
        zo.write(data);
        zo.closeEntry();
    }
}
