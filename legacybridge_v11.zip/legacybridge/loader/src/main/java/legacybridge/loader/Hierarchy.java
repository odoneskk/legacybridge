package legacybridge.loader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Hierarquia (superclasse, interfaces, tipo) de classes da API antiga, lida de um arquivo de texto. Serve para o
 * sintetizador de stubs dar aos stubs a herança certa: o verificador de bytecode da JVM recusa passar um EntityPlayer
 * onde se espera um Entity se o stub de EntityPlayer não herdar de Entity.
 */
final class Hierarchy {
    enum Kind { CLASS, INTERFACE, ENUM }

    record Entry(String name, String superName, List<String> interfaces, Kind kind) {}

    private final Map<String, Entry> entries = new HashMap<>();

    static Hierarchy empty() {
        return new Hierarchy();
    }

    /** Carrega legacybridge/hierarchy-&lt;geração&gt;.txt do classpath do loader; vazio se não existir. */
    static Hierarchy forGeneration(LegacyGeneration gen) throws IOException {
        Hierarchy h = new Hierarchy();
        try (InputStream in = Hierarchy.class.getResourceAsStream("/legacybridge/hierarchy-" + gen.label + ".txt")) {
            if (in == null) {
                return h;
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            for (String line; (line = br.readLine()) != null; ) {
                line = line.strip();
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }
                String[] p = line.split("\\|", -1);
                if (p.length < 4) {
                    continue;
                }
                List<String> itfs = new ArrayList<>();
                if (!p[2].equals("-") && !p[2].isEmpty()) {
                    for (String i : p[2].split(",")) {
                        itfs.add(i.strip());
                    }
                }
                Kind kind = switch (p[3].strip()) {
                    case "interface" -> Kind.INTERFACE;
                    case "enum" -> Kind.ENUM;
                    default -> Kind.CLASS;
                };
                h.entries.put(p[0].strip(), new Entry(p[0].strip(), p[1].equals("-") ? null : p[1].strip(), itfs, kind));
            }
        }
        return h;
    }

    /** @param originalName nome da API antiga (ex.: net/minecraft/block/BlockLog), sem prefixo de shim */
    Entry get(String originalName) {
        return entries.get(originalName);
    }

    int size() {
        return entries.size();
    }
}
