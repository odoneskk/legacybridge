package legacybridge.loader;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.commons.Remapper;

/**
 * Gera classes "stub" para a API antiga que ainda não tem shim, para o mod conseguir CARREGAR e rodar até onde der:
 * métodos devolvem valores neutros (0, false, "", lista vazia, uma instância vazia do stub) e nada acontece.
 * Os stubs vão dentro do jar traduzido, num pacote próprio do mod (legacybridge/gen/&lt;mod&gt;/stub/...), porque o mesmo
 * pacote em dois jars (runtime e mod) quebra o carregador de módulos do Forge.
 *
 * <p>O stub só contém o que o mod usa (construtores, métodos, campos referenciados no bytecode dele) e a herança vem
 * da tabela {@link Hierarchy}. Isso NÃO faz o mod funcionar: troca "crash ao carregar" por "não faz nada ali", e o
 * relatório de links continua listando cada stub como pendência a implementar de verdade.
 */
final class StubSynthesizer {
    /** @param fieldRedirects "dono.campo:desc" (relocados) -> classe onde o campo foi criado (campos que faltam em shims reais) */
    record Result(Map<String, String> renames, Map<String, byte[]> classes, Map<String, String> fieldRedirects) {}

    private record MethodSig(String name, String desc, boolean isStatic) {}

    private record FieldSig(String name, String desc, boolean isStatic) {}

    private static final class Spec {
        final String name;                                           // nome relocado (legacybridge/v1_7_10/...)
        String superName;                                            // relocado; null = Object
        final List<String> interfaces = new ArrayList<>();
        Hierarchy.Kind kind = Hierarchy.Kind.CLASS;
        final Set<String> ctors = new LinkedHashSet<>();
        final Map<String, MethodSig> methods = new LinkedHashMap<>();
        final Map<String, FieldSig> fields = new LinkedHashMap<>();

        Spec(String name) {
            this.name = name;
        }
    }

    private static final Spec DECLARED = new Spec("<declarado>");
    private static final Set<String> NEVER_OVERRIDE = Set.of("getClass", "notify", "notifyAll", "wait");
    private static final Set<String> ENUM_FINALS = Set.of("ordinal()I", "name()Ljava/lang/String;", "compareTo(Ljava/lang/Enum;)I",
            "equals(Ljava/lang/Object;)Z", "hashCode()I", "getDeclaringClass()Ljava/lang/Class;", "toString()Ljava/lang/String;");

    private final LegacyGeneration gen;
    private final ShimIndex shims;
    private final Hierarchy hierarchy;
    private final String stubRoot;
    private final Map<String, Spec> specs = new LinkedHashMap<>();
    private Map<String, ShimIndex.Info> own;
    /** Só INVOKEINTERFACE pode pôr um método numa interface: nos outros casos o membro é da classe, não da interface. */
    private boolean interfacesAllowed;
    /** Campos estáticos que faltam em classes de shim de verdade (ex.: Blocks.leaves): vão para uma classe "holder" do mod. */
    private final Map<String, Map<String, FieldSig>> holders = new LinkedHashMap<>();

    StubSynthesizer(LegacyGeneration gen, ShimIndex shims, Hierarchy hierarchy, String stubRoot) {
        this.gen = gen;
        this.shims = shims;
        this.hierarchy = hierarchy;
        this.stubRoot = stubRoot;
    }

    /**
     * @param missing     classes relocadas referenciadas pelo mod e sem shim
     * @param refs        membros referenciados pelo mod (com opcode)
     * @param ownInfo     classes do mod (nomes originais), com hierarquia e membros já no vocabulário MCP/shim
     * @param annotations anotações usadas pelo mod (relocadas): ninguém as lê em tempo de execução, não precisam de stub
     */
    Result synthesize(Collection<String> missing, Collection<LegacyRemapper.Ref> refs,
                      Map<String, ShimIndex.Info> ownInfo, Set<String> annotations) {
        this.own = ownInfo;
        for (String m : missing) {
            if (!annotations.contains(m)) {
                ensureSpec(m);
            }
        }
        // O que as classes do mod "implementam" é interface.
        for (ShimIndex.Info info : ownInfo.values()) {
            for (String itf : info.interfaces()) {
                Spec s = specs.get(gen.relocate(itf));
                if (s != null && s.kind == Hierarchy.Kind.CLASS) {
                    s.kind = Hierarchy.Kind.INTERFACE;
                }
            }
        }
        for (LegacyRemapper.Ref r : refs) {
            attach(r);
        }

        Map<String, String> renames = new LinkedHashMap<>();
        for (Spec s : specs.values()) {
            renames.put(s.name, stubRoot + s.name.substring(gen.shimPrefix.length()));
        }
        Remapper rn = new Remapper() {
            @Override
            public String map(String internalName) {
                return renames.getOrDefault(internalName, internalName);
            }
        };
        Map<String, byte[]> classes = new LinkedHashMap<>();
        for (Spec s : specs.values()) {
            classes.put(renames.get(s.name) + ".class", generate(s, renames, rn));
        }
        Map<String, String> fieldRedirects = new LinkedHashMap<>();
        for (Map.Entry<String, Map<String, FieldSig>> h : holders.entrySet()) {
            String holderName = stubRoot + h.getKey().substring(gen.shimPrefix.length());
            classes.put(holderName + ".class", generateHolder(holderName, h.getValue().values(), rn));
            for (FieldSig f : h.getValue().values()) {
                fieldRedirects.put(h.getKey() + "." + f.name() + ":" + f.desc(), holderName);
            }
        }
        return new Result(renames, classes, fieldRedirects);
    }

    // ---- análise ----

    private Spec ensureSpec(String relocated) {
        if (!relocated.startsWith(gen.shimPrefix) || shims.hasClass(relocated)) {
            return null;                                              // shim de verdade (ou classe fora da API antiga)
        }
        Spec existing = specs.get(relocated);
        if (existing != null) {
            return existing;
        }
        Spec spec = new Spec(relocated);
        specs.put(relocated, spec);
        String original = relocated.substring(gen.shimPrefix.length());
        Hierarchy.Entry entry = hierarchy.get(original);
        if (entry != null) {
            spec.kind = entry.kind();
            if (entry.superName() != null) {
                spec.superName = link(entry.superName());
            }
            for (String itf : entry.interfaces()) {
                String rel = link(itf);
                if (rel != null) {
                    spec.interfaces.add(rel);
                }
            }
        } else if (original.endsWith("Exception") || original.endsWith("Error")) {
            spec.superName = "java/lang/RuntimeException";
        }
        return spec;
    }

    /** Nome relocado de uma classe da hierarquia, garantindo o stub dela se não houver shim. */
    private String link(String original) {
        String rel = gen.relocate(original);
        ensureSpec(rel);
        return rel;
    }

    private void attach(LegacyRemapper.Ref r) {
        boolean isStatic = r.opcode() == Opcodes.INVOKESTATIC || r.opcode() == Opcodes.GETSTATIC
                || r.opcode() == Opcodes.PUTSTATIC;
        interfacesAllowed = r.opcode() == Opcodes.INVOKEINTERFACE;
        Spec target = find(r.owner(), r.name(), r.desc(), r.field(), new java.util.HashSet<>());
        if (target == null) {
            holdMissingStaticField(r, isStatic);
            return;
        }
        if (target == DECLARED) {
            return;
        }
        if (target.kind == Hierarchy.Kind.INTERFACE && r.field() && !isStatic) {
            return;                                           // interface não tem campo de instância
        }
        if (r.field()) {
            target.fields.putIfAbsent(r.name() + ":" + r.desc(), new FieldSig(r.name(), r.desc(), isStatic));
        } else if (r.name().equals("<init>")) {
            target.ctors.add(r.desc());
        } else if (!r.name().equals("<clinit>")) {
            target.methods.putIfAbsent(r.name() + r.desc(), new MethodSig(r.name(), r.desc(), isStatic));
            if (r.opcode() == Opcodes.INVOKEINTERFACE && target.kind == Hierarchy.Kind.CLASS) {
                target.kind = Hierarchy.Kind.INTERFACE;
            }
        }
    }

    /** O stub mais próximo (subindo a hierarquia) que deve receber o membro; DECLARED se já existe; null se não há onde pôr. */
    private Spec find(String cur, String name, String desc, boolean field, Set<String> seen) {
        if (!field && name.equals("<init>")) {
            return findCtorOwner(cur, desc);                  // construtores não são herdados: só vale o dono exato
        }
        if (cur == null || !seen.add(cur)) {
            return null;
        }
        ShimIndex.Info mine = own.get(cur);
        if (mine != null) {
            if (declares(mine, name, desc, field)) {
                return DECLARED;
            }
            Spec r = find(mine.superName(), name, desc, field, seen);
            if (r != null) {
                return r;
            }
            if (interfacesAllowed) {
                for (String itf : mine.interfaces()) {
                    r = find(itf, name, desc, field, seen);
                    if (r != null) {
                        return r;
                    }
                }
            }
            return null;
        }
        String rel = gen.relocate(cur);
        Spec spec = specs.get(rel);
        if (spec != null) {
            return realAncestorDeclares(spec, name, desc, field, new java.util.HashSet<>()) ? DECLARED : spec;
        }
        ShimIndex.Info info = shims.info(rel);
        if (info != null) {
            if (declares(info, name, desc, field)) {
                return DECLARED;
            }
            Spec r = find(info.superName(), name, desc, field, seen);
            if (r != null) {
                return r;
            }
            if (interfacesAllowed) {
                for (String itf : info.interfaces()) {
                    r = find(itf, name, desc, field, seen);
                    if (r != null) {
                        return r;
                    }
                }
            }
        }
        return null;
    }

    /** Campo estático que falta numa classe de shim real: guardamos para criar um holder no mod. */
    private void holdMissingStaticField(LegacyRemapper.Ref r, boolean isStatic) {
        if (!r.field() || !isStatic) {
            return;
        }
        String rel = gen.relocate(r.owner());
        if (shims.info(rel) == null || !rel.startsWith(gen.shimPrefix)) {
            return;
        }
        holders.computeIfAbsent(rel, k -> new LinkedHashMap<>())
                .putIfAbsent(r.name() + ":" + r.desc(), new FieldSig(r.name(), r.desc(), true));
    }

    private Spec findCtorOwner(String cur, String desc) {
        if (cur == null) {
            return null;
        }
        ShimIndex.Info mine = own.get(cur);
        if (mine != null) {
            return DECLARED;                                  // o mod declara os próprios construtores
        }
        String rel = gen.relocate(cur);
        Spec spec = specs.get(rel);
        if (spec != null) {
            return spec;                                      // o stub precisa ter este construtor
        }
        ShimIndex.Info info = shims.info(rel);
        return info != null ? DECLARED : null;
    }

    private boolean realAncestorDeclares(Spec spec, String name, String desc, boolean field, Set<String> seen) {
        List<String> parents = new ArrayList<>(spec.interfaces);
        if (spec.superName != null) {
            parents.add(0, spec.superName);
        }
        for (String p : parents) {
            if (!seen.add(p)) {
                continue;
            }
            Spec ps = specs.get(p);
            if (ps != null) {
                if (realAncestorDeclares(ps, name, desc, field, seen)) {
                    return true;
                }
                continue;
            }
            ShimIndex.Info info = shims.info(p);
            if (info != null && (declares(info, name, desc, field) || realInfoAncestorDeclares(info, name, desc, field, seen))) {
                return true;
            }
        }
        return false;
    }

    private boolean realInfoAncestorDeclares(ShimIndex.Info info, String name, String desc, boolean field, Set<String> seen) {
        List<String> parents = new ArrayList<>(info.interfaces());
        if (info.superName() != null) {
            parents.add(0, info.superName());
        }
        for (String p : parents) {
            ShimIndex.Info pi = shims.info(p);
            if (pi != null && seen.add(p) && (declares(pi, name, desc, field) || realInfoAncestorDeclares(pi, name, desc, field, seen))) {
                return true;
            }
        }
        return false;
    }

    private static boolean declares(ShimIndex.Info info, String name, String desc, boolean field) {
        return field ? info.fields().contains(name + ":" + desc) : info.methods().contains(name + desc);
    }

    // ---- geração ----

    private byte[] generate(Spec s, Map<String, String> renames, Remapper rn) {
        ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        String name = renames.get(s.name);
        String superInternal = s.kind == Hierarchy.Kind.ENUM ? "java/lang/Enum"
                : s.kind == Hierarchy.Kind.INTERFACE ? "java/lang/Object"
                : (s.superName == null ? "java/lang/Object" : rn.map(s.superName));
        String[] itfs = s.interfaces.stream().map(rn::map).toArray(String[]::new);
        int access = switch (s.kind) {
            case INTERFACE -> Opcodes.ACC_PUBLIC | Opcodes.ACC_INTERFACE | Opcodes.ACC_ABSTRACT;
            case ENUM -> Opcodes.ACC_PUBLIC | Opcodes.ACC_FINAL | Opcodes.ACC_SUPER | Opcodes.ACC_ENUM;
            default -> Opcodes.ACC_PUBLIC | Opcodes.ACC_SUPER;
        };
        cw.visit(Opcodes.V17, access, name, null, superInternal, itfs);

        if (s.kind == Hierarchy.Kind.ENUM) {
            generateEnum(cw, s, name, rn);
        } else {
            generateMembers(cw, s, name, superInternal, rn, renames);
        }
        cw.visitEnd();
        return cw.toByteArray();
    }

    /**
     * Classe com os campos estáticos que faltam num shim real (ex.: Blocks.leaves). Blocos viram o bloco vanilla de mesmo
     * nome (VanillaLookup); objetos de tipos com stub viram instâncias vazias; o resto fica no valor padrão.
     */
    private byte[] generateHolder(String name, Collection<FieldSig> fields, Remapper rn) {
        ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        cw.visit(Opcodes.V17, Opcodes.ACC_PUBLIC | Opcodes.ACC_SUPER, name, null, "java/lang/Object", null);
        String blockDesc = "L" + gen.shimPrefix + "net/minecraft/block/Block;";
        MethodVisitor clinit = cw.visitMethod(Opcodes.ACC_STATIC, "<clinit>", "()V", null, null);
        clinit.visitCode();
        for (FieldSig f : fields) {
            String desc = rn.mapDesc(f.desc());
            cw.visitField(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, f.name(), desc, null, null).visitEnd();
            if (f.desc().equals(blockDesc)) {
                clinit.visitLdcInsn(f.name());
                clinit.visitMethodInsn(Opcodes.INVOKESTATIC, "legacybridge/runtime/VanillaLookup", "block",
                        "(Ljava/lang/String;)" + blockDesc, false);
                clinit.visitFieldInsn(Opcodes.PUTSTATIC, name, f.name(), desc);
            } else if (emitValue(clinit, desc, rn)) {
                clinit.visitFieldInsn(Opcodes.PUTSTATIC, name, f.name(), desc);
            }
        }
        clinit.visitInsn(Opcodes.RETURN);
        clinit.visitMaxs(0, 0);
        clinit.visitEnd();
        cw.visitEnd();
        return cw.toByteArray();
    }

    private void generateEnum(ClassWriter cw, Spec s, String name, Remapper rn) {
        String self = "L" + name + ";";
        List<String> constants = new ArrayList<>();
        for (FieldSig f : s.fields.values()) {
            if (f.isStatic() && rn.mapDesc(f.desc()).equals(self)) {
                constants.add(f.name());
                cw.visitField(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC | Opcodes.ACC_FINAL | Opcodes.ACC_ENUM, f.name(), self, null, null).visitEnd();
            }
        }
        cw.visitField(Opcodes.ACC_PRIVATE | Opcodes.ACC_STATIC | Opcodes.ACC_FINAL | Opcodes.ACC_SYNTHETIC, "$VALUES", "[" + self, null, null).visitEnd();

        MethodVisitor ctor = cw.visitMethod(Opcodes.ACC_PRIVATE, "<init>", "(Ljava/lang/String;I)V", null, null);
        ctor.visitCode();
        ctor.visitVarInsn(Opcodes.ALOAD, 0);
        ctor.visitVarInsn(Opcodes.ALOAD, 1);
        ctor.visitVarInsn(Opcodes.ILOAD, 2);
        ctor.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Enum", "<init>", "(Ljava/lang/String;I)V", false);
        ctor.visitInsn(Opcodes.RETURN);
        ctor.visitMaxs(0, 0);
        ctor.visitEnd();

        MethodVisitor clinit = cw.visitMethod(Opcodes.ACC_STATIC, "<clinit>", "()V", null, null);
        clinit.visitCode();
        for (int i = 0; i < constants.size(); i++) {
            clinit.visitTypeInsn(Opcodes.NEW, name);
            clinit.visitInsn(Opcodes.DUP);
            clinit.visitLdcInsn(constants.get(i));
            clinit.visitLdcInsn(i);
            clinit.visitMethodInsn(Opcodes.INVOKESPECIAL, name, "<init>", "(Ljava/lang/String;I)V", false);
            clinit.visitFieldInsn(Opcodes.PUTSTATIC, name, constants.get(i), self);
        }
        clinit.visitLdcInsn(constants.size());
        clinit.visitTypeInsn(Opcodes.ANEWARRAY, name);
        for (int i = 0; i < constants.size(); i++) {
            clinit.visitInsn(Opcodes.DUP);
            clinit.visitLdcInsn(i);
            clinit.visitFieldInsn(Opcodes.GETSTATIC, name, constants.get(i), self);
            clinit.visitInsn(Opcodes.AASTORE);
        }
        clinit.visitFieldInsn(Opcodes.PUTSTATIC, name, "$VALUES", "[" + self);
        clinit.visitInsn(Opcodes.RETURN);
        clinit.visitMaxs(0, 0);
        clinit.visitEnd();

        MethodVisitor values = cw.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "values", "()[" + self, null, null);
        values.visitCode();
        values.visitFieldInsn(Opcodes.GETSTATIC, name, "$VALUES", "[" + self);
        values.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "[" + self, "clone", "()Ljava/lang/Object;", false);
        values.visitTypeInsn(Opcodes.CHECKCAST, "[" + self);
        values.visitInsn(Opcodes.ARETURN);
        values.visitMaxs(0, 0);
        values.visitEnd();

        MethodVisitor valueOf = cw.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "valueOf", "(Ljava/lang/String;)" + self, null, null);
        valueOf.visitCode();
        valueOf.visitLdcInsn(Type.getObjectType(name));
        valueOf.visitVarInsn(Opcodes.ALOAD, 0);
        valueOf.visitMethodInsn(Opcodes.INVOKESTATIC, "java/lang/Enum", "valueOf", "(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;", false);
        valueOf.visitTypeInsn(Opcodes.CHECKCAST, name);
        valueOf.visitInsn(Opcodes.ARETURN);
        valueOf.visitMaxs(0, 0);
        valueOf.visitEnd();

        // métodos estáticos usados pelo mod além de values/valueOf; os de instância herdados de Enum são finais, não se sobrescreve.
        for (MethodSig m : s.methods.values()) {
            String desc = rn.mapMethodDesc(m.desc());
            if (!m.isStatic() || (m.name().equals("values") && desc.startsWith("()")) || m.name().equals("valueOf")) {
                continue;
            }
            emitMethod(cw, Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, m.name(), desc, rn);
        }
    }

    private void generateMembers(ClassWriter cw, Spec s, String name, String superInternal, Remapper rn, Map<String, String> renames) {
        boolean isInterface = s.kind == Hierarchy.Kind.INTERFACE;

        // campos
        List<FieldSig> staticInits = new ArrayList<>();
        for (FieldSig f : s.fields.values()) {
            int acc = Opcodes.ACC_PUBLIC | (f.isStatic() ? Opcodes.ACC_STATIC : 0) | (isInterface ? Opcodes.ACC_FINAL : 0);
            cw.visitField(acc, f.name(), rn.mapDesc(f.desc()), null, null).visitEnd();
            if (f.isStatic()) {
                staticInits.add(f);
            }
        }

        // construtores
        if (!isInterface) {
            Set<String> ctorDescs = new LinkedHashSet<>(s.ctors);
            ctorDescs.add("()V");
            for (String d : ctorDescs) {
                emitCtor(cw, s, superInternal, rn.mapMethodDesc(d), rn, renames);
            }
        }

        // métodos
        for (MethodSig m : s.methods.values()) {
            if (NEVER_OVERRIDE.contains(m.name())) {
                continue;
            }
            String desc = rn.mapMethodDesc(m.desc());
            if (isInterface && !m.isStatic()) {
                cw.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_ABSTRACT, m.name(), desc, null, null).visitEnd();
            } else {
                emitMethod(cw, Opcodes.ACC_PUBLIC | (m.isStatic() ? Opcodes.ACC_STATIC : 0), m.name(), desc, rn);
            }
        }

        // inicialização dos campos estáticos (instância vazia, lista vazia...) para evitar NullPointerException em cadeia
        if (!staticInits.isEmpty()) {
            MethodVisitor mv = cw.visitMethod(Opcodes.ACC_STATIC, "<clinit>", "()V", null, null);
            mv.visitCode();
            for (FieldSig f : staticInits) {
                String desc = rn.mapDesc(f.desc());
                if (emitValue(mv, desc, rn)) {
                    mv.visitFieldInsn(Opcodes.PUTSTATIC, name, f.name(), desc);
                }
            }
            mv.visitInsn(Opcodes.RETURN);
            mv.visitMaxs(0, 0);
            mv.visitEnd();
        }
    }

    private void emitCtor(ClassWriter cw, Spec s, String superInternal, String desc, Remapper rn, Map<String, String> renames) {
        MethodVisitor mv = cw.visitMethod(Opcodes.ACC_PUBLIC, "<init>", desc, null, null);
        mv.visitCode();
        mv.visitVarInsn(Opcodes.ALOAD, 0);
        String superDesc = "()V";
        ShimIndex.Info real = s.superName == null ? null : shims.info(s.superName);
        if (real != null) {
            superDesc = smallestCtor(real);                           // super é um shim de verdade: chama um construtor dele
        }
        pushDefaults(mv, superDesc);
        mv.visitMethodInsn(Opcodes.INVOKESPECIAL, superInternal, "<init>", superDesc, false);
        mv.visitInsn(Opcodes.RETURN);
        mv.visitMaxs(0, 0);
        mv.visitEnd();
    }

    private static String smallestCtor(ShimIndex.Info info) {
        String best = "()V";
        int bestArgs = Integer.MAX_VALUE;
        for (String m : info.methods()) {
            if (m.startsWith("<init>(")) {
                String d = m.substring("<init>".length());
                int n = Type.getArgumentTypes(d).length;
                if (n < bestArgs) {
                    best = d;
                    bestArgs = n;
                }
            }
        }
        return best;
    }

    private static void pushDefaults(MethodVisitor mv, String desc) {
        for (Type t : Type.getArgumentTypes(desc)) {
            switch (t.getSort()) {
                case Type.BOOLEAN, Type.BYTE, Type.CHAR, Type.SHORT, Type.INT -> mv.visitInsn(Opcodes.ICONST_0);
                case Type.LONG -> mv.visitInsn(Opcodes.LCONST_0);
                case Type.FLOAT -> mv.visitInsn(Opcodes.FCONST_0);
                case Type.DOUBLE -> mv.visitInsn(Opcodes.DCONST_0);
                default -> mv.visitInsn(Opcodes.ACONST_NULL);
            }
        }
    }

    private void emitMethod(ClassWriter cw, int access, String name, String desc, Remapper rn) {
        MethodVisitor mv = cw.visitMethod(access, name, desc, null, null);
        mv.visitCode();
        Type ret = Type.getReturnType(desc);
        switch (ret.getSort()) {
            case Type.VOID -> mv.visitInsn(Opcodes.RETURN);
            case Type.BOOLEAN, Type.BYTE, Type.CHAR, Type.SHORT, Type.INT -> {
                mv.visitInsn(Opcodes.ICONST_0);
                mv.visitInsn(Opcodes.IRETURN);
            }
            case Type.LONG -> {
                mv.visitInsn(Opcodes.LCONST_0);
                mv.visitInsn(Opcodes.LRETURN);
            }
            case Type.FLOAT -> {
                mv.visitInsn(Opcodes.FCONST_0);
                mv.visitInsn(Opcodes.FRETURN);
            }
            case Type.DOUBLE -> {
                mv.visitInsn(Opcodes.DCONST_0);
                mv.visitInsn(Opcodes.DRETURN);
            }
            default -> {
                if (!emitValue(mv, ret.getDescriptor(), rn)) {
                    mv.visitInsn(Opcodes.ACONST_NULL);
                }
                mv.visitInsn(Opcodes.ARETURN);
            }
        }
        mv.visitMaxs(0, 0);
        mv.visitEnd();
    }

    /**
     * Empilha um valor "neutro" para o tipo (texto vazio, coleção vazia, array vazio, instância vazia de um stub).
     * @return false se não há valor útil (o chamador usa null)
     */
    private boolean emitValue(MethodVisitor mv, String desc, Remapper rn) {
        switch (desc.charAt(0)) {
            case 'Z', 'B', 'C', 'S', 'I' -> {
                mv.visitInsn(Opcodes.ICONST_0);
                return true;
            }
            case 'J' -> {
                mv.visitInsn(Opcodes.LCONST_0);
                return true;
            }
            case 'F' -> {
                mv.visitInsn(Opcodes.FCONST_0);
                return true;
            }
            case 'D' -> {
                mv.visitInsn(Opcodes.DCONST_0);
                return true;
            }
            case '[' -> {
                Type elem = Type.getType(desc).getElementType();
                int dims = Type.getType(desc).getDimensions();
                mv.visitInsn(Opcodes.ICONST_0);
                if (dims == 1 && elem.getSort() != Type.OBJECT) {
                    int t = switch (elem.getSort()) {
                        case Type.BOOLEAN -> Opcodes.T_BOOLEAN;
                        case Type.BYTE -> Opcodes.T_BYTE;
                        case Type.CHAR -> Opcodes.T_CHAR;
                        case Type.SHORT -> Opcodes.T_SHORT;
                        case Type.INT -> Opcodes.T_INT;
                        case Type.LONG -> Opcodes.T_LONG;
                        case Type.FLOAT -> Opcodes.T_FLOAT;
                        default -> Opcodes.T_DOUBLE;
                    };
                    mv.visitIntInsn(Opcodes.NEWARRAY, t);
                } else {
                    mv.visitTypeInsn(Opcodes.ANEWARRAY, Type.getType(desc.substring(1)).getInternalName());
                }
                return true;
            }
            case 'L' -> {
                String n = desc.substring(1, desc.length() - 1);
                switch (n) {
                    case "java/lang/String" -> {
                        mv.visitLdcInsn("");
                        return true;
                    }
                    case "java/util/List", "java/util/Collection", "java/lang/Iterable", "java/util/ArrayList" -> {
                        return newInstance(mv, "java/util/ArrayList");
                    }
                    case "java/util/Set", "java/util/HashSet" -> {
                        return newInstance(mv, "java/util/HashSet");
                    }
                    case "java/util/Map", "java/util/HashMap" -> {
                        return newInstance(mv, "java/util/HashMap");
                    }
                    default -> {
                        Spec spec = specByStubName(n);
                        if (spec != null && spec.kind == Hierarchy.Kind.CLASS) {
                            return newInstance(mv, n);
                        }
                        return false;
                    }
                }
            }
            default -> {
                return false;
            }
        }
    }

    private static boolean newInstance(MethodVisitor mv, String internal) {
        mv.visitTypeInsn(Opcodes.NEW, internal);
        mv.visitInsn(Opcodes.DUP);
        mv.visitMethodInsn(Opcodes.INVOKESPECIAL, internal, "<init>", "()V", false);
        return true;
    }

    private Spec specByStubName(String stubInternal) {
        if (!stubInternal.startsWith(stubRoot)) {
            return null;
        }
        return specs.get(gen.shimPrefix + stubInternal.substring(stubRoot.length()));
    }
}
