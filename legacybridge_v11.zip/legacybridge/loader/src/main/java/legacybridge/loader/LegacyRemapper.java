package legacybridge.loader;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

import org.objectweb.asm.commons.Remapper;

/**
 * Faz duas coisas ao mesmo tempo, em todo o bytecode do mod:
 * <ol>
 *   <li>realoca classes da API antiga para o pacote de shims;</li>
 *   <li>troca nomes SRG (func_/field_) pelos nomes MCP que os shims usam.</li>
 * </ol>
 * Enquanto mapeia, registra as classes realocadas e todo membro referenciado (dono ORIGINAL + nome/descritor
 * já traduzidos), para o relatório de links resolver depois, subindo a hierarquia.
 */
final class LegacyRemapper extends Remapper {
    record MemberRef(String owner,  // nome original (pré-realocação)
                      String name, String desc, boolean field) {}

    private final LegacyGeneration gen;
    private final McpMappings mcp;
    private final Set<String> ownClasses;

    /** Referência a membro com o opcode usado (para saber se é estático/interface); dono = nome ORIGINAL. */
    record Ref(String owner, String name, String desc, boolean field, int opcode) {}

    final Set<Ref> refs = new LinkedHashSet<>();
    final Set<String> shimClassRefs = new TreeSet<>();
    final Set<MemberRef> memberRefs = new LinkedHashSet<>();

    LegacyRemapper(LegacyGeneration gen, McpMappings mcp, Set<String> ownClasses) {
        this.gen = gen;
        this.mcp = mcp;
        this.ownClasses = ownClasses;
    }

    @Override
    public String map(String internalName) {
        if (ownClasses.contains(internalName)) {
            return internalName;                      // classe do próprio mod: nunca realocar
        }
        String relocated = gen.relocate(internalName);
        if (!relocated.equals(internalName)) {
            shimClassRefs.add(relocated);
        }
        return relocated;
    }

    @Override
    public String mapMethodName(String owner, String name, String descriptor) {
        String mapped = mcp.method(name);
        if (!owner.startsWith("[")) {
            memberRefs.add(new MemberRef(owner, mapped, mapDesc(descriptor), false));
        }
        return mapped;
    }

    @Override
    public String mapFieldName(String owner, String name, String descriptor) {
        String mapped = mcp.field(name);
        if (!owner.startsWith("[")) {
            memberRefs.add(new MemberRef(owner, mapped, mapDesc(descriptor), true));
        }
        return mapped;
    }

    void noteMethod(int opcode, String owner, String name, String descriptor) {
        if (!owner.startsWith("[")) {
            refs.add(new Ref(owner, mcp.method(name), mapDesc(descriptor), false, opcode));
        }
    }

    void noteField(int opcode, String owner, String name, String descriptor) {
        if (!owner.startsWith("[")) {
            refs.add(new Ref(owner, mcp.field(name), mapDesc(descriptor), true, opcode));
        }
    }
}
