package legacybridge.runtime;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import legacybridge.v1_7_10.net.minecraft.block.Block;
import legacybridge.v1_7_10.net.minecraft.creativetab.CreativeTabs;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Na 1.7.10 qualquer coisa registra no preInit; na 1.20.1 só dentro do RegisterEvent. Por isso o preInit legado roda
 * no primeiro RegisterEvent, e os shims (ex.: GameRegistry.registerBlock) só enfileiram aqui. O Block moderno de cada
 * bloco legado só é criado ({@link Block#modern()}) quando o registro correspondente é aberto.
 *
 * <p>TODO: itens, entidades (EntityType + atributos + spawn placement + renderer), biomas e spawns
 * (estes são dados/JSON na 1.20.1, ver README), ItemBlock customizado, abas criativas
 * (BuildCreativeModeTabContentsEvent), receitas.
 */
public final class PendingRegistry {
    private static final Logger LOGGER = LogManager.getLogger("legacybridge");
    private static final Map<ResourceLocation, Block> BLOCKS = new LinkedHashMap<>();
    private static int ignoredRecipes;

    private PendingRegistry() {}

    public static void queueBlock(String name, Block block) {
        String path = name.toLowerCase(Locale.ROOT);
        BLOCKS.put(new ResourceLocation(LegacyBootstrap.currentModId(), path), block);
    }

    public static void ignoredRecipe() {
        ignoredRecipes++;
    }

    static int ignoredRecipes() {
        return ignoredRecipes;
    }

    static void onRegister(RegisterEvent event) {
        // Primeiro RegisterEvent de qualquer registro: os registros estão abertos, então o preInit legado só pode
        // rodar agora. As chamadas seguintes não fazem nada (a flag fica no LegacyBootstrap).
        LegacyBootstrap.runPreInit();
        event.register(ForgeRegistries.Keys.BLOCKS, helper -> {
            BLOCKS.forEach((id, block) -> {
                helper.register(id, block.modern());
                LOGGER.info("Legacy Bridge: bloco registrado: {}", id);
            });
            LOGGER.info("Legacy Bridge: {} bloco(s) de mods legados registrado(s)", BLOCKS.size());
        });
        event.register(ForgeRegistries.Keys.ITEMS,
                helper -> BLOCKS.forEach((id, block) -> helper.register(id, new BlockItem(block.modern(), new Item.Properties()))));
    }

    /**
     * Desde a 1.19.3 o inventário criativo e o JEI só listam itens que estão em uma aba criativa. Por isso cada bloco
     * legado entra numa aba moderna equivalente (abas customizadas e blocos sem aba vão para "Blocos de construção").
     */
    static void onBuildTabContents(BuildCreativeModeTabContentsEvent event) {
        for (Block legacy : BLOCKS.values()) {
            if (event.getTabKey().equals(modernTabFor(legacy.legacyCreativeTab()))) {
                event.accept(legacy.modern());
            }
        }
    }

    private static ResourceKey<CreativeModeTab> modernTabFor(CreativeTabs tab) {
        if (tab == CreativeTabs.tabRedstone || tab == CreativeTabs.tabTransport) {
            return CreativeModeTabs.REDSTONE_BLOCKS;
        }
        if (tab == CreativeTabs.tabDecorations) {
            return CreativeModeTabs.FUNCTIONAL_BLOCKS;
        }
        if (tab == CreativeTabs.tabTools) {
            return CreativeModeTabs.TOOLS_AND_UTILITIES;
        }
        if (tab == CreativeTabs.tabCombat) {
            return CreativeModeTabs.COMBAT;
        }
        if (tab == CreativeTabs.tabFood) {
            return CreativeModeTabs.FOOD_AND_DRINKS;
        }
        if (tab == CreativeTabs.tabMisc || tab == CreativeTabs.tabMaterials || tab == CreativeTabs.tabBrewing) {
            return CreativeModeTabs.INGREDIENTS;
        }
        return CreativeModeTabs.BUILDING_BLOCKS;
    }
}
