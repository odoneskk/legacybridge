package legacybridge.runtime;

import java.util.ArrayList;
import java.util.List;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import legacybridge.v1_7_10.cpw.mods.fml.common.event.FMLInitializationEvent;
import legacybridge.v1_7_10.cpw.mods.fml.common.event.FMLPostInitializationEvent;
import legacybridge.v1_7_10.cpw.mods.fml.common.event.FMLPreInitializationEvent;

/**
 * Liga o mundo antigo ao novo. O construtor da classe de entrada gerada ({@code @Mod("id")}) chama
 * {@link #boot}; preInit roda ali mesmo (antes de os registros abrirem, então blocos/itens enfileirados
 * entram no RegisterEvent), e init/postInit rodam no FMLCommonSetupEvent.
 *
 * <p>Por enquanto só a geração 1.7.10.
 */
public final class LegacyBootstrap {
    private static final Logger LOGGER = LogManager.getLogger("legacybridge");
    private static final List<LegacyModContainer> MODS = new ArrayList<>();
    private static String currentModId = "minecraft";

    private LegacyBootstrap() {}

    /** Equivalente ao Loader.instance().activeModContainer().getModId() da 1.7.10. */
    public static String currentModId() {
        return currentModId;
    }

    /** Chamado pela classe de entrada gerada. */
    public static void boot(Class<?> anchor, String modId, String legacyClassName) {
        String previous = currentModId;
        currentModId = modId;
        try {
            Class<?> cls = Class.forName(legacyClassName, true, anchor.getClassLoader());
            var ctor = cls.getDeclaredConstructor();
            ctor.setAccessible(true);
            LegacyModContainer container = new LegacyModContainer(modId, ctor.newInstance());
            MODS.add(container);
            container.injectInstance();
            LOGGER.info("Legacy Bridge: preInit de {}", modId);
            container.fire(new FMLPreInitializationEvent(modId));
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Legacy Bridge: não foi possível iniciar o mod legado " + modId, e);
        } finally {
            currentModId = previous;
        }
    }

    static void onCommonSetup(FMLCommonSetupEvent event) {
        for (LegacyModContainer c : MODS) {
            currentModId = c.modId();
            c.fire(new FMLInitializationEvent());
        }
        event.enqueueWork(() -> {
            for (LegacyModContainer c : MODS) {
                currentModId = c.modId();
                c.fire(new FMLPostInitializationEvent());
            }
            currentModId = "minecraft";
        });
    }
}
