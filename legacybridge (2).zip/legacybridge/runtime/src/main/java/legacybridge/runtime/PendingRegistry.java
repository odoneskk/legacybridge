package legacybridge.runtime;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

/**
 * Na 1.7.10 qualquer coisa registra no preInit; na 1.20.1 só dentro do RegisterEvent.
 * Os shims (ex.: GameRegistry.registerBlock) só enfileiram aqui; o flush acontece no evento certo.
 *
 * <p>TODO: itens, entidades (EntityType + atributos + spawn placement + renderer), biomas e spawns
 * (estes são dados/JSON na 1.20.1, ver README), blocos com ItemBlock customizado, abas criativas
 * (BuildCreativeModeTabContentsEvent).
 */
public final class PendingRegistry {
    private static final Map<ResourceLocation, Block> BLOCKS = new LinkedHashMap<>();

    private PendingRegistry() {}

    public static void queueBlock(String name, Block block) {
        String path = name.toLowerCase(Locale.ROOT);
        BLOCKS.put(new ResourceLocation(LegacyBootstrap.currentModId(), path), block);
    }

    static void onRegister(RegisterEvent event) {
        event.register(ForgeRegistries.Keys.BLOCKS, helper -> BLOCKS.forEach(helper::register));
        event.register(ForgeRegistries.Keys.ITEMS,
                helper -> BLOCKS.forEach((id, block) -> helper.register(id, new BlockItem(block, new Item.Properties()))));
    }
}
