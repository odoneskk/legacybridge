package legacybridge.v1_7_10.net.minecraft.block;

import legacybridge.v1_7_10.net.minecraft.block.material.Material;
import net.minecraft.world.level.block.state.BlockBehaviour;

/**
 * Shim de Block (1.7.10) sobre o Block moderno. Os "setters encadeados" da 1.7.10 guardam valores;
 * as propriedades do Block moderno são finais e definidas no construtor, então aplicá-las de verdade
 * exige um Access Transformer (BlockBehaviour$BlockStateBase.destroySpeed e explosionResistance)
 * e atualizar todos os estados em getStateDefinition().getPossibleStates(). Ainda NÃO feito.
 */
public class Block extends net.minecraft.world.level.block.Block {
    private final Material legacyMaterial;
    private String unlocalizedName = "";
    private float legacyHardness;
    private float legacyResistance;

    public Block(Material material) {
        super(BlockBehaviour.Properties.of());
        this.legacyMaterial = material;
    }

    public Block setBlockName(String name) {
        this.unlocalizedName = name;
        return this;
    }

    public Block setHardness(float hardness) {
        this.legacyHardness = hardness;
        return this;
    }

    public Block setResistance(float resistance) {
        this.legacyResistance = resistance * 0.6F;    // 1.7.10 guardava r*3 e usava /5 nas explosões
        return this;
    }

    public Material legacyMaterial() {
        return legacyMaterial;
    }

    public float legacyHardness() {
        return legacyHardness;
    }

    public float legacyResistance() {
        return legacyResistance;
    }

    /** A chave de tradução antiga é "tile.<nome>"; o conversor de .lang emite essa chave (sem o ".name"). */
    @Override
    public String getDescriptionId() {
        return unlocalizedName.isEmpty() ? super.getDescriptionId() : "tile." + unlocalizedName;
    }
}
