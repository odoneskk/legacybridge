package legacybridge.v1_7_10.cpw.mods.fml.common.registry;

import legacybridge.runtime.PendingRegistry;
import legacybridge.v1_7_10.net.minecraft.block.Block;

/** Shim de GameRegistry (1.7.10). Só enfileira; o registro real acontece no RegisterEvent. */
public class GameRegistry {
    public static Block registerBlock(Block block, String name) {
        PendingRegistry.queueBlock(name, block);
        return block;
    }

    // TODO: registerBlock(Block, Class<? extends ItemBlock>, String), registerItem, registerTileEntity,
    //       addRecipe/addShapedRecipe/addSmelting (viram JSON de receita), registerWorldGenerator (ver README).
}
