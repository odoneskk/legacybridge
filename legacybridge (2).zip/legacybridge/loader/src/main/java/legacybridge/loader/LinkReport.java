package legacybridge.loader;

import java.util.SortedSet;
import java.util.TreeSet;

/**
 * Lista o que o mod traduzido usa da API antiga e os shims ainda não têm. É a lista de tarefas para
 * implementar shims: ordene mods reais por quantas pendências têm e ataque pelos mais simples.
 */
final class LinkReport {
    final SortedSet<String> missingClasses = new TreeSet<>();
    final SortedSet<String> missingMembers = new TreeSet<>();
    int unverified;
    int resolved;

    static LinkReport build(LegacyRemapper remapper, ShimIndex shims) {
        LinkReport r = new LinkReport();
        for (String cls : remapper.shimClassRefs) {
            if (!shims.hasClass(cls)) {
                r.missingClasses.add(cls);
            }
        }
        for (LegacyRemapper.MemberRef m : remapper.memberRefs) {
            ShimIndex.Probe probe = new ShimIndex.Probe();
            switch (shims.check(m.owner(), m.name(), m.desc(), m.field(), probe)) {
                case OK -> r.resolved++;
                case UNVERIFIED -> r.unverified++;
                case MISSING -> r.missingMembers.add((probe.nearestShim != null ? probe.nearestShim : m.owner())
                        + (m.field() ? " field " : " ") + m.name() + (m.field() ? "" : m.desc()));
                case IRRELEVANT -> { }
            }
        }
        return r;
    }

    boolean clean() {
        return missingClasses.isEmpty() && missingMembers.isEmpty();
    }

    String summary() {
        return missingClasses.size() + " classes e " + missingMembers.size() + " membros sem shim; "
                + resolved + " referências resolvidas, " + unverified + " não verificáveis";
    }

    String render(String jarName) {
        StringBuilder sb = new StringBuilder();
        sb.append("Legacy Bridge - relatório de links: ").append(jarName).append('\n');
        sb.append(summary()).append("\n\n");
        sb.append("== Classes da API antiga sem shim ==\n");
        missingClasses.forEach(c -> sb.append(c).append('\n'));
        sb.append("\n== Métodos/campos sem shim (dono, nome+descritor) ==\n");
        missingMembers.forEach(m -> sb.append(m).append('\n'));
        sb.append("\n(\"não verificáveis\" = o shim herda de uma classe moderna; só dá para confirmar rodando.)\n");
        return sb.toString();
    }
}
