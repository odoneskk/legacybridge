package legacybridge.runtime;
import legacybridge.v1_7_10.cpw.mods.fml.common.event.FMLPreInitializationEvent;
public class LegacyBootstrap {
  public static void boot(Class<?> anchor, String modId, String cls) {
    try {
      System.out.println("  [stub] boot " + modId + " -> " + cls);
      Object inst = Class.forName(cls, true, anchor.getClassLoader()).getDeclaredConstructor().newInstance();
      LegacyModContainer c = new LegacyModContainer(modId, inst);
      c.injectInstance();
      c.fire(new FMLPreInitializationEvent(modId));
    } catch (Exception e) { throw new RuntimeException(e); }
  }
}
