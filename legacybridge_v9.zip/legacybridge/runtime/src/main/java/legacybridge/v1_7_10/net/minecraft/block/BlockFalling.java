package legacybridge.v1_7_10.net.minecraft.block;

import legacybridge.v1_7_10.net.minecraft.block.material.Material;

/** Shim de BlockFalling (1.7.10). */
public class BlockFalling extends Block {
    public BlockFalling() {
        super(Material.sand);
    }

    public BlockFalling(Material material) {
        super(material);
    }
}
