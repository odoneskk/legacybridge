package legacybridge.v1_7_10.net.minecraft.item;

import legacybridge.v1_7_10.net.minecraft.block.Block;

/**
 * Shim de ItemStack (1.7.10): só guarda o que o mod passou. O "damage" (metadata) NÃO existe no ItemStack
 * moderno; quando a conversão de receitas/itens for feita, ele vira variante ou NBT.
 */
public class ItemStack {
    public int stackSize;
    private final Item item;
    private final Block block;
    private final int damage;

    public ItemStack(Block block) {
        this(block, 1, 0);
    }

    public ItemStack(Block block, int count) {
        this(block, count, 0);
    }

    public ItemStack(Block block, int count, int damage) {
        this.block = block;
        this.item = null;
        this.stackSize = count;
        this.damage = damage;
    }

    public ItemStack(Item item) {
        this(item, 1, 0);
    }

    public ItemStack(Item item, int count) {
        this(item, count, 0);
    }

    public ItemStack(Item item, int count, int damage) {
        this.item = item;
        this.block = null;
        this.stackSize = count;
        this.damage = damage;
    }

    public Item getItem() {
        return item;
    }

    public int getItemDamage() {
        return damage;
    }

    public Block legacyBlock() {
        return block;
    }
}
