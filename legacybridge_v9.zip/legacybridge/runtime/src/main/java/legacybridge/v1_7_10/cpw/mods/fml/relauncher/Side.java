package legacybridge.v1_7_10.cpw.mods.fml.relauncher;

/** Shim de Side (1.7.10). */
public enum Side {
    CLIENT, SERVER;

    public boolean isClient() {
        return this == CLIENT;
    }

    public boolean isServer() {
        return this == SERVER;
    }
}
