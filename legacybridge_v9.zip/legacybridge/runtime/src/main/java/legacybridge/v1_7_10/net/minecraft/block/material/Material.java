package legacybridge.v1_7_10.net.minecraft.block.material;

/** Shim de Material (1.7.10). Na 1.20 o Material não existe mais; aqui ele só carrega o "tipo". */
public class Material {
    public static final Material rock = new Material("rock");
    public static final Material iron = new Material("iron");
    public static final Material wood = new Material("wood");
    public static final Material ground = new Material("ground");
    public static final Material glass = new Material("glass");
    public static final Material grass = new Material("grass");
    public static final Material sand = new Material("sand");
    public static final Material cloth = new Material("cloth");

    private final String id;

    public Material(String id) {
        this.id = id;
    }

    public String id() {
        return id;
    }
}
