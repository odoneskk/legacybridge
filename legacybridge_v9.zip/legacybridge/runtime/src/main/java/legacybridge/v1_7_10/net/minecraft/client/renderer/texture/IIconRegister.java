package legacybridge.v1_7_10.net.minecraft.client.renderer.texture;

import legacybridge.v1_7_10.net.minecraft.util.IIcon;

/** Shim de IIconRegister (1.7.10). Ninguém chama registerBlockIcons ainda; as texturas vêm dos modelos JSON. */
public interface IIconRegister {
    IIcon registerIcon(String name);
}
