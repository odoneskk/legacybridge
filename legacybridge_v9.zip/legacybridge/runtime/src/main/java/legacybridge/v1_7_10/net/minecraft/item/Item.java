package legacybridge.v1_7_10.net.minecraft.item;

import legacybridge.v1_7_10.net.minecraft.block.Block;
import legacybridge.v1_7_10.net.minecraft.creativetab.CreativeTabs;

/** Shim de Item (1.7.10), objeto comum (o Item moderno só será criado ao registrar). Mínimo por enquanto. */
public class Item {
    private String unlocalizedName = "";
    private boolean hasSubtypes;
    private int maxStackSize = 64;
    private CreativeTabs creativeTab;

    public Item() {
    }

    public static Item getItemFromBlock(Block block) {
        return block.legacyItem();
    }

    public Item setUnlocalizedName(String name) {
        this.unlocalizedName = name;
        return this;
    }

    public String getUnlocalizedName() {
        return "item." + unlocalizedName;
    }

    public String getUnlocalizedName(ItemStack stack) {
        return getUnlocalizedName();
    }

    public Item setHasSubtypes(boolean hasSubtypes) {
        this.hasSubtypes = hasSubtypes;
        return this;
    }

    public boolean getHasSubtypes() {
        return hasSubtypes;
    }

    public Item setMaxStackSize(int size) {
        this.maxStackSize = size;
        return this;
    }

    public Item setCreativeTab(CreativeTabs tab) {
        this.creativeTab = tab;
        return this;
    }

    public CreativeTabs getCreativeTab() {
        return creativeTab;
    }

    public int getMetadata(int damage) {
        return 0;
    }
}
