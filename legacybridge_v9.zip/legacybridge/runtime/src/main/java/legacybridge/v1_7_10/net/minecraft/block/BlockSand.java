package legacybridge.v1_7_10.net.minecraft.block;

/** Shim de BlockSand (1.7.10). Existe porque Blocks.sand tem esse tipo. */
public class BlockSand extends BlockFalling {
    public BlockSand() {
        super();
    }
}
