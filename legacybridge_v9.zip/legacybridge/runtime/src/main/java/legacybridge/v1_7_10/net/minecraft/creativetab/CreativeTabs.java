package legacybridge.v1_7_10.net.minecraft.creativetab;

import legacybridge.v1_7_10.net.minecraft.item.Item;

/** Shim de CreativeTabs (1.7.10). TODO: ligar às abas modernas (BuildCreativeModeTabContentsEvent). */
public class CreativeTabs {
    public static final CreativeTabs tabBlock = new CreativeTabs("buildingBlocks");
    public static final CreativeTabs tabDecorations = new CreativeTabs("decorations");
    public static final CreativeTabs tabRedstone = new CreativeTabs("redstone");
    public static final CreativeTabs tabTransport = new CreativeTabs("transportation");
    public static final CreativeTabs tabMisc = new CreativeTabs("misc");
    public static final CreativeTabs tabAllSearch = new CreativeTabs("search");
    public static final CreativeTabs tabFood = new CreativeTabs("food");
    public static final CreativeTabs tabTools = new CreativeTabs("tools");
    public static final CreativeTabs tabCombat = new CreativeTabs("combat");
    public static final CreativeTabs tabBrewing = new CreativeTabs("brewing");
    public static final CreativeTabs tabMaterials = new CreativeTabs("materials");

    private final String label;

    public CreativeTabs(String label) {
        this.label = label;
    }

    public String getTabLabel() {
        return label;
    }

    /** Na 1.7.10 é abstrato; mods criam subclasses anônimas que o sobrescrevem. */
    public Item getTabIconItem() {
        return null;
    }
}
