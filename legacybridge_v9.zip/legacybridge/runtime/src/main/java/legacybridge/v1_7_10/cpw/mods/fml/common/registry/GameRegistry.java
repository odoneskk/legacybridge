package legacybridge.v1_7_10.cpw.mods.fml.common.registry;

import legacybridge.runtime.PendingRegistry;
import legacybridge.v1_7_10.net.minecraft.block.Block;
import legacybridge.v1_7_10.net.minecraft.item.ItemBlock;
import legacybridge.v1_7_10.net.minecraft.item.ItemStack;

/** Shim de GameRegistry (1.7.10). Só enfileira; o registro real acontece no RegisterEvent. */
public class GameRegistry {
    public static Block registerBlock(Block block, String name) {
        PendingRegistry.queueBlock(name, block);
        return block;
    }

    /** O ItemBlock customizado só é usado para descobrir os nomes de cada metadata (registramos um BlockItem comum). */
    public static Block registerBlock(Block block, Class<? extends ItemBlock> itemClass, String name) {
        block.setItemClass(itemClass);
        PendingRegistry.queueBlock(name, block);
        return block;
    }

    /** Guardada e convertida em receita JSON ao montar o data pack gerado (ver LegacyGeneratedPacks). */
    public static void addRecipe(ItemStack output, Object... params) {
        PendingRegistry.queueRecipe(true, output, params);
    }

    public static void addShapelessRecipe(ItemStack output, Object... params) {
        PendingRegistry.queueRecipe(false, output, params);
    }

    // TODO: registerItem, registerTileEntity, addSmelting, registerWorldGenerator (ver README).
}
