package legacybridge.v1_7_10.net.minecraft.block;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import legacybridge.runtime.LegacyBlockAdapter;
import legacybridge.runtime.LegacyPaneBlock;
import legacybridge.v1_7_10.net.minecraft.block.material.Material;
import legacybridge.v1_7_10.net.minecraft.client.renderer.texture.IIconRegister;
import legacybridge.v1_7_10.net.minecraft.creativetab.CreativeTabs;
import legacybridge.v1_7_10.net.minecraft.item.Item;
import legacybridge.v1_7_10.net.minecraft.item.ItemBlock;
import legacybridge.v1_7_10.net.minecraft.item.ItemStack;
import legacybridge.v1_7_10.net.minecraft.util.IIcon;
import net.minecraft.world.level.block.state.BlockBehaviour;

/**
 * Shim de Block (1.7.10): um objeto COMUM, que não herda do Block moderno.
 *
 * <p>Por quê: o Block moderno registra a si mesmo no construtor e o Minecraft exige que todo Block construído seja
 * registrado (senão os registros não congelam), além de ter propriedades finais. Aqui os "setters encadeados" da 1.7.10
 * só guardam valores; o Block moderno ({@link LegacyBlockAdapter}) é criado por {@link #modern()} quando o bloco é
 * de fato registrado, já com dureza, resistência, som e luz corretos.
 */
public class Block {
    /** Shim de Block.SoundType (1.7.10). */
    public static class SoundType {
        public final String soundName;
        public final float volume;
        public final float frequency;

        public SoundType(String name, float volume, float frequency) {
            this.soundName = name;
            this.volume = volume;
            this.frequency = frequency;
        }
    }

    public static final SoundType soundTypeStone = new SoundType("stone", 1.0F, 1.0F);
    public static final SoundType soundTypeWood = new SoundType("wood", 1.0F, 1.0F);
    public static final SoundType soundTypeGravel = new SoundType("gravel", 1.0F, 1.0F);
    public static final SoundType soundTypeGrass = new SoundType("grass", 1.0F, 1.0F);
    public static final SoundType soundTypePiston = new SoundType("stone", 1.0F, 1.0F);
    public static final SoundType soundTypeMetal = new SoundType("stone", 1.0F, 1.5F);
    public static final SoundType soundTypeGlass = new SoundType("stone", 1.0F, 1.0F);
    public static final SoundType soundTypeCloth = new SoundType("cloth", 1.0F, 1.0F);
    public static final SoundType soundTypeSand = new SoundType("sand", 1.0F, 1.0F);
    public static final SoundType soundTypeSnow = new SoundType("snow", 1.0F, 1.0F);
    public static final SoundType soundTypeLadder = new SoundType("ladder", 1.0F, 1.0F);
    public static final SoundType soundTypeAnvil = new SoundType("anvil", 0.3F, 1.0F);

    private final Material material;
    private String unlocalizedName = "";
    private float blockHardness;
    private float blockResistance;          // no "espaço" da 1.7.10: setResistance(r) guarda r*3; explosão usa isto/5
    private int lightValue;
    private SoundType stepSound = soundTypeStone;
    private CreativeTabs creativeTab;
    private String textureName = "";
    private int lightOpacity;
    private boolean tickRandomly;
    private float minX, minY, minZ, maxX = 1.0F, maxY = 1.0F, maxZ = 1.0F;
    private ItemBlock legacyItem;
    private Class<? extends ItemBlock> itemClass;
    private ItemBlock customItem;
    private List<Integer> subMetas;
    /** Blocos vanilla embrulhados por Blocks.* (um só, ou um por metadata/cor). */
    private net.minecraft.world.level.block.Block vanilla;
    private net.minecraft.world.level.block.Block[] vanillaByMeta;
    /** Blocos modernos criados para este bloco legado, um por metadata (ver README: "metadata vira bloco"). */
    private final Map<Integer, net.minecraft.world.level.block.Block> created = new LinkedHashMap<>();

    public Block(Material material) {
        this.material = material;
    }

    // ---- "setters encadeados" da 1.7.10 ----

    public Block setBlockName(String name) {
        this.unlocalizedName = name;
        return this;
    }

    public Block setHardness(float hardness) {
        this.blockHardness = hardness;
        if (this.blockResistance < hardness * 5.0F) {
            this.blockResistance = hardness * 5.0F;
        }
        return this;
    }

    public Block setResistance(float resistance) {
        this.blockResistance = resistance * 3.0F;
        return this;
    }

    public Block setBlockUnbreakable() {
        return setHardness(-1.0F);
    }

    public Block setLightLevel(float level) {
        this.lightValue = (int) (15.0F * level);
        return this;
    }

    public Block setStepSound(SoundType sound) {
        this.stepSound = sound;
        return this;
    }

    public Block setCreativeTab(CreativeTabs tab) {
        this.creativeTab = tab;
        return this;
    }

    public Block setBlockTextureName(String name) {
        this.textureName = name;
        return this;
    }

    /** TODO: aplicar de verdade (na 1.20 é Properties.noOcclusion/getLightBlock). Por enquanto só guarda. */
    public Block setLightOpacity(int opacity) {
        this.lightOpacity = opacity;
        return this;
    }

    public Block setTickRandomly(boolean tickRandomly) {
        this.tickRandomly = tickRandomly;
        return this;
    }

    public Block disableStats() {
        return this;
    }

    /** TODO: virar VoxelShape (getShape). Por enquanto só guarda os limites (0..1). */
    public void setBlockBounds(float minX, float minY, float minZ, float maxX, float maxY, float maxZ) {
        this.minX = minX;
        this.minY = minY;
        this.minZ = minZ;
        this.maxX = maxX;
        this.maxY = maxY;
        this.maxZ = maxZ;
    }

    public Material getMaterial() {
        return material;
    }

    /** O "Item" legado deste bloco (Item.getItemFromBlock). */
    public ItemBlock legacyItem() {
        if (legacyItem == null) {
            legacyItem = new ItemBlock(this);
        }
        return legacyItem;
    }

    // ---- métodos que mods costumam sobrescrever (valores padrão da 1.7.10) ----

    public String getTextureName() {
        return textureName;
    }

    public String getUnlocalizedName() {
        return "tile." + unlocalizedName;
    }

    public IIcon getIcon(int side, int meta) {
        return null;
    }

    public void registerBlockIcons(IIconRegister register) {
    }

    public int damageDropped(int meta) {
        return 0;
    }

    public boolean isOpaqueCube() {
        return true;
    }

    public boolean renderAsNormalBlock() {
        return true;
    }

    public int getRenderBlockPass() {
        return 0;
    }

    // ---- acesso para o runtime ----

    public Material legacyMaterial() {
        return material;
    }

    public String legacyTextureName() {
        return textureName;
    }

    public CreativeTabs legacyCreativeTab() {
        return creativeTab;
    }

    /** Usado por Blocks.*: o bloco vanilla correspondente já existe, não criamos outro. */
    public static Block wrapVanilla(Material material, net.minecraft.world.level.block.Block vanilla) {
        Block b = new Block(material);
        b.vanilla = vanilla;
        return b;
    }

    /** Como wrapVanilla, mas para subclasses (os campos de Blocks.* têm tipos como BlockStainedGlass). */
    public static <T extends Block> T bindVanilla(T legacy, net.minecraft.world.level.block.Block vanilla) {
        ((Block) legacy).vanilla = vanilla;   // via cast: membros privados não são acessíveis por T
        return legacy;
    }

    /** Para blocos vanilla que a 1.7.10 separava por metadata (cor): um bloco moderno por valor de metadata. */
    public static <T extends Block> T bindVanillaMeta(T legacy, net.minecraft.world.level.block.Block[] byMeta) {
        ((Block) legacy).vanillaByMeta = byMeta;
        return legacy;
    }

    /** O Block moderno (de qualquer metadata) já existe? (evita criar blocos depois que os registros congelaram) */
    public boolean hasModern() {
        return vanilla != null || vanillaByMeta != null || !created.isEmpty();
    }

    /** Existe um Block moderno para esta metadata? Nunca cria nada. */
    public boolean hasModernFor(int meta) {
        if (vanillaByMeta != null) {
            return meta >= 0 && meta < vanillaByMeta.length;
        }
        if (vanilla != null) {
            return meta == 0;
        }
        return created.containsKey(meta);
    }

    /** Block moderno da metadata 0. */
    public net.minecraft.world.level.block.Block modern() {
        return modernForMeta(0);
    }

    /**
     * Block moderno para uma metadata. Para blocos do mod, é CRIADO aqui (só chamar com os registros abertos, ou seja,
     * dentro do RegisterEvent). A 1.20 não tem metadata: cada valor vira um bloco próprio (nome_0, nome_1, ...).
     */
    public net.minecraft.world.level.block.Block modernForMeta(int meta) {
        if (vanillaByMeta != null) {
            return vanillaByMeta[Math.max(0, Math.min(meta, vanillaByMeta.length - 1))];
        }
        if (vanilla != null) {
            return vanilla;
        }
        net.minecraft.world.level.block.Block block = created.get(meta);
        if (block == null) {
            BlockBehaviour.Properties props = buildProperties();
            block = this instanceof BlockPane ? new LegacyPaneBlock(this, props, meta) : new LegacyBlockAdapter(this, props, meta);
            created.put(meta, block);
        }
        return block;
    }

    /** Valores de metadata que este bloco oferece (o que o mod põe na aba criativa via getSubBlocks); sempre ao menos [0]. */
    public List<Integer> subMetas() {
        if (subMetas == null) {
            TreeSet<Integer> metas = new TreeSet<>();
            try {
                List<Object> stacks = new ArrayList<>();
                getSubBlocks(legacyItem(), creativeTab, stacks);
                for (Object o : stacks) {
                    if (o instanceof ItemStack s && s.getItemDamage() >= 0 && s.getItemDamage() <= 15) {
                        metas.add(s.getItemDamage());
                    }
                }
            } catch (RuntimeException | LinkageError e) {
                // o getSubBlocks do mod falhou: fica só a metadata 0
            }
            if (metas.isEmpty()) {
                metas.add(0);
            }
            subMetas = List.copyOf(metas);
        }
        return subMetas;
    }

    /** Padrão da 1.7.10: só a metadata 0. Mods com cores/variantes sobrescrevem. */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void getSubBlocks(Item item, CreativeTabs tab, List list) {
        list.add(new ItemStack(item, 1, 0));
    }

    public void setItemClass(Class<? extends ItemBlock> itemClass) {
        this.itemClass = itemClass;
    }

    /** Chave de tradução de uma metadata: a do ItemBlock customizado do mod, se houver, senão a do próprio bloco. */
    public String descriptionIdFor(int meta, String fallback) {
        try {
            if (customItem == null && itemClass != null) {
                var ctor = itemClass.getDeclaredConstructor(Block.class);
                ctor.setAccessible(true);
                customItem = ctor.newInstance(this);
            }
            if (customItem != null) {
                String key = customItem.getUnlocalizedName(new ItemStack(this, 1, meta));
                if (key != null && !key.isEmpty()) {
                    return key;
                }
            }
        } catch (ReflectiveOperationException | RuntimeException | LinkageError e) {
            // sem nome específico: usa o padrão
        }
        String name = getUnlocalizedName();
        return name.equals("tile.") ? fallback : name;
    }

    /** Limites do bloco (0..1) definidos por setBlockBounds: minX, minY, minZ, maxX, maxY, maxZ. */
    public float[] legacyBounds() {
        return new float[] {minX, minY, minZ, maxX, maxY, maxZ};
    }

    public boolean hasCustomBounds() {
        return minX != 0.0F || minY != 0.0F || minZ != 0.0F || maxX != 1.0F || maxY != 1.0F || maxZ != 1.0F;
    }

    private BlockBehaviour.Properties buildProperties() {
        BlockBehaviour.Properties p = BlockBehaviour.Properties.of();
        if (blockHardness < 0.0F) {
            p = p.strength(-1.0F, 3600000.0F);
        } else {
            p = p.strength(blockHardness, blockResistance / 5.0F);
        }
        p = p.sound(modernSound(stepSound));
        boolean opaque = true;
        try {
            opaque = isOpaqueCube();
        } catch (RuntimeException | LinkageError e) {
            // método do mod falhou ou usa API sem shim: assume opaco
        }
        if (!opaque) {
            p = p.noOcclusion();
        }
        if (lightValue > 0) {
            final int light = lightValue;
            p = p.lightLevel(state -> light);
        }
        return p;
    }

    private static net.minecraft.world.level.block.SoundType modernSound(SoundType s) {
        if (s == soundTypeWood) return net.minecraft.world.level.block.SoundType.WOOD;
        if (s == soundTypeGravel) return net.minecraft.world.level.block.SoundType.GRAVEL;
        if (s == soundTypeGrass) return net.minecraft.world.level.block.SoundType.GRASS;
        if (s == soundTypeMetal) return net.minecraft.world.level.block.SoundType.METAL;
        if (s == soundTypeGlass) return net.minecraft.world.level.block.SoundType.GLASS;
        if (s == soundTypeCloth) return net.minecraft.world.level.block.SoundType.WOOL;
        if (s == soundTypeSand) return net.minecraft.world.level.block.SoundType.SAND;
        if (s == soundTypeSnow) return net.minecraft.world.level.block.SoundType.SNOW;
        if (s == soundTypeLadder) return net.minecraft.world.level.block.SoundType.LADDER;
        if (s == soundTypeAnvil) return net.minecraft.world.level.block.SoundType.ANVIL;
        return net.minecraft.world.level.block.SoundType.STONE;
    }
}
