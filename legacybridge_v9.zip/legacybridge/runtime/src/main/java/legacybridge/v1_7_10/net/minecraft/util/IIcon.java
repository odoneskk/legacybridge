package legacybridge.v1_7_10.net.minecraft.util;

/** Shim de IIcon (1.7.10). Ícones/atlas antigos não existem na 1.20; por ora só o tipo. */
public interface IIcon {
}
