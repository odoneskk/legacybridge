package legacybridge.v1_7_10.net.minecraft.block;

import legacybridge.v1_7_10.net.minecraft.block.material.Material;

/**
 * Shim de BlockPane (1.7.10). O bloco moderno correspondente é um IronBarsBlock (ver LegacyPaneBlock), que cuida da
 * forma fina e da conexão com os vizinhos.
 */
public class BlockPane extends Block {
    public BlockPane(String sideTexture, String topTexture, Material material, boolean canDropItself) {
        super(material);
    }

    @Override
    public boolean isOpaqueCube() {
        return false;
    }

    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }
}
