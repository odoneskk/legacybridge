package legacybridge.v1_7_10.cpw.mods.fml.common.event;

import java.io.File;

import net.minecraftforge.fml.loading.FMLPaths;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** Shim de FMLPreInitializationEvent (1.7.10). */
public class FMLPreInitializationEvent {
    private final String modId;

    public FMLPreInitializationEvent(String modId) {
        this.modId = modId;
    }

    public File getModConfigurationDirectory() {
        return FMLPaths.CONFIGDIR.get().toFile();
    }

    public File getSuggestedConfigurationFile() {
        return new File(getModConfigurationDirectory(), modId + ".cfg");
    }

    public Logger getModLog() {
        return LogManager.getLogger(modId);
    }
}
