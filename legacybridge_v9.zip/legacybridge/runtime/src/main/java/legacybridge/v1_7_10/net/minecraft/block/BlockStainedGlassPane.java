package legacybridge.v1_7_10.net.minecraft.block;

import legacybridge.v1_7_10.net.minecraft.block.material.Material;

/** Shim de BlockStainedGlassPane (1.7.10). */
public class BlockStainedGlassPane extends BlockPane {
    public BlockStainedGlassPane() {
        super("glass", "glass_pane_top", Material.glass, false);
    }

    @Override
    public int getRenderBlockPass() {
        return 1;
    }
}
