package legacybridge.v1_7_10.net.minecraft.block;

import legacybridge.v1_7_10.net.minecraft.block.material.Material;

/** Shim de BlockGrass (1.7.10). Existe porque Blocks.grass tem esse tipo. */
public class BlockGrass extends Block {
    public BlockGrass() {
        super(Material.grass);
    }
}
