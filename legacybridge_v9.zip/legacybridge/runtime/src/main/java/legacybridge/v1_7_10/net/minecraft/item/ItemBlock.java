package legacybridge.v1_7_10.net.minecraft.item;

import legacybridge.v1_7_10.net.minecraft.block.Block;

/** Shim de ItemBlock (1.7.10). */
public class ItemBlock extends Item {
    public final Block field_150939_a;

    public ItemBlock(Block block) {
        this.field_150939_a = block;
    }

    @Override
    public int getMetadata(int damage) {
        return damage;
    }

    @Override
    public String getUnlocalizedName(ItemStack stack) {
        return field_150939_a.getUnlocalizedName();
    }
}
