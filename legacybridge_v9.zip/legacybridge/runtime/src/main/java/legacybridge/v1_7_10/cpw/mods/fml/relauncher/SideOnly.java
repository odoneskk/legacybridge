package legacybridge.v1_7_10.cpw.mods.fml.relauncher;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/** Shim de SideOnly (1.7.10). TODO: remover membros @SideOnly(CLIENT) ao rodar em servidor dedicado. */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.FIELD, ElementType.METHOD, ElementType.CONSTRUCTOR, ElementType.PACKAGE})
public @interface SideOnly {
    Side value();
}
