package legacybridge.runtime;

import legacybridge.v1_7_10.net.minecraft.util.IIcon;

/** IIcon que só guarda o nome com que o mod o registrou (a gente usa o nome para achar a textura). */
final class NamedIcon implements IIcon {
    final String name;

    NamedIcon(String name) {
        this.name = name;
    }
}
