package legacybridge.runtime;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import legacybridge.v1_7_10.net.minecraft.block.Block;
import legacybridge.v1_7_10.net.minecraft.item.Item;
import legacybridge.v1_7_10.net.minecraft.item.ItemStack;

/**
 * Receita registrada por um mod 1.7.10 (GameRegistry.addRecipe / addShapelessRecipe), ainda no formato antigo.
 * Vira o JSON de receita da 1.20.1 em {@link #toJson}. Sem dependência do Minecraft: o que depende dele
 * (achar o id do item moderno) entra pelo {@link Resolver}.
 *
 * <p>Limitações: metadata/dano (ex.: cor do vidro, corantes) não existe na 1.20, então receitas que dependem disso
 * são puladas (com o motivo no log). OreDictionary, receitas customizadas e itens ainda sem shim também.
 */
public final class LegacyRecipe {
    /** Dá o id do item moderno ("minecraft:glass") para um Block/Item legado + metadata, ou null se não há equivalente. */
    public interface Resolver {
        String itemId(Object legacy, int meta);
    }

    private final String modId;
    private final boolean shaped;
    private final ItemStack output;
    private final Object[] params;

    public LegacyRecipe(String modId, boolean shaped, ItemStack output, Object[] params) {
        this.modId = modId;
        this.shaped = shaped;
        this.output = output;
        this.params = params == null ? new Object[0] : params;
    }

    public String modId() {
        return modId;
    }

    /** @return o JSON da receita, ou null (e os motivos em {@code problems}). */
    public String toJson(Resolver resolver, List<String> problems) {
        String result = stackId(output, resolver, problems, "resultado");
        if (result == null) {
            return null;
        }
        String resultJson = "\"result\":{\"item\":" + q(result) + ",\"count\":" + Math.max(1, output.stackSize) + "}";
        return shaped ? shaped(resolver, problems, resultJson) : shapeless(resolver, problems, resultJson);
    }

    /** Nome sugerido do arquivo da receita (sem extensão), a partir do resultado. */
    public String fileName(int index, Resolver resolver) {
        List<String> ignore = new ArrayList<>();
        String id = stackId(output, resolver, ignore, "resultado");
        String path = id == null ? "desconhecido" : id.substring(id.indexOf(':') + 1).replace('/', '_');
        return "legacy_" + index + "_" + path;
    }

    private String shaped(Resolver r, List<String> problems, String resultJson) {
        int i = 0;
        List<String> rows = new ArrayList<>();
        if (params.length > 0 && params[0] instanceof String[] arr) {
            rows.addAll(Arrays.asList(arr));
            i = 1;
        } else {
            while (i < params.length && params[i] instanceof String s) {
                rows.add(s);
                i++;
            }
        }
        if (rows.isEmpty() || rows.size() > 3) {
            problems.add("padrão com " + rows.size() + " linhas");
            return null;
        }
        int width = 0;
        for (String row : rows) {
            width = Math.max(width, row.length());
        }
        if (width == 0 || width > 3) {
            problems.add("padrão com largura " + width);
            return null;
        }

        Map<Character, String> key = new LinkedHashMap<>();
        for (; i + 1 < params.length; i += 2) {
            if (!(params[i] instanceof Character c)) {
                problems.add("ingrediente sem letra no padrão: " + describe(params[i]));
                return null;
            }
            String id = stackId(params[i + 1], r, problems, "ingrediente '" + c + "'");
            if (id == null) {
                return null;
            }
            key.put(c, id);
        }

        StringBuilder pattern = new StringBuilder();
        for (int n = 0; n < rows.size(); n++) {
            String row = rows.get(n);
            StringBuilder padded = new StringBuilder(row);
            while (padded.length() < width) {
                padded.append(' ');                   // a 1.7.10 aceitava linhas de larguras diferentes
            }
            for (char ch : padded.toString().toCharArray()) {
                if (ch != ' ' && !key.containsKey(ch)) {
                    problems.add("letra '" + ch + "' do padrão sem ingrediente");
                    return null;
                }
            }
            if (n > 0) {
                pattern.append(',');
            }
            pattern.append(q(padded.toString()));
        }

        StringBuilder keys = new StringBuilder();
        for (Map.Entry<Character, String> e : key.entrySet()) {
            if (e.getKey() == ' ') {
                continue;
            }
            if (keys.length() > 0) {
                keys.append(',');
            }
            keys.append(q(String.valueOf(e.getKey()))).append(":{\"item\":").append(q(e.getValue())).append('}');
        }
        return "{\"type\":\"minecraft:crafting_shaped\",\"pattern\":[" + pattern + "],\"key\":{" + keys + "}," + resultJson + "}";
    }

    private String shapeless(Resolver r, List<String> problems, String resultJson) {
        if (params.length == 0 || params.length > 9) {
            problems.add("receita sem forma com " + params.length + " ingredientes");
            return null;
        }
        StringBuilder ing = new StringBuilder();
        for (Object p : params) {
            String id = stackId(p, r, problems, "ingrediente");
            if (id == null) {
                return null;
            }
            if (ing.length() > 0) {
                ing.append(',');
            }
            ing.append("{\"item\":").append(q(id)).append('}');
        }
        return "{\"type\":\"minecraft:crafting_shapeless\",\"ingredients\":[" + ing + "]," + resultJson + "}";
    }

    private static String stackId(Object o, Resolver r, List<String> problems, String what) {
        int meta = 0;
        if (o instanceof ItemStack s) {
            // Short.MAX_VALUE = "qualquer metadata" na 1.7.10; aproximamos pela metadata 0.
            meta = s.getItemDamage() == Short.MAX_VALUE ? 0 : s.getItemDamage();
            o = s.legacyBlock() != null ? (Object) s.legacyBlock() : (Object) s.getItem();
        }
        if (o instanceof Block || o instanceof Item) {
            String id = r.itemId(o, meta);
            if (id == null) {
                problems.add(what + " sem equivalente moderno: " + describe(o) + (meta != 0 ? " (metadata " + meta + ")" : ""));
            }
            return id;
        }
        problems.add(what + " de tipo não suportado: " + describe(o));
        return null;
    }

    private static String describe(Object o) {
        return o == null ? "null" : o.getClass().getSimpleName();
    }

    private static String q(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            if (c == '"' || c == '\\') {
                sb.append('\\');
            }
            sb.append(c);
        }
        return sb.append('"').toString();
    }
}
