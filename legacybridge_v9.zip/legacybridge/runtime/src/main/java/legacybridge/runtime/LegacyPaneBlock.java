package legacybridge.runtime;

import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;

/**
 * Bloco moderno de um painel legado (BlockPane). Herda de IronBarsBlock, a classe dos painéis de vidro e grades do
 * vanilla: ela já tem a forma fina, a conexão com painéis/blocos vizinhos e o waterlogging.
 */
public class LegacyPaneBlock extends IronBarsBlock {
    private final legacybridge.v1_7_10.net.minecraft.block.Block legacy;
    private final int meta;

    public LegacyPaneBlock(legacybridge.v1_7_10.net.minecraft.block.Block legacy, BlockBehaviour.Properties properties, int meta) {
        super(properties);
        this.legacy = legacy;
        this.meta = meta;
    }

    public legacybridge.v1_7_10.net.minecraft.block.Block legacy() {
        return legacy;
    }

    public int meta() {
        return meta;
    }

    @Override
    public String getDescriptionId() {
        return legacy.descriptionIdFor(meta, super.getDescriptionId());
    }
}
