package legacybridge.runtime;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod("legacybridge")
public class LegacyBridgeMod {
    public LegacyBridgeMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        bus.addListener(PendingRegistry::onRegister);       // registra o que os mods legados enfileiraram
        bus.addListener(PendingRegistry::onBuildTabContents); // põe os itens dos blocos nas abas criativas (e no JEI)
        bus.addListener(LegacyGeneratedPacks::onAddPackFinders); // texturas/modelos e receitas gerados
        bus.addListener(LegacyBootstrap::onCommonSetup);    // dispara init/postInit dos mods legados
    }
}
