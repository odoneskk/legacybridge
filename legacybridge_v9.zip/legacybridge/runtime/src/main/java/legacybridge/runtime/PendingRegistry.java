package legacybridge.runtime;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import legacybridge.v1_7_10.net.minecraft.block.Block;
import legacybridge.v1_7_10.net.minecraft.creativetab.CreativeTabs;
import legacybridge.v1_7_10.net.minecraft.item.ItemStack;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Na 1.7.10 qualquer coisa registra no preInit; na 1.20.1 só dentro do RegisterEvent. Por isso o preInit legado roda
 * no primeiro RegisterEvent, e os shims (ex.: GameRegistry.registerBlock) só enfileiram aqui.
 *
 * <p>Metadata: a 1.20 não tem. Um bloco legado com N valores de metadata (ex.: 16 cores) vira N blocos modernos,
 * "nome_0" ... "nome_15" (ou só "nome", se tem um único valor). O Block moderno de cada um só é criado
 * ({@link Block#modernForMeta}) quando o registro é aberto.
 *
 * <p>TODO: itens, entidades, biomas e spawns (dados/JSON na 1.20.1, ver README), ItemBlock customizado de verdade.
 */
public final class PendingRegistry {
    /** Um bloco moderno que representa uma metadata de um bloco legado. */
    public record Variant(ResourceLocation id, Block legacy, int meta) {}

    private static final Logger LOGGER = LogManager.getLogger("legacybridge");
    private static final Map<ResourceLocation, Block> BLOCKS = new LinkedHashMap<>();
    private static final List<LegacyRecipe> RECIPES = new ArrayList<>();

    private PendingRegistry() {}

    public static void queueBlock(String name, Block block) {
        String path = name.toLowerCase(Locale.ROOT);
        BLOCKS.put(new ResourceLocation(LegacyBootstrap.currentModId(), path), block);
    }

    public static void queueRecipe(boolean shaped, ItemStack output, Object[] params) {
        RECIPES.add(new LegacyRecipe(LegacyBootstrap.currentModId(), shaped, output, params));
    }

    static List<LegacyRecipe> recipes() {
        return Collections.unmodifiableList(RECIPES);
    }

    /** Todos os blocos modernos (um por metadata). Só confiável depois do RegisterEvent de blocos. */
    static List<Variant> variants() {
        List<Variant> all = new ArrayList<>();
        for (Map.Entry<ResourceLocation, Block> e : BLOCKS.entrySet()) {
            List<Integer> metas = e.getValue().subMetas();
            for (int meta : metas) {
                all.add(new Variant(variantId(e.getKey(), metas.size(), meta), e.getValue(), meta));
            }
        }
        return all;
    }

    private static ResourceLocation variantId(ResourceLocation base, int metaCount, int meta) {
        return metaCount == 1 ? base : new ResourceLocation(base.getNamespace(), base.getPath() + "_" + meta);
    }

    static void onRegister(RegisterEvent event) {
        // Primeiro RegisterEvent de qualquer registro: os registros estão abertos, então o preInit legado só pode
        // rodar agora. As chamadas seguintes não fazem nada (a flag fica no LegacyBootstrap).
        LegacyBootstrap.runPreInit();
        event.register(ForgeRegistries.Keys.BLOCKS, helper -> {
            int count = 0;
            for (Variant v : variants()) {
                helper.register(v.id(), v.legacy().modernForMeta(v.meta()));
                LOGGER.info("Legacy Bridge: bloco registrado: {}", v.id());
                count++;
            }
            LOGGER.info("Legacy Bridge: {} bloco(s) de mods legados registrado(s)", count);
        });
        event.register(ForgeRegistries.Keys.ITEMS, helper -> {
            for (Variant v : variants()) {
                helper.register(v.id(), new BlockItem(v.legacy().modernForMeta(v.meta()), new Item.Properties()));
            }
        });
    }

    /**
     * Desde a 1.19.3 o inventário criativo e o JEI só listam itens que estão em uma aba criativa. Por isso cada bloco
     * legado entra numa aba moderna equivalente (abas customizadas e blocos sem aba vão para "Blocos de construção").
     */
    static void onBuildTabContents(BuildCreativeModeTabContentsEvent event) {
        for (Variant v : variants()) {
            if (event.getTabKey().equals(modernTabFor(v.legacy().legacyCreativeTab()))) {
                event.accept(v.legacy().modernForMeta(v.meta()));
            }
        }
    }

    private static ResourceKey<CreativeModeTab> modernTabFor(CreativeTabs tab) {
        if (tab == CreativeTabs.tabRedstone || tab == CreativeTabs.tabTransport) {
            return CreativeModeTabs.REDSTONE_BLOCKS;
        }
        if (tab == CreativeTabs.tabDecorations) {
            return CreativeModeTabs.FUNCTIONAL_BLOCKS;
        }
        if (tab == CreativeTabs.tabTools) {
            return CreativeModeTabs.TOOLS_AND_UTILITIES;
        }
        if (tab == CreativeTabs.tabCombat) {
            return CreativeModeTabs.COMBAT;
        }
        if (tab == CreativeTabs.tabFood) {
            return CreativeModeTabs.FOOD_AND_DRINKS;
        }
        if (tab == CreativeTabs.tabMisc || tab == CreativeTabs.tabMaterials || tab == CreativeTabs.tabBrewing) {
            return CreativeModeTabs.INGREDIENTS;
        }
        return CreativeModeTabs.BUILDING_BLOCKS;
    }
}
