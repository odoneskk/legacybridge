package legacybridge.runtime;

import java.util.Locale;

/**
 * JSONs de blockstate/modelo (1.20.1) para blocos legados. A 1.7.10 não tem nada disso: as texturas vinham de
 * IIcon registrados por código, e aqui são reconstruídas a partir do que o mod registrou.
 * Faces da 1.7.10: 0=baixo, 1=cima, 2=norte, 3=sul, 4=oeste, 5=leste.
 */
public final class ModelJson {
    private ModelJson() {}

    /** "mod:nome" (nome de ícone 1.7.10) -> "mod:block/nome" (textura 1.20; minúsculas obrigatórias). */
    public static String texture(String icon) {
        String ns = "minecraft";
        String path = icon;
        int colon = icon.indexOf(':');
        if (colon >= 0) {
            ns = icon.substring(0, colon);
            path = icon.substring(colon + 1);
        }
        return ns.toLowerCase(Locale.ROOT) + ":block/" + path.toLowerCase(Locale.ROOT);
    }

    /**
     * @param faces      nomes de ícone por face (null = sem info); posições 0..5
     * @param fallback   ícone usado nas faces sem info (null = textura "faltando")
     * @param renderType null (sólido), "cutout" ou "translucent"
     */
    public static String blockModel(String[] faces, String fallback, String renderType) {
        String[] tex = new String[6];
        boolean same = true;
        for (int i = 0; i < 6; i++) {
            String icon = faces[i] != null ? faces[i] : fallback;
            tex[i] = icon == null ? "minecraft:missingno" : texture(icon);
            if (!tex[i].equals(tex[0])) {
                same = false;
            }
        }
        String render = renderType == null ? "" : ",\"render_type\":" + q("minecraft:" + renderType);
        if (same) {
            return "{\"parent\":\"minecraft:block/cube_all\",\"textures\":{\"all\":" + q(tex[0]) + "}" + render + "}";
        }
        return "{\"parent\":\"minecraft:block/cube\",\"textures\":{\"particle\":" + q(tex[1])
                + ",\"down\":" + q(tex[0]) + ",\"up\":" + q(tex[1]) + ",\"north\":" + q(tex[2])
                + ",\"south\":" + q(tex[3]) + ",\"west\":" + q(tex[4]) + ",\"east\":" + q(tex[5]) + "}" + render + "}";
    }

    /**
     * Modelo de bloco com forma própria (setBlockBounds): um cuboide. Limites em 0..1 (minX, minY, minZ, maxX, maxY, maxZ).
     * Herda de block/block para ter as transformações de exibição (inventário, mão) de um bloco.
     */
    public static String cuboidModel(float[] b, String[] faces, String fallback, String renderType) {
        String[] tex = new String[6];
        for (int i = 0; i < 6; i++) {
            String icon = faces[i] != null ? faces[i] : fallback;
            tex[i] = icon == null ? "minecraft:missingno" : texture(icon);
        }
        String render = renderType == null ? "" : ",\"render_type\":" + q("minecraft:" + renderType);
        String[] names = {"down", "up", "north", "south", "west", "east"};
        StringBuilder faceJson = new StringBuilder();
        StringBuilder texJson = new StringBuilder("\"particle\":" + q(tex[1]));
        for (int i = 0; i < 6; i++) {
            texJson.append(',').append(q(names[i])).append(':').append(q(tex[i]));
            if (i > 0) {
                faceJson.append(',');
            }
            faceJson.append(q(names[i])).append(":{\"texture\":").append(q("#" + names[i])).append('}');
        }
        return "{\"parent\":\"minecraft:block/block\",\"textures\":{" + texJson + "},\"elements\":[{\"from\":["
                + num(b[0]) + "," + num(b[1]) + "," + num(b[2]) + "],\"to\":[" + num(b[3]) + "," + num(b[4]) + "," + num(b[5])
                + "],\"faces\":{" + faceJson + "}}]" + render + "}";
    }

    /** Blockstate de painel (igual ao do painel de vidro vanilla): poste + lados conforme a conexão. */
    public static String paneBlockstate(String ns, String name) {
        String m = ns + ":block/" + name;
        return "{\"multipart\":["
                + "{\"apply\":{\"model\":" + q(m + "_post") + "}},"
                + "{\"when\":{\"north\":\"true\"},\"apply\":{\"model\":" + q(m + "_side") + "}},"
                + "{\"when\":{\"east\":\"true\"},\"apply\":{\"model\":" + q(m + "_side") + ",\"y\":90}},"
                + "{\"when\":{\"south\":\"true\"},\"apply\":{\"model\":" + q(m + "_side_alt") + "}},"
                + "{\"when\":{\"west\":\"true\"},\"apply\":{\"model\":" + q(m + "_side_alt") + ",\"y\":90}},"
                + "{\"when\":{\"north\":\"false\"},\"apply\":{\"model\":" + q(m + "_noside") + "}},"
                + "{\"when\":{\"east\":\"false\"},\"apply\":{\"model\":" + q(m + "_noside_alt") + "}},"
                + "{\"when\":{\"south\":\"false\"},\"apply\":{\"model\":" + q(m + "_noside_alt") + ",\"y\":90}},"
                + "{\"when\":{\"west\":\"false\"},\"apply\":{\"model\":" + q(m + "_noside") + ",\"y\":270}}"
                + "]}";
    }

    /** @param part post, side, side_alt, noside ou noside_alt (modelos-molde do painel de vidro vanilla) */
    public static String paneModel(String part, String paneIcon, String edgeIcon, String renderType) {
        String pane = paneIcon == null ? "minecraft:missingno" : texture(paneIcon);
        String edge = edgeIcon == null ? pane : texture(edgeIcon);
        String render = renderType == null ? "" : ",\"render_type\":" + q("minecraft:" + renderType);
        return "{\"parent\":" + q("minecraft:block/template_glass_pane_" + part) + ",\"textures\":{\"edge\":" + q(edge)
                + ",\"pane\":" + q(pane) + "}" + render + "}";
    }

    public static String paneItemModel(String paneIcon) {
        String pane = paneIcon == null ? "minecraft:missingno" : texture(paneIcon);
        return "{\"parent\":\"minecraft:item/generated\",\"textures\":{\"layer0\":" + q(pane) + "}}";
    }

    private static String num(float v) {
        return String.format(Locale.ROOT, "%.4f", v * 16.0F).replaceAll("0+$", "0").replaceAll("\\.0$", ".0");
    }

    public static String blockstate(String modelId) {
        return "{\"variants\":{\"\":{\"model\":" + q(modelId) + "}}}";
    }

    public static String itemModel(String blockModelId) {
        return "{\"parent\":" + q(blockModelId) + "}";
    }

    private static String q(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }
}
