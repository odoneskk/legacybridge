package legacybridge.runtime;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

import legacybridge.v1_7_10.net.minecraft.block.Block;
import legacybridge.v1_7_10.net.minecraft.block.BlockPane;
import legacybridge.v1_7_10.net.minecraft.item.ItemBlock;
import legacybridge.v1_7_10.net.minecraft.util.IIcon;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.PathPackResources;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackSource;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.AddPackFindersEvent;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.registries.ForgeRegistries;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Gera, a partir do que os mods legados registraram, dois packs em .legacybridge/generated/:
 * <ul>
 *   <li><b>assets</b> (resource pack): blockstate + modelo de bloco + modelo de item de cada bloco, com as texturas
 *       descobertas chamando o {@code registerBlockIcons}/{@code getIcon} do próprio mod;</li>
 *   <li><b>data</b> (data pack): receitas JSON convertidas de GameRegistry.addRecipe/addShapelessRecipe.</li>
 * </ul>
 * Os packs são sempre ativados (pack "required") e ficam no topo.
 *
 * <p>Ainda não cobre: itens (só blocos), formas dinâmicas (setBlockBoundsBasedOnState), receitas com
 * corantes/OreDictionary, fornalha.
 */
public final class LegacyGeneratedPacks {
    private static final Logger LOGGER = LogManager.getLogger("legacybridge");
    private static final String PACK_META = "{\"pack\":{\"description\":\"Legacy Bridge (gerado)\",\"pack_format\":15}}";

    /** Block/Item legado -> id do item moderno. Não é final só para os testes poderem trocá-lo. */
    static LegacyRecipe.Resolver resolver = LegacyGeneratedPacks::modernItemId;

    private LegacyGeneratedPacks() {}

    static void onAddPackFinders(AddPackFindersEvent event) {
        PackType type = event.getPackType();
        try {
            if (type == PackType.CLIENT_RESOURCES) {
                Path dir = freshDir("assets");
                generateAssets(dir);
                addPack(event, dir, "legacybridge_generated_assets");
            } else if (type == PackType.SERVER_DATA) {
                Path dir = freshDir("data");
                generateRecipes(dir);
                addPack(event, dir, "legacybridge_generated_data");
            }
        } catch (IOException | RuntimeException e) {
            LOGGER.error("Legacy Bridge: falha ao gerar o pack ({})", type, e);
        }
    }

    static void generateAssets(Path dir) throws IOException {
        int count = 0;
        Set<Block> iconsRegistered = new HashSet<>();
        for (PendingRegistry.Variant v : PendingRegistry.variants()) {
            ResourceLocation id = v.id();
            Block legacy = v.legacy();
            String ns = id.getNamespace();
            String name = id.getPath();

            // Descobre as texturas chamando o código do próprio mod (registerBlockIcons uma vez, getIcon por face/metadata)
            String[] faces = new String[6];
            String fallback = legacy.legacyTextureName();
            if (fallback != null && fallback.isEmpty()) {
                fallback = null;
            }
            try {
                if (iconsRegistered.add(legacy)) {
                    legacy.registerBlockIcons(new IconRecorder());
                }
                for (int side = 0; side < 6; side++) {
                    IIcon icon = legacy.getIcon(side, v.meta());
                    if (icon instanceof NamedIcon named) {
                        faces[side] = named.name;
                    }
                }
            } catch (RuntimeException | LinkageError ex) {
                LOGGER.warn("Legacy Bridge: não deu para descobrir as texturas de {} ({})", id, ex.toString());
            }

            String renderType = renderTypeOf(legacy);
            Path assets = dir.resolve("assets/" + ns);
            if (legacy instanceof BlockPane) {
                // Painel: poste + lados (o IronBarsBlock cuida da conexão). Lado = face norte, borda = face de cima.
                String pane = faces[2] != null ? faces[2] : (faces[3] != null ? faces[3] : fallback);
                String edge = faces[1] != null ? faces[1] : pane;
                write(assets.resolve("blockstates/" + name + ".json"), ModelJson.paneBlockstate(ns, name));
                for (String part : new String[] {"post", "side", "side_alt", "noside", "noside_alt"}) {
                    write(assets.resolve("models/block/" + name + "_" + part + ".json"), ModelJson.paneModel(part, pane, edge, renderType));
                }
                write(assets.resolve("models/item/" + name + ".json"), ModelJson.paneItemModel(pane));
            } else {
                write(assets.resolve("blockstates/" + name + ".json"), ModelJson.blockstate(ns + ":block/" + name));
                String model = legacy.hasCustomBounds()
                        ? ModelJson.cuboidModel(legacy.legacyBounds(), faces, fallback, renderType)
                        : ModelJson.blockModel(faces, fallback, renderType);
                write(assets.resolve("models/block/" + name + ".json"), model);
                write(assets.resolve("models/item/" + name + ".json"), ModelJson.itemModel(ns + ":block/" + name));
            }
            count++;
        }
        LOGGER.info("Legacy Bridge: blockstate e modelos gerados para {} bloco(s)", count);
    }

    static void generateRecipes(Path dir) throws IOException {
        int converted = 0;
        int skipped = 0;
        int index = 0;
        for (LegacyRecipe recipe : PendingRegistry.recipes()) {
            index++;
            List<String> problems = new ArrayList<>();
            String json = null;
            try {
                json = recipe.toJson(resolver, problems);
            } catch (RuntimeException | LinkageError ex) {
                problems.add(ex.toString());
            }
            if (json == null) {
                skipped++;
                LOGGER.warn("Legacy Bridge: receita #{} de '{}' ignorada: {}", index, recipe.modId(), String.join("; ", problems));
                continue;
            }
            write(dir.resolve("data/" + recipe.modId() + "/recipes/" + recipe.fileName(index, resolver) + ".json"), json);
            converted++;
        }
        LOGGER.info("Legacy Bridge: {} receita(s) convertida(s), {} ignorada(s)", converted, skipped);
    }

    private static String renderTypeOf(Block legacy) {
        try {
            if (legacy.getRenderBlockPass() == 1) {
                return "translucent";
            }
            if (!legacy.isOpaqueCube()) {
                return "cutout";
            }
        } catch (RuntimeException | LinkageError ignored) {
            // o método do mod falhou: trata como bloco sólido
        }
        return null;
    }

    private static String modernItemId(Object legacy, int meta) {
        Block block = null;
        if (legacy instanceof Block b) {
            block = b;
        } else if (legacy instanceof ItemBlock ib) {
            block = ib.field_150939_a;
        }
        if (block == null || !block.hasModernFor(meta)) {
            return null;                          // não criar bloco novo aqui: os registros já estão congelados
        }
        net.minecraft.world.item.Item item = block.modernForMeta(meta).asItem();
        if (item == Items.AIR) {
            return null;
        }
        ResourceLocation key = ForgeRegistries.ITEMS.getKey(item);
        return key == null ? null : key.toString();
    }

    private static void addPack(AddPackFindersEvent event, Path dir, String packId) {
        Pack pack = Pack.readMetaAndCreate(packId, Component.literal("Legacy Bridge (gerado)"), true,
                id -> new PathPackResources(id, dir, false), event.getPackType(), Pack.Position.TOP, PackSource.BUILT_IN);
        if (pack == null) {
            LOGGER.error("Legacy Bridge: o Minecraft recusou o pack gerado {} (pack.mcmeta/versão?)", packId);
            return;
        }
        event.addRepositorySource(consumer -> consumer.accept(pack));
    }

    private static Path freshDir(String kind) throws IOException {
        Path dir = FMLPaths.GAMEDIR.get().resolve(".legacybridge").resolve("generated").resolve(kind);
        if (Files.exists(dir)) {
            List<Path> all;
            try (Stream<Path> walk = Files.walk(dir)) {
                all = walk.sorted(Comparator.reverseOrder()).toList();
            }
            for (Path p : all) {
                Files.deleteIfExists(p);
            }
        }
        Files.createDirectories(dir);
        Files.writeString(dir.resolve("pack.mcmeta"), PACK_META, StandardCharsets.UTF_8);
        return dir;
    }

    private static void write(Path file, String content) throws IOException {
        Files.createDirectories(file.getParent());
        Files.writeString(file, content, StandardCharsets.UTF_8);
    }
}
