package legacybridge.runtime;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * O Block moderno que representa UMA metadata de um Block legado (1.7.10). A 1.20 não tem metadata, então cada valor
 * (ex.: cada cor) vira um bloco próprio. Cuida do nome traduzido e da forma (setBlockBounds).
 */
public class LegacyBlockAdapter extends Block {
    private final legacybridge.v1_7_10.net.minecraft.block.Block legacy;
    private final int meta;
    private final VoxelShape shape;

    public LegacyBlockAdapter(legacybridge.v1_7_10.net.minecraft.block.Block legacy, BlockBehaviour.Properties properties, int meta) {
        super(properties);
        this.legacy = legacy;
        this.meta = meta;
        if (legacy.hasCustomBounds()) {
            float[] b = legacy.legacyBounds();
            this.shape = Block.box(b[0] * 16.0, b[1] * 16.0, b[2] * 16.0, b[3] * 16.0, b[4] * 16.0, b[5] * 16.0);
        } else {
            this.shape = null;
        }
    }

    public legacybridge.v1_7_10.net.minecraft.block.Block legacy() {
        return legacy;
    }

    public int meta() {
        return meta;
    }

    @Override
    public String getDescriptionId() {
        return legacy.descriptionIdFor(meta, super.getDescriptionId());
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return shape != null ? shape : super.getShape(state, level, pos, context);
    }
}
