package legacybridge.runtime;

import legacybridge.v1_7_10.net.minecraft.client.renderer.texture.IIconRegister;
import legacybridge.v1_7_10.net.minecraft.util.IIcon;

/** IIconRegister que só devolve NamedIcon, para descobrir quais texturas cada bloco legado usa. */
final class IconRecorder implements IIconRegister {
    @Override
    public IIcon registerIcon(String name) {
        return new NamedIcon(name);
    }
}
