import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.imageio.ImageIO;

import jdk.internal.org.objectweb.asm.AnnotationVisitor;
import jdk.internal.org.objectweb.asm.ClassWriter;
import jdk.internal.org.objectweb.asm.MethodVisitor;
import jdk.internal.org.objectweb.asm.Opcodes;

/**
 * Gera um mod "1.7.10" mínimo e SINTÉTICO (não é de terceiros) para testar o Legacy Bridge de ponta a ponta:
 * registra um bloco ("lbtest:test_block") usando só o que os shims atuais cobrem.
 * O bytecode usa os mesmos nomes SRG (func_/field_) e a mesma estrutura de um mod real reofuscado.
 *
 * Uso (JDK 17+):
 *   java --add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED dev-test/MakeTestMod.java saida.jar
 */
public class MakeTestMod {
    static ClassWriter writer() {
        return new ClassWriter(ClassWriter.COMPUTE_FRAMES) {
            @Override
            protected String getCommonSuperClass(String a, String b) {
                return "java/lang/Object";
            }
        };
    }

    static byte[] testBlock() {
        ClassWriter cw = writer();
        cw.visit(Opcodes.V1_7, Opcodes.ACC_PUBLIC | Opcodes.ACC_SUPER, "lbtest/TestBlock", null, "net/minecraft/block/Block", null);
        MethodVisitor mv = cw.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "()V", null, null);
        mv.visitCode();
        mv.visitVarInsn(Opcodes.ALOAD, 0);
        mv.visitFieldInsn(Opcodes.GETSTATIC, "net/minecraft/block/material/Material", "field_151576_e",   // Material.rock
                "Lnet/minecraft/block/material/Material;");
        mv.visitMethodInsn(Opcodes.INVOKESPECIAL, "net/minecraft/block/Block", "<init>",
                "(Lnet/minecraft/block/material/Material;)V", false);
        mv.visitVarInsn(Opcodes.ALOAD, 0);
        mv.visitLdcInsn("testBlock");
        mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "lbtest/TestBlock", "func_149663_c",                   // setBlockName
                "(Ljava/lang/String;)Lnet/minecraft/block/Block;", false);
        mv.visitInsn(Opcodes.POP);
        mv.visitVarInsn(Opcodes.ALOAD, 0);
        mv.visitLdcInsn(1.5f);
        mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "lbtest/TestBlock", "func_149711_c",                   // setHardness
                "(F)Lnet/minecraft/block/Block;", false);
        mv.visitInsn(Opcodes.POP);
        mv.visitInsn(Opcodes.RETURN);
        mv.visitMaxs(0, 0);
        mv.visitEnd();
        cw.visitEnd();
        return cw.toByteArray();
    }

    static byte[] mainClass() {
        ClassWriter cw = writer();
        cw.visit(Opcodes.V1_7, Opcodes.ACC_PUBLIC | Opcodes.ACC_SUPER, "lbtest/LbTestMod", null, "java/lang/Object", null);
        AnnotationVisitor av = cw.visitAnnotation("Lcpw/mods/fml/common/Mod;", true);
        av.visit("modid", "lbtest");
        av.visit("name", "LB Test Mod");
        av.visit("version", "1.0");
        av.visitEnd();

        MethodVisitor init = cw.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "()V", null, null);
        init.visitCode();
        init.visitVarInsn(Opcodes.ALOAD, 0);
        init.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false);
        init.visitInsn(Opcodes.RETURN);
        init.visitMaxs(0, 0);
        init.visitEnd();

        MethodVisitor mv = cw.visitMethod(Opcodes.ACC_PUBLIC, "preInit",
                "(Lcpw/mods/fml/common/event/FMLPreInitializationEvent;)V", null, null);
        mv.visitAnnotation("Lcpw/mods/fml/common/Mod$EventHandler;", true).visitEnd();
        mv.visitCode();
        mv.visitTypeInsn(Opcodes.NEW, "lbtest/TestBlock");
        mv.visitInsn(Opcodes.DUP);
        mv.visitMethodInsn(Opcodes.INVOKESPECIAL, "lbtest/TestBlock", "<init>", "()V", false);
        mv.visitLdcInsn("test_block");
        mv.visitMethodInsn(Opcodes.INVOKESTATIC, "cpw/mods/fml/common/registry/GameRegistry", "registerBlock",
                "(Lnet/minecraft/block/Block;Ljava/lang/String;)Lnet/minecraft/block/Block;", false);
        mv.visitInsn(Opcodes.POP);
        mv.visitInsn(Opcodes.RETURN);
        mv.visitMaxs(0, 0);
        mv.visitEnd();
        cw.visitEnd();
        return cw.toByteArray();
    }

    static byte[] texture() throws Exception {
        BufferedImage img = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < 16; y++) {
            for (int x = 0; x < 16; x++) {
                boolean border = x == 0 || y == 0 || x == 15 || y == 15;
                boolean check = ((x / 4) + (y / 4)) % 2 == 0;
                int rgb = border ? 0x4B2E83 : (check ? 0xFFB000 : 0xFF6A00);
                img.setRGB(x, y, 0xFF000000 | rgb);
            }
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ImageIO.write(img, "png", out);
        return out.toByteArray();
    }

    static void put(ZipOutputStream z, String name, byte[] data) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        z.write(data);
        z.closeEntry();
    }

    static byte[] text(String s) {
        return s.getBytes(StandardCharsets.UTF_8);
    }

    public static void main(String[] args) throws Exception {
        Path out = Paths.get(args.length > 0 ? args[0] : "legacybridge-testmod-1.7.10.jar");
        try (ZipOutputStream z = new ZipOutputStream(Files.newOutputStream(out))) {
            put(z, "META-INF/MANIFEST.MF", text("Manifest-Version: 1.0\r\n\r\n"));
            put(z, "lbtest/LbTestMod.class", mainClass());
            put(z, "lbtest/TestBlock.class", testBlock());
            put(z, "mcmod.info", text("[{\"modid\":\"lbtest\",\"name\":\"LB Test Mod\",\"version\":\"1.0\","
                    + "\"description\":\"Mod sintetico 1.7.10 para testar o Legacy Bridge\"}]"));
            // Estilo 1.7.10: .lang e textures/blocks (o tradutor converte para .json e textures/block)
            put(z, "assets/lbtest/lang/en_US.lang", text("tile.testBlock.name=LB Test Block\n"));
            put(z, "assets/lbtest/textures/blocks/test_block.png", texture());
            // A 1.7.10 não tem blockstates/modelos JSON; aqui vão no formato moderno só para o bloco ter aparência
            // até o tradutor gerar isso sozinho (ainda não implementado).
            put(z, "assets/lbtest/blockstates/test_block.json", text("{\"variants\":{\"\":{\"model\":\"lbtest:block/test_block\"}}}"));
            put(z, "assets/lbtest/models/block/test_block.json",
                    text("{\"parent\":\"minecraft:block/cube_all\",\"textures\":{\"all\":\"lbtest:block/test_block\"}}"));
            put(z, "assets/lbtest/models/item/test_block.json", text("{\"parent\":\"lbtest:block/test_block\"}"));
        }
        System.out.println("Gerado: " + out.toAbsolutePath());
    }
}
