#!/usr/bin/env bash
# Teste rápido do pipeline de tradução SEM Forge e SEM Minecraft.
# Requer JDK 21 (usa o ASM interno do JDK só para testar; o build real usa o ASM do Forge).
# Uso: dev-test/run.sh caminho/methods.csv caminho/fields.csv   (CSVs do MCP 1.7.10, formato "searge,name,side,desc")
set -euo pipefail

here="$(cd "$(dirname "$0")" && pwd)"
methods="$(realpath "${1:?informe o methods.csv do MCP 1.7.10}")"
fields="$(realpath "${2:?informe o fields.csv do MCP 1.7.10}")"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

EXP="--add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED --add-exports java.base/jdk.internal.org.objectweb.asm.commons=ALL-UNNAMED"

mkdir -p "$tmp/src/legacybridge/loader" "$tmp/out" "$tmp/stubout" "$tmp/work"

# Copia o loader (menos o locator, que depende do Forge) trocando o ASM do Forge pelo ASM interno do JDK.
for f in "$here"/../loader/src/main/java/legacybridge/loader/*.java; do
  name="$(basename "$f")"
  [ "$name" = "LegacyBridgeLocator.java" ] && continue
  sed 's/org\.objectweb\.asm/jdk.internal.org.objectweb.asm/g' "$f" > "$tmp/src/legacybridge/loader/$name"
done
cp "$here/Harness.java" "$tmp/src/legacybridge/loader/"

javac $EXP -d "$tmp/out" "$tmp"/src/legacybridge/loader/*.java
javac -d "$tmp/stubout" $(find "$here/stubs" -name '*.java')
jar --create --file "$tmp/stub-runtime.jar" -C "$tmp/stubout" .

java $EXP \
  -Dlb.work="$tmp/work" -Dlb.methods="$methods" -Dlb.fields="$fields" -Dlb.stubjar="$tmp/stub-runtime.jar" \
  -cp "$tmp/out" legacybridge.loader.Harness
