package legacybridge.loader;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

import jdk.internal.org.objectweb.asm.*;

public class Harness {
    static final String MOD = "Lcpw/mods/fml/common/Mod;";

    static byte[] fakeBlock() {
        ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES) { @Override protected String getCommonSuperClass(String a, String b) { return "java/lang/Object"; } };
        cw.visit(Opcodes.V1_7, Opcodes.ACC_PUBLIC | Opcodes.ACC_SUPER, "fake/FakeBlock", null, "net/minecraft/block/Block", null);
        MethodVisitor mv = cw.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "(Lnet/minecraft/block/material/Material;)V", null, null);
        mv.visitCode();
        mv.visitVarInsn(Opcodes.ALOAD, 0);
        mv.visitVarInsn(Opcodes.ALOAD, 1);
        mv.visitMethodInsn(Opcodes.INVOKESPECIAL, "net/minecraft/block/Block", "<init>", "(Lnet/minecraft/block/material/Material;)V", false);
        // this.setBlockName("fakeBlock")  -> func_149663_c, dono = subclasse do mod
        mv.visitVarInsn(Opcodes.ALOAD, 0);
        mv.visitLdcInsn("fakeBlock");
        mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "fake/FakeBlock", "func_149663_c", "(Ljava/lang/String;)Lnet/minecraft/block/Block;", false);
        mv.visitInsn(Opcodes.POP);
        mv.visitInsn(Opcodes.RETURN);
        mv.visitMaxs(0, 0);
        mv.visitEnd();
        cw.visitEnd();
        return cw.toByteArray();
    }

    static byte[] fakeMod() {
        ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES) { @Override protected String getCommonSuperClass(String a, String b) { return "java/lang/Object"; } };
        cw.visit(Opcodes.V1_7, Opcodes.ACC_PUBLIC | Opcodes.ACC_SUPER, "fake/FakeMod", null, "java/lang/Object", null);
        AnnotationVisitor av = cw.visitAnnotation(MOD, true);
        av.visit("modid", "Fake|Mod");
        av.visit("name", "Fake Mod");
        av.visit("version", "${version}");
        av.visitEnd();
        cw.visitField(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "instance", "Lfake/FakeMod;", null, null)
          .visitAnnotation("Lcpw/mods/fml/common/Mod$Instance;", true).visitEnd();

        MethodVisitor init = cw.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "()V", null, null);
        init.visitCode();
        init.visitVarInsn(Opcodes.ALOAD, 0);
        init.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false);
        init.visitInsn(Opcodes.RETURN);
        init.visitMaxs(0, 0);
        init.visitEnd();

        MethodVisitor mv = cw.visitMethod(Opcodes.ACC_PUBLIC, "preInit", "(Lcpw/mods/fml/common/event/FMLPreInitializationEvent;)V", null, null);
        mv.visitAnnotation("Lcpw/mods/fml/common/Mod$EventHandler;", true).visitEnd();
        mv.visitCode();
        mv.visitTypeInsn(Opcodes.NEW, "fake/FakeBlock");
        mv.visitInsn(Opcodes.DUP);
        mv.visitFieldInsn(Opcodes.GETSTATIC, "net/minecraft/block/material/Material", "field_151576_e", "Lnet/minecraft/block/material/Material;");
        mv.visitMethodInsn(Opcodes.INVOKESPECIAL, "fake/FakeBlock", "<init>", "(Lnet/minecraft/block/material/Material;)V", false);
        mv.visitInsn(Opcodes.DUP);
        mv.visitLdcInsn(3.0f);
        mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "fake/FakeBlock", "func_149711_c", "(F)Lnet/minecraft/block/Block;", false);   // setHardness (existe no stub)
        mv.visitInsn(Opcodes.POP);
        mv.visitInsn(Opcodes.DUP);
        mv.visitLdcInsn(5.0f);
        mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "fake/FakeBlock", "func_149752_b", "(F)Lnet/minecraft/block/Block;", false);   // setResistance (NÃO existe no stub)
        mv.visitInsn(Opcodes.POP);
        mv.visitLdcInsn("fake_block");
        mv.visitMethodInsn(Opcodes.INVOKESTATIC, "cpw/mods/fml/common/registry/GameRegistry", "registerBlock",
                "(Lnet/minecraft/block/Block;Ljava/lang/String;)Lnet/minecraft/block/Block;", false);
        mv.visitInsn(Opcodes.POP);
        // referência a classe sem shim: new ItemStack(block)  (só para aparecer no relatório; não é executado)
        Label skip = new Label();
        mv.visitInsn(Opcodes.ICONST_0);
        mv.visitJumpInsn(Opcodes.IFEQ, skip);
        mv.visitTypeInsn(Opcodes.NEW, "net/minecraft/item/ItemStack");
        mv.visitInsn(Opcodes.POP);
        mv.visitLabel(skip);
        mv.visitInsn(Opcodes.RETURN);
        mv.visitMaxs(0, 0);
        mv.visitEnd();
        cw.visitEnd();
        return cw.toByteArray();
    }

    static void putZip(ZipOutputStream z, String n, byte[] d) throws IOException {
        z.putNextEntry(new ZipEntry(n)); z.write(d); z.closeEntry();
    }

    public static void main(String[] a) throws Exception {
        Path work = Paths.get(System.getProperty("lb.work"));
        Files.createDirectories(work);
        Path legacy = work.resolve("fake-1.7.10.jar");
        try (ZipOutputStream z = new ZipOutputStream(Files.newOutputStream(legacy))) {
            putZip(z, "fake/FakeMod.class", fakeMod());
            putZip(z, "fake/FakeBlock.class", fakeBlock());
            putZip(z, "assets/fake/lang/en_US.lang", "# comentario\ntile.fakeBlock.name=Bloco \"Falso\"\nitemGroup.fake=Fake Tab\n".getBytes(StandardCharsets.UTF_8));
            putZip(z, "assets/fake/textures/blocks/fake.png", new byte[]{1, 2, 3});
            putZip(z, "assets/fake/textures/items/thing.png", new byte[]{4});
            putZip(z, "mcmod.info", "[]".getBytes());
            putZip(z, "META-INF/MANIFEST.MF", "Manifest-Version: 1.0\r\nFMLCorePlugin: x\r\n\r\n".getBytes());
            putZip(z, "META-INF/FAKE.SF", new byte[]{9});
        }

        List<LegacyModDecl> decls = LegacyJarInspector.inspect(legacy);
        System.out.println("== inspect: " + decls);

        McpMappings mcp = McpMappings.load(Paths.get(System.getProperty("lb.methods")), Paths.get(System.getProperty("lb.fields")));
        System.out.println("== mapeamentos: " + mcp.size() + " | func_149711_c -> " + mcp.method("func_149711_c") + " | field_151576_e -> " + mcp.field("field_151576_e"));
        ShimIndex shims = ShimIndex.fromJar(Paths.get(System.getProperty("lb.stubjar")), LegacyGeneration.V1_7_10);
        System.out.println("== shims indexados: " + shims.size());

        Path out = work.resolve("fake-translated.jar");
        LinkReport rep = new JarTranslator(mcp, shims).translate(legacy, out, decls);
        System.out.println("\n== LinkReport ==\n" + rep.render("fake-1.7.10.jar"));

        System.out.println("== conteúdo do jar traduzido ==");
        try (ZipFile zf = new ZipFile(out.toFile())) {
            zf.stream().map(ZipEntry::getName).sorted().forEach(n -> System.out.println("  " + n));
            System.out.println("\n-- mods.toml --\n" + new String(zf.getInputStream(zf.getEntry("META-INF/mods.toml")).readAllBytes(), StandardCharsets.UTF_8));
            System.out.println("-- en_us.json --\n" + new String(zf.getInputStream(zf.getEntry("assets/fake/lang/en_us.json")).readAllBytes(), StandardCharsets.UTF_8));
        }

        // Carrega de verdade (com o verificador de bytecode do JVM) e executa o construtor da entrada gerada
        try (URLClassLoader cl = new URLClassLoader(new URL[]{out.toUri().toURL(), Paths.get(System.getProperty("lb.stubjar")).toUri().toURL()}, null)) {
            System.out.println("== executando a entrada gerada ==");
            Class<?> entry = Class.forName("legacybridge.gen.fake_mod.LegacyEntry", true, cl);
            entry.getDeclaredConstructor().newInstance();
            Class<?> mod = Class.forName("fake.FakeMod", true, cl);
            System.out.println("  FakeMod.instance injetado? " + (mod.getField("instance").get(null) != null));
        } catch (Throwable t) {
            System.out.println("FALHOU: ");
            t.printStackTrace(System.out);
        }

        System.out.println("\n== ModIds / cache ==");
        System.out.println("  sanitize(BuildCraft|Core) = " + ModIds.sanitize("BuildCraft|Core") + " ; sanitize(1337) = " + ModIds.sanitize("1337") + " ; sanitize(X) = " + ModIds.sanitize("X"));
        System.out.println("  cache path = " + new TranslationCache(work.resolve("cache"), "abc123def456").pathFor(legacy, "mapkey").getFileName());
    }
}
