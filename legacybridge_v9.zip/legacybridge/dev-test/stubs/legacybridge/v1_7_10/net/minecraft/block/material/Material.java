package legacybridge.v1_7_10.net.minecraft.block.material;
public class Material { public static final Material rock = new Material(); }
