package legacybridge.v1_7_10.net.minecraft.block;
import legacybridge.v1_7_10.net.minecraft.block.material.Material;
public class Block {
  public Block(Material m) {}
  public Block setBlockName(String n) { System.out.println("  [stub] setBlockName " + n); return this; }
  public Block setResistance(float r) { System.out.println("  [stub] setResistance " + r); return this; }
  public Block setHardness(float h) { System.out.println("  [stub] setHardness " + h); return this; }
}
