package legacybridge.v1_7_10.cpw.mods.fml.common.event;
public class FMLPreInitializationEvent { public FMLPreInitializationEvent(String id){} }
