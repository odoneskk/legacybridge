package legacybridge.v1_7_10.cpw.mods.fml.common.registry;
import legacybridge.v1_7_10.net.minecraft.block.Block;
public class GameRegistry { public static Block registerBlock(Block b, String n) { System.out.println("  [stub] registerBlock " + n); return b; } }
