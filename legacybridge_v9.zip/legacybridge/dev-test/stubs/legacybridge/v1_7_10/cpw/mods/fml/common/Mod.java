package legacybridge.v1_7_10.cpw.mods.fml.common;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/** Shim de cpw.mods.fml.common.Mod (1.7.10). */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface Mod {
    String modid();
    String name() default "";
    String version() default "";
    String dependencies() default "";
    boolean useMetadata() default false;
    String acceptedMinecraftVersions() default "";
    String guiFactory() default "";
    boolean canBeDeactivated() default false;
    String certificateFingerprint() default "";
    String modLanguage() default "java";
    String modLanguageAdapter() default "";
    String acceptableRemoteVersions() default "";
    String acceptableSaveVersions() default "";
    boolean clientSideOnly() default false;
    boolean serverSideOnly() default false;

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    @interface EventHandler {
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.FIELD)
    @interface Instance {
        String value() default "";
    }
}
