package legacybridge.v1_7_10.cpw.mods.fml.common.event;

/** Shim de FMLInitializationEvent (1.7.10). */
public class FMLInitializationEvent {
}
