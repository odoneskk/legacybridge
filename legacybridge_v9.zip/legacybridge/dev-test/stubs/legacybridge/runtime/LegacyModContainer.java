package legacybridge.runtime;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import legacybridge.v1_7_10.cpw.mods.fml.common.Mod;

/** Um mod 1.7.10 em execução: injeta @Mod.Instance e despacha eventos para métodos @Mod.EventHandler. */
final class LegacyModContainer {
    private final String modId;
    private final Object instance;

    LegacyModContainer(String modId, Object instance) {
        this.modId = modId;
        this.instance = instance;
    }

    String modId() {
        return modId;
    }

    void injectInstance() throws IllegalAccessException {
        for (Class<?> c = instance.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (f.isAnnotationPresent(Mod.Instance.class) && f.getType().isAssignableFrom(instance.getClass())) {
                    f.setAccessible(true);
                    f.set(Modifier.isStatic(f.getModifiers()) ? null : instance, instance);
                }
            }
        }
    }

    void fire(Object event) {
        for (Class<?> c = instance.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                if (m.isAnnotationPresent(Mod.EventHandler.class)
                        && m.getParameterCount() == 1
                        && m.getParameterTypes()[0].isInstance(event)) {
                    try {
                        m.setAccessible(true);
                        m.invoke(Modifier.isStatic(m.getModifiers()) ? null : instance, event);
                    } catch (InvocationTargetException e) {
                        if (e.getCause() instanceof LinkageError le) {
                            throw LegacyBootstrap.missingShim(modId, le);
                        }
                        throw new IllegalStateException("Erro em " + modId + " (" + m + "): " + e.getCause(), e.getCause());
                    } catch (IllegalAccessException e) {
                        throw new IllegalStateException(e);
                    }
                }
            }
        }
    }
}
