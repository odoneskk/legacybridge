#!/usr/bin/env bash
# Traduz um jar 1.7.10 FORA do Minecraft e imprime o relatório de links (para iterar nos shims sem abrir o jogo).
# Requer JDK 21 (usa o ASM interno do JDK; o build real usa o ASM do Forge).
# Uso: dev-test/translate.sh mod-1.7.10.jar methods.csv fields.csv runtime.jar [saida.jar] [--run]
#   runtime.jar = o jar do runtime (ex.: legacybridge-runtime-*.jar em .legacybridge/runtime/)
#   --run       = também instancia a classe de entrada (só com o runtime de teste: dev-test/stubs)
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
in="$(realpath "${1:?jar do mod 1.7.10}")"
methods="$(realpath "${2:?methods.csv}")"; fields="$(realpath "${3:?fields.csv}")"; runtime="$(realpath "${4:?runtime.jar}")"
out="${5:-./$(basename "${in%.jar}")-traduzido.jar}"; out="$(realpath -m "$out")"
run=false; [ "${6:-}" = "--run" ] && run=true
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
EXP="--add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED --add-exports java.base/jdk.internal.org.objectweb.asm.commons=ALL-UNNAMED"

mkdir -p "$tmp/src/legacybridge/loader" "$tmp/out"
for f in "$here"/../loader/src/main/java/legacybridge/loader/*.java; do
  name="$(basename "$f")"; [ "$name" = "LegacyBridgeLocator.java" ] && continue
  sed 's/org\.objectweb\.asm/jdk.internal.org.objectweb.asm/g' "$f" > "$tmp/src/legacybridge/loader/$name"
done
cp "$here/TranslateCli.java" "$tmp/src/legacybridge/loader/"
javac $EXP -d "$tmp/out" "$tmp"/src/legacybridge/loader/*.java
java $EXP -Dlb.in="$in" -Dlb.out="$out" -Dlb.methods="$methods" -Dlb.fields="$fields" -Dlb.runtime="$runtime" -Dlb.run=$run \
     -cp "$tmp/out" legacybridge.loader.TranslateCli
