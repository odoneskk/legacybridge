package legacybridge.loader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Opcodes;

/** Procura @Mod legados (1.7.10 / 1.12.2) dentro de um jar, lendo só o cabeçalho das classes. */
final class LegacyJarInspector {
    private LegacyJarInspector() {}

    /** Lista vazia = o jar não é um mod legado (já é 1.20.1, é Fabric ou é só uma biblioteca). */
    static List<LegacyModDecl> inspect(Path jar) throws IOException {
        List<LegacyModDecl> found = new ArrayList<>();
        try (ZipFile zip = new ZipFile(jar.toFile())) {
            if (zip.getEntry("META-INF/mods.toml") != null || zip.getEntry("fabric.mod.json") != null) {
                return found;
            }
            for (Enumeration<? extends ZipEntry> en = zip.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement();
                String n = e.getName();
                if (!n.endsWith(".class") || n.startsWith("META-INF/")) {
                    continue;
                }
                try (InputStream in = zip.getInputStream(e)) {
                    scanClass(in.readAllBytes(), found);
                }
            }
        }
        return found;
    }

    private static void scanClass(byte[] bytes, List<LegacyModDecl> out) {
        ClassReader cr = new ClassReader(bytes);
        cr.accept(new ClassVisitor(Opcodes.ASM9) {
            @Override
            public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
                LegacyGeneration gen = LegacyGeneration.byAnnotationDescriptor(descriptor);
                if (gen == null) {
                    return null;
                }
                Map<String, String> values = new HashMap<>();
                return new AnnotationVisitor(Opcodes.ASM9) {
                    @Override
                    public void visit(String name, Object value) {
                        if (value instanceof String s) {
                            values.put(name, s);
                        }
                    }

                    @Override
                    public void visitEnd() {
                        String id = values.get("modid");
                        if (id == null || id.isBlank()) {
                            return;
                        }
                        out.add(new LegacyModDecl(id, values.getOrDefault("name", id),
                                values.getOrDefault("version", ""), cr.getClassName(), gen,
                                values.getOrDefault("dependencies", "")));
                    }
                };
            }
        }, ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
    }
}
