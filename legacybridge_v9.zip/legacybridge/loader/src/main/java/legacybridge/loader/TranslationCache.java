package legacybridge.loader;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;
import java.util.HexFormat;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Cache dos jars traduzidos. A chave inclui o hash do jar original E o "build id" do runtime,
 * então atualizar o Legacy Bridge invalida tudo automaticamente (evita cache velho com shims novos).
 */
final class TranslationCache {
    private final Path dir;
    private final String buildId;

    TranslationCache(Path dir, String buildId) {
        this.dir = dir;
        this.buildId = buildId;
    }

    /** {@code extraKey} entra no nome: troque os CSVs de mapeamento e o jar é retraduzido sozinho. */
    Path pathFor(Path sourceJar, String extraKey) throws IOException {
        String base = sourceJar.getFileName().toString().replaceAll("(?i)\\.jar$", "")
                .replaceAll("[^A-Za-z0-9._-]", "_");
        return dir.resolve(base + "-" + sha256(sourceJar).substring(0, 16) + "-" + buildId + "-" + extraKey + ".jar");
    }

    static Path reportFor(Path translatedJar) {
        String n = translatedJar.getFileName().toString();
        return translatedJar.resolveSibling(n.substring(0, n.length() - ".jar".length()) + ".linkreport.txt");
    }

    /** Apaga do cache tudo que não está em {@code keep} (jars removidos da pasta mods, builds antigos). */
    void prune(Collection<Path> keep) throws IOException {
        if (!Files.isDirectory(dir)) {
            return;
        }
        Set<Path> keepAbs = keep.stream().map(p -> p.toAbsolutePath().normalize()).collect(Collectors.toSet());
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {
            for (Path p : ds) {
                Path abs = p.toAbsolutePath().normalize();
                boolean isReportOfKept = abs.getFileName().toString().endsWith(".linkreport.txt")
                        && keepAbs.contains(abs.resolveSibling(
                                abs.getFileName().toString().replace(".linkreport.txt", ".jar")));
                if (!keepAbs.contains(abs) && !isReportOfKept) {
                    Files.deleteIfExists(p);
                }
            }
        }
    }

    static String sha256(Path file) throws IOException {
        MessageDigest md = digest();
        try (InputStream in = Files.newInputStream(file)) {
            byte[] buf = new byte[1 << 16];
            for (int n; (n = in.read(buf)) > 0; ) {
                md.update(buf, 0, n);
            }
        }
        return HexFormat.of().formatHex(md.digest());
    }

    static String sha256(byte[] data) {
        return HexFormat.of().formatHex(digest().digest(data));
    }

    private static MessageDigest digest() {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
