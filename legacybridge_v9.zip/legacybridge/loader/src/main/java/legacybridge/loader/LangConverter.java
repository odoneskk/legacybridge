package legacybridge.loader;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Converte arquivos .lang (1.7.10/1.12.2) para o JSON moderno.
 *
 * <p>Chaves antigas terminam em ".name" (tile.foo.name); as modernas não. Emitimos as duas formas,
 * assim o shim pode usar a que preferir sem perder tradução.
 */
final class LangConverter {
    private LangConverter() {}

    static String toJson(String lang) {
        Map<String, String> entries = new LinkedHashMap<>();
        for (String raw : lang.split("\\R")) {
            String line = raw.startsWith("\uFEFF") ? raw.substring(1) : raw;
            if (line.isBlank() || line.stripLeading().startsWith("#")) {
                continue;
            }
            int eq = line.indexOf('=');
            if (eq <= 0) {
                continue;
            }
            String key = line.substring(0, eq).strip();
            String value = line.substring(eq + 1).stripTrailing();
            entries.put(key, value);
            if (key.endsWith(".name")) {
                entries.putIfAbsent(key.substring(0, key.length() - ".name".length()), value);
            }
        }
        StringBuilder sb = new StringBuilder("{\n");
        boolean first = true;
        for (Map.Entry<String, String> e : entries.entrySet()) {
            if (!first) {
                sb.append(",\n");
            }
            first = false;
            sb.append("  ").append(json(e.getKey())).append(": ").append(json(e.getValue()));
        }
        return sb.append("\n}\n").toString();
    }

    private static String json(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '\\' -> sb.append("\\\\");
                case '"' -> sb.append("\\\"");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        return sb.append('"').toString();
    }
}
