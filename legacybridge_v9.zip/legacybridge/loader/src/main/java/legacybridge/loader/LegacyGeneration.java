package legacybridge.loader;

import java.util.List;

/**
 * Geração de Minecraft para a qual um mod legado foi escrito.
 *
 * <p>Toda classe da API antiga ({@code legacyRoots}) é realocada para o pacote de shims
 * ({@code shimPrefix}); as classes do próprio mod ficam onde estão.
 */
public enum LegacyGeneration {
    V1_7_10("1.7.10", "legacybridge/v1_7_10/", "cpw/mods/fml/common/Mod",
            List.of("net/minecraft/", "net/minecraftforge/", "cpw/mods/fml/")),
    V1_12_2("1.12.2", "legacybridge/v1_12_2/", "net/minecraftforge/fml/common/Mod",
            List.of("net/minecraft/", "net/minecraftforge/"));

    public final String label;
    public final String shimPrefix;
    /** Nome interno da anotação @Mod daquela geração. */
    public final String modAnnotation;
    public final List<String> legacyRoots;

    LegacyGeneration(String label, String shimPrefix, String modAnnotation, List<String> legacyRoots) {
        this.label = label;
        this.shimPrefix = shimPrefix;
        this.modAnnotation = modAnnotation;
        this.legacyRoots = legacyRoots;
    }

    /** Nome interno (a/b/C) -> nome realocado para o shim, ou o próprio nome se não for API antiga. */
    public String relocate(String internalName) {
        for (String root : legacyRoots) {
            if (internalName.startsWith(root)) {
                return shimPrefix + internalName;
            }
        }
        return internalName;
    }

    public boolean isShim(String internalName) {
        return internalName.startsWith(shimPrefix);
    }

    /** Descobre a geração pelo descritor da anotação (ex.: "Lcpw/mods/fml/common/Mod;"). */
    public static LegacyGeneration byAnnotationDescriptor(String descriptor) {
        for (LegacyGeneration g : values()) {
            if (descriptor.equals("L" + g.modAnnotation + ";")) {
                return g;
            }
        }
        return null;
    }
}
