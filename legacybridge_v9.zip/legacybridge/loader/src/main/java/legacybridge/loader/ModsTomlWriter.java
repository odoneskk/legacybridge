package legacybridge.loader;

import java.util.List;

/** Gera o META-INF/mods.toml do jar traduzido (jars legados não têm um). */
final class ModsTomlWriter {
    private ModsTomlWriter() {}

    static String write(List<LegacyModDecl> mods, String sourceJarName) {
        StringBuilder sb = new StringBuilder();
        sb.append("modLoader=\"javafml\"\n");
        sb.append("loaderVersion=\"[47,)\"\n");
        sb.append("license=\"All Rights Reserved\"\n\n");
        for (LegacyModDecl m : mods) {
            String id = ModIds.sanitize(m.modId());
            sb.append("[[mods]]\n");
            sb.append("modId=").append(quote(id)).append('\n');
            sb.append("version=").append(quote(m.safeVersion())).append('\n');
            sb.append("displayName=").append(quote(m.safeName())).append('\n');
            sb.append("description=").append(quote(
                    "Mod " + m.generation().label + " traduzido pelo Legacy Bridge a partir de " + sourceJarName)).append("\n\n");
            sb.append("[[dependencies.").append(id).append("]]\n");
            sb.append("    modId=\"legacybridge\"\n");
            sb.append("    mandatory=true\n");
            sb.append("    versionRange=\"[0,)\"\n");
            sb.append("    ordering=\"AFTER\"\n");
            sb.append("    side=\"BOTH\"\n\n");
        }
        return sb.toString();
    }

    /** String básica do TOML. */
    static String quote(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '\\' -> sb.append("\\\\");
                case '"' -> sb.append("\\\"");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        return sb.append('"').toString();
    }
}
