package legacybridge.loader;

/** Um @Mod encontrado em um jar legado (valores lidos da anotação, antes de qualquer tradução). */
public record LegacyModDecl(
        String modId,
        String name,
        String version,
        String modClass,          // nome interno, ex.: com/foo/FooMod
        LegacyGeneration generation,
        String dependencies) {

    /** Versão utilizável no mods.toml (placeholders como ${version} viram 1.0.0). */
    public String safeVersion() {
        if (version == null || version.isBlank() || version.contains("${")) {
            return "1.0.0";
        }
        return version;
    }

    public String safeName() {
        return (name == null || name.isBlank()) ? modId : name;
    }
}
