package legacybridge.loader;

import java.util.Locale;

/** Os modids da 1.7.10 aceitam maiúsculas e símbolos ("BuildCraft|Core"); o Forge 1.20.1 exige ^[a-z][a-z0-9_]{1,63}$. */
final class ModIds {
    private ModIds() {}

    static String sanitize(String raw) {
        StringBuilder sb = new StringBuilder();
        for (char c : raw.toLowerCase(Locale.ROOT).toCharArray()) {
            boolean ok = (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_';
            sb.append(ok ? c : '_');
        }
        String s = sb.toString();
        if (s.isEmpty() || s.charAt(0) < 'a' || s.charAt(0) > 'z') {
            s = "m" + s;
        }
        if (s.length() < 2) {
            s += "_";
        }
        return s.length() > 64 ? s.substring(0, 64) : s;
    }
}
