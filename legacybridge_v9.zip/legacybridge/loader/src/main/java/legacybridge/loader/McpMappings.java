package legacybridge.loader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Tabela SRG -> nome MCP (formato CSV padrão do MCP: "searge,name,side,desc").
 *
 * <p>Mods 1.7.10/1.12.2 distribuídos estão reofuscados: chamam {@code func_149711_c}, não {@code setHardness}.
 * Os ids SRG são únicos por família de métodos, então o mapeamento só precisa do nome (não do dono).
 * Os CSVs NÃO acompanham este projeto: baixe-os do MCP (veja o README) e respeite a licença deles.
 */
final class McpMappings {
    private final Map<String, String> methods;
    private final Map<String, String> fields;

    McpMappings(Map<String, String> methods, Map<String, String> fields) {
        this.methods = methods;
        this.fields = fields;
    }

    static McpMappings empty() {
        return new McpMappings(Map.of(), Map.of());
    }

    static McpMappings load(Path methodsCsv, Path fieldsCsv) throws IOException {
        return new McpMappings(read(methodsCsv), read(fieldsCsv));
    }

    String method(String name) {
        return name.startsWith("func_") ? methods.getOrDefault(name, name) : name;
    }

    String field(String name) {
        return name.startsWith("field_") ? fields.getOrDefault(name, name) : name;
    }

    int size() {
        return methods.size() + fields.size();
    }

    private static Map<String, String> read(Path csv) throws IOException {
        Map<String, String> map = new HashMap<>();
        List<String> lines = Files.readAllLines(csv, StandardCharsets.UTF_8);
        for (int i = 1; i < lines.size(); i++) {          // linha 0 = cabeçalho
            String line = lines.get(i);
            int a = line.indexOf(',');
            int b = a < 0 ? -1 : line.indexOf(',', a + 1);
            if (a <= 0 || b < 0) {
                continue;
            }
            map.put(line.substring(0, a), line.substring(a + 1, b));
        }
        return map;
    }
}
