package legacybridge.loader;

import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

/**
 * Gera a classe de entrada que o Forge 1.20.1 enxerga como o mod: um {@code @Mod("modid")} cujo
 * construtor entrega o mod legado ao runtime ({@code LegacyBootstrap.boot}). É assim que um mod 1.7.10,
 * que não tem construtor de mod, passa a ser carregado como mod normal.
 */
final class LifecycleEntryGenerator {
    private LifecycleEntryGenerator() {}

    static byte[] generate(String entryInternalName, String modId, String legacyClassInternalName) {
        ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        cw.visit(Opcodes.V17, Opcodes.ACC_PUBLIC | Opcodes.ACC_SUPER, entryInternalName, null, "java/lang/Object", null);

        AnnotationVisitor av = cw.visitAnnotation("Lnet/minecraftforge/fml/common/Mod;", true);
        av.visit("value", modId);
        av.visitEnd();

        MethodVisitor mv = cw.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "()V", null, null);
        mv.visitCode();
        mv.visitVarInsn(Opcodes.ALOAD, 0);
        mv.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false);
        mv.visitLdcInsn(Type.getObjectType(entryInternalName));
        mv.visitLdcInsn(modId);
        mv.visitLdcInsn(legacyClassInternalName.replace('/', '.'));
        mv.visitMethodInsn(Opcodes.INVOKESTATIC, "legacybridge/runtime/LegacyBootstrap", "boot",
                "(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)V", false);
        mv.visitInsn(Opcodes.RETURN);
        mv.visitMaxs(0, 0);
        mv.visitEnd();

        cw.visitEnd();
        return cw.toByteArray();
    }
}
